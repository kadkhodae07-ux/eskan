library tesseract_ocr.config;

/// OCR engine exposed by the compatibility API.
enum OCREngine {
  vision,
  tesseract,
  defaultEngine,
}

class TesseractConfig {
  static const String preserveInterwordSpaces = 'preserve_interword_spaces';
  static const String pageSegMode = 'tessedit_pageseg_mode';
  static const String ocrEngineMode = 'tessedit_ocr_engine_mode';
  static const String debugFile = 'debug_file';

  const TesseractConfig._();
}

class PageSegmentationMode {
  static const String osd = '0';
  static const String autoOsd = '1';
  static const String autoOnly = '2';
  static const String auto = '3';
  static const String singleColumn = '4';
  static const String singleBlockVertText = '5';
  static const String singleBlock = '6';
  static const String singleLine = '7';
  static const String singleWord = '8';
  static const String singleChar = '9';
  static const String sparseText = '10';
  static const String sparseTextOsd = '11';
  static const String rawLine = '12';

  const PageSegmentationMode._();
}

class OCRConfig {
  final String language;
  final OCREngine engine;
  final String? tessDataPath;
  final Map<String, dynamic>? options;

  const OCRConfig({
    this.language = 'eng',
    this.engine = OCREngine.defaultEngine,
    this.tessDataPath,
    this.options,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'language': language,
      'engine': engine.name,
      if (tessDataPath != null) 'tessDataPath': tessDataPath,
      if (options != null) ...options!,
    };
  }
}
