# Sanadyar Pro — Build 33

Sanadyar is a Flutter-based Persian document utility app with document scanning, OCR, signatures, fingerprint extraction, portrait 3×4 creation, background removal and PDF/image editing.

## Build 33 focus

Build 33 is a build-pipeline and analyzer hardening release over Build 32. It preserves the signature, stamp, PDF and fingerprint improvements while fixing the executable-permission loss that stopped WF-32.1 after dependency resolution. Numeric clamp results used by image and UI code are explicitly converted to the required integer types.

See `CHANGELOG.md` and `VALIDATION_REPORT.md` for details.
