# Third-party notices

This source package bundles `fas.traineddata` and `eng.traineddata` for offline OCR.
The trained data is distributed by the Tesseract OCR project under the Apache License 2.0.

- Project: Tesseract OCR tessdata
- License: Apache-2.0
- Files: `assets/tessdata/fas.traineddata`, `assets/tessdata/eng.traineddata`

The project vendors an Android-compatible derivative of `tesseract_ocr 0.5.0` under `packages/tesseract_ocr`.
Its BSD 3-Clause license is included at `packages/tesseract_ocr/LICENSE`.
The Android implementation resolves the pinned `Tesseract4Android 4.8.0` AAR from JitPack during the Android build. Tesseract4Android and its bundled native components are distributed under their respective upstream licenses, including Apache License 2.0.

Other Flutter/Dart packages remain listed in `pubspec.yaml` and are distributed under their respective licenses.
