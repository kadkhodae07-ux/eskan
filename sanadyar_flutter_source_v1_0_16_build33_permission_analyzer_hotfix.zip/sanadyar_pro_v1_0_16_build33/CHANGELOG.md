# Sanadyar 1.0.16+33

## Fixed

- Fixed Workflow source extraction so executable Unix permissions from ZIP entries are restored.
- Workflow no longer requires Python helper files to retain the executable bit; helpers are validated with `test -f` and invoked through `python3`.
- Added explicit integer conversion for stamp text weight, fingerprint alpha, background-removal alpha and portrait fallback bounds.
- Prevented Build 32 source from being promoted by version rewriting; WF-33.1 accepts only the exact `1.0.16+33` source.

## Preserved

- Signature settings apply to existing strokes and drawing locks parent scrolling.
- Multi-page PDF generation runs in a background isolate.
- Stamp weight, bold and inner-spacing controls are persisted.
- Fingerprint extraction provides cropped transparent output.

## Toolchain

- Flutter: 3.44.6
- Dart: 3.12.2
- Java: 17
- Android compile/target SDK: 36
- Android min SDK: 24
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3
- Kotlin Gradle Plugin: 2.2.20
