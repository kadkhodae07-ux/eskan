import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart' as adivery_ads;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_poolakey/flutter_poolakey.dart';
import 'package:gal/gal.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart' as mlface;
import 'package:google_mlkit_selfie_segmentation/google_mlkit_selfie_segmentation.dart';
import 'package:intl/intl.dart';
import 'package:image/image.dart' as im;
import 'package:image_picker/image_picker.dart';
import 'package:local_auth/local_auth.dart';
import 'package:myket_iap/myket_iap.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:tesseract_ocr/ocr_engine_config.dart';
import 'package:tesseract_ocr/tesseract_ocr.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  AdiveryPlugin.initialize(AppBuildInfo.adiveryAppId);
  AdiveryPlugin.setLoggingEnabled(kDebugMode);
  runApp(const SanadyarApp());
}

enum OutputQuality { light, printReady, compressed }
enum StampShape { circle, rectangle, oval, rounded }
enum AssetKind { signature, fingerprint, portrait }
enum ScanFilter { color, grayscale, document }
enum FingerprintMode { photo, manual }
enum EditorOverlayKind { text, image, stamp }
enum OutputDestination { sanadyar, gallery, device }
enum OcrProfile { document, label, receipt }


class AppBuildInfo {
  static const versionName = '1.0.16';
  static const buildNumber = 40;
  static const versionLabel = '$versionName+$buildNumber';
  static const apiBaseUrl = String.fromEnvironment(
    'SANADYAR_API_BASE_URL',
    defaultValue: 'https://YOUR-DOMAIN.example/sanadyar',
  );
  static const storeChannel = String.fromEnvironment(
    'SANADYAR_STORE_CHANNEL',
    defaultValue: 'direct',
  );
  static const bazaarRsaKey = String.fromEnvironment('SANADYAR_BAZAAR_RSA_KEY');
  static const myketRsaKey = String.fromEnvironment('SANADYAR_MYKET_RSA_KEY');
  static const proProductId = String.fromEnvironment(
    'SANADYAR_PRO_PRODUCT_ID',
    defaultValue: 'sanadyar_pro_monthly',
  );
  static const proPriceLabel = '۲۵٬۰۰۰ تومان در ماه';

  static const adiveryAppId = '1cced1a2-7651-4886-88ae-40bb836351e2';
  static const nativePlacementId = 'd826715d-efaa-4760-8e3c-4f1926daccb5';
  static const rewardedPlacementId = '1f94d8a9-cbc0-48d4-88a6-898cd45f4384';
  static const interstitialPlacementId = 'f633fe88-25fa-407b-bd5c-dd681b5ac63c';
}

int _jsonInt(dynamic value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString().trim() ?? '') ?? fallback;
}

double _jsonDouble(dynamic value, {double fallback = 0}) {
  if (value is num) return value.toDouble();
  return double.tryParse(value?.toString().trim() ?? '') ?? fallback;
}

bool _jsonBool(dynamic value, {bool fallback = false}) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  final normalized = value?.toString().trim().toLowerCase();
  if (normalized == '1' || normalized == 'true' || normalized == 'yes') return true;
  if (normalized == '0' || normalized == 'false' || normalized == 'no') return false;
  return fallback;
}

DateTime? _jsonDate(dynamic value) {
  final text = value?.toString().trim() ?? '';
  if (text.isEmpty) return null;
  return DateTime.tryParse(text)?.toLocal();
}

class SupportTicket {
  SupportTicket({
    required this.id,
    required this.title,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
    this.category = 'عمومی',
    this.lastMessage = '',
    this.unreadCount = 0,
  });

  final int id;
  final String title;
  final String status;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String category;
  final String lastMessage;
  final int unreadCount;

  factory SupportTicket.fromJson(Map<String, dynamic> json) => SupportTicket(
        id: _jsonInt(json['id']),
        title: (json['title'] ?? 'بدون عنوان').toString(),
        status: (json['status'] ?? 'open').toString(),
        createdAt: DateTime.tryParse((json['created_at'] ?? '').toString()) ?? DateTime.now(),
        updatedAt: DateTime.tryParse((json['updated_at'] ?? '').toString()) ?? DateTime.now(),
        category: (json['category'] ?? 'عمومی').toString(),
        lastMessage: (json['last_message'] ?? '').toString(),
        unreadCount: _jsonInt(json['unread_count']),
      );
}

class TicketMessage {
  TicketMessage({required this.senderRole, required this.message, required this.createdAt});
  final String senderRole;
  final String message;
  final DateTime createdAt;

  factory TicketMessage.fromJson(Map<String, dynamic> json) => TicketMessage(
        senderRole: (json['sender_role'] ?? 'user').toString(),
        message: (json['message'] ?? '').toString(),
        createdAt: DateTime.tryParse((json['created_at'] ?? '').toString()) ?? DateTime.now(),
      );
}

class AdminSession {
  AdminSession({required this.token, required this.displayName});
  final String token;
  final String displayName;
}

class BackendClient {
  BackendClient({required this.installationId, this.installationToken = ''});
  final String installationId;
  String installationToken;

  Uri _uri(String path) {
    final base = AppBuildInfo.apiBaseUrl.endsWith('/')
        ? AppBuildInfo.apiBaseUrl.substring(0, AppBuildInfo.apiBaseUrl.length - 1)
        : AppBuildInfo.apiBaseUrl;
    return Uri.parse('$base/api/$path');
  }

  bool get isConfigured => !AppBuildInfo.apiBaseUrl.contains('YOUR-DOMAIN');

  Future<Map<String, dynamic>> _request(
    String path, {
    String method = 'GET',
    Map<String, dynamic>? body,
    String? adminToken,
  }) async {
    if (!isConfigured) {
      throw StateError('آدرس Backend تنظیم نشده است.');
    }
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final request = await client.openUrl(method, _uri(path));
      request.headers.contentType = ContentType.json;
      request.headers.set('X-Installation-ID', installationId);
      request.headers.set('X-App-Version', AppBuildInfo.versionLabel);
      request.headers.set('X-Store-Channel', AppBuildInfo.storeChannel);
      if (installationToken.isNotEmpty) {
        request.headers.set('X-Installation-Token', installationToken);
      }
      if (adminToken != null && adminToken.isNotEmpty) {
        request.headers.set(HttpHeaders.authorizationHeader, 'Bearer $adminToken');
      }
      if (body != null) request.write(jsonEncode(body));
      final response = await request.close().timeout(const Duration(seconds: 20));
      final payload = await utf8.decoder.bind(response).join();
      final decoded = payload.trim().isEmpty ? <String, dynamic>{} : jsonDecode(payload);
      if (decoded is! Map) {
        throw const FormatException('پاسخ سرور ساختار معتبر JSON ندارد.');
      }
      final map = Map<String, dynamic>.from(decoded);
      if (response.statusCode < 200 || response.statusCode >= 300 || map['ok'] == false) {
        throw HttpException((map['message'] ?? 'خطای ارتباط با سرور').toString(), uri: _uri(path));
      }
      return map;
    } finally {
      client.close(force: true);
    }
  }

  Future<String?> registerInstallation({required bool isPro}) async {
    final data = await _request('installations/register.php', method: 'POST', body: {
      'installation_id': installationId,
      'app_version': AppBuildInfo.versionLabel,
      'store_channel': AppBuildInfo.storeChannel,
      'is_pro': isPro,
    });
    final token = (data['installation_token'] ?? '').toString().trim();
    if (token.isNotEmpty) installationToken = token;
    return token.isEmpty ? null : token;
  }

  Future<void> heartbeat({required bool isPro}) async {
    await _request('installations/heartbeat.php', method: 'POST', body: {
      'installation_id': installationId,
      'app_version': AppBuildInfo.versionLabel,
      'store_channel': AppBuildInfo.storeChannel,
      'is_pro': isPro,
    });
  }


  Future<Map<String, dynamic>> entitlementStatus() async {
    final data = await _request(
      'entitlements/status.php?installation_id=${Uri.encodeQueryComponent(installationId)}',
    );
    return Map<String, dynamic>.from(data['entitlement'] as Map? ?? const {});
  }

  Future<Map<String, dynamic>> grantRewardAccess({required String rewardNonce}) async {
    final data = await _request('entitlements/reward.php', method: 'POST', body: {
      'installation_id': installationId,
      'reward_nonce': rewardNonce,
      'placement_id': AppBuildInfo.rewardedPlacementId,
    });
    return Map<String, dynamic>.from(data['entitlement'] as Map? ?? const {});
  }

  Future<Map<String, dynamic>> syncPurchase({
    required String store,
    required String productId,
    required String orderId,
    required String purchaseToken,
    required int purchaseTime,
    required String payload,
    required String originalJson,
    required String signature,
  }) async {
    final data = await _request('entitlements/purchase.php', method: 'POST', body: {
      'installation_id': installationId,
      'store': store,
      'product_id': productId,
      'order_id': orderId,
      'purchase_token': purchaseToken,
      'purchase_time': purchaseTime,
      'payload': payload,
      'original_json': originalJson,
      'signature': signature,
    });
    return Map<String, dynamic>.from(data['entitlement'] as Map? ?? const {});
  }

  Future<List<SupportTicket>> listTickets() async {
    final data = await _request('tickets/list.php?installation_id=${Uri.encodeQueryComponent(installationId)}');
    final items = (data['tickets'] as List? ?? const []);
    return items.map((item) => SupportTicket.fromJson(Map<String, dynamic>.from(item as Map))).toList();
  }

  Future<int> createTicket({required String title, required String category, required String message}) async {
    final data = await _request('tickets/create.php', method: 'POST', body: {
      'installation_id': installationId,
      'title': title,
      'category': category,
      'message': message,
    });
    return _jsonInt(data['ticket_id']);
  }

  Future<List<TicketMessage>> ticketMessages(int ticketId) async {
    final data = await _request('tickets/messages.php?ticket_id=$ticketId&installation_id=${Uri.encodeQueryComponent(installationId)}');
    return (data['messages'] as List? ?? const [])
        .map((item) => TicketMessage.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList();
  }

  Future<void> sendTicketMessage(int ticketId, String message) async {
    await _request('tickets/reply.php', method: 'POST', body: {
      'ticket_id': ticketId,
      'installation_id': installationId,
      'message': message,
    });
  }

  Future<AdminSession> adminLogin(String username, String password) async {
    final data = await _request('admin/login.php', method: 'POST', body: {
      'username': username,
      'password': password,
    });
    return AdminSession(
      token: (data['token'] ?? '').toString(),
      displayName: (data['display_name'] ?? username).toString(),
    );
  }

  Future<Map<String, dynamic>> adminStats(String token) async {
    final data = await _request('admin/stats.php', adminToken: token);
    return Map<String, dynamic>.from(data['stats'] as Map? ?? const {});
  }

  Future<List<SupportTicket>> adminTickets(String token) async {
    final data = await _request('admin/tickets.php', adminToken: token);
    return (data['tickets'] as List? ?? const [])
        .map((item) => SupportTicket.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList();
  }

  Future<void> adminReply(String token, int ticketId, String message, {String status = 'answered'}) async {
    await _request('admin/ticket-reply.php', method: 'POST', adminToken: token, body: {
      'ticket_id': ticketId,
      'message': message,
      'status': status,
    });
  }
}

class SanadyarApp extends StatelessWidget {
  const SanadyarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سندیار',
      themeMode: ThemeMode.system,
      theme: SanadyarTheme.light(),
      darkTheme: SanadyarTheme.dark(),
      home: const HomeShell(),
    );
  }
}

class SanadyarTheme {
  static ThemeData light() => _theme(Brightness.light);
  static ThemeData dark() => _theme(Brightness.dark);

  static ThemeData _theme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(
      seedColor: brightness == Brightness.light ? const Color(0xFF3557A5) : const Color(0xFF8FA9FF),
      brightness: brightness,
      surface: brightness == Brightness.light ? const Color(0xFFF7F8FC) : null,
    );
    final isLight = brightness == Brightness.light;
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Roboto',
      colorScheme: scheme,
      scaffoldBackgroundColor: isLight ? const Color(0xFFF4F6FA) : const Color(0xFF101218),
      appBarTheme: AppBarThemeData(
        centerTitle: false,
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: isLight ? const Color(0xFFF4F6FA) : const Color(0xFF101218),
        titleTextStyle: TextStyle(color: scheme.onSurface, fontSize: 22, fontWeight: FontWeight.w900),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: scheme.surface,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: scheme.outlineVariant.withValues(alpha: .65)),
        ),
      ),
      inputDecorationTheme: InputDecorationThemeData(
        filled: true,
        fillColor: scheme.surfaceContainerLowest,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: scheme.outlineVariant)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: scheme.outlineVariant)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: scheme.primary, width: 1.8)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(50),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          side: BorderSide(color: scheme.outline),
          textStyle: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      sliderTheme: SliderThemeData(
        trackHeight: 4,
        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 9),
        overlayShape: const RoundSliderOverlayShape(overlayRadius: 18),
      ),
      dividerTheme: DividerThemeData(color: scheme.outlineVariant, thickness: 1),
      navigationBarTheme: NavigationBarThemeData(
        height: 72,
        backgroundColor: scheme.surface,
        indicatorColor: scheme.primaryContainer,
        labelTextStyle: WidgetStatePropertyAll(TextStyle(color: scheme.onSurface, fontWeight: FontWeight.w700)),
      ),
    );
  }
}

class ToolPanel extends StatelessWidget {
  const ToolPanel({
    super.key,
    required this.title,
    required this.child,
    this.subtitle,
    this.trailing,
    this.padding = const EdgeInsets.all(16),
  });

  final String title;
  final String? subtitle;
  final Widget child;
  final Widget? trailing;
  final EdgeInsets padding;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colors.outlineVariant.withValues(alpha: .72)),
      ),
      child: Padding(
        padding: padding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                      if (subtitle != null) ...[
                        const SizedBox(height: 3),
                        Text(subtitle!, style: TextStyle(fontSize: 12.5, height: 1.45, color: colors.onSurfaceVariant)),
                      ],
                    ],
                  ),
                ),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: 14),
            child,
          ],
        ),
      ),
    );
  }
}

class ToolHeader extends StatelessWidget {
  const ToolHeader({super.key, required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: colors.primaryContainer.withValues(alpha: .55),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: colors.primary, borderRadius: BorderRadius.circular(13)),
            child: Icon(icon, color: colors.onPrimary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 2),
                Text(subtitle, style: TextStyle(color: colors.onSurfaceVariant, fontSize: 12.5, height: 1.4)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class CompactSlider extends StatelessWidget {
  const CompactSlider({
    super.key,
    required this.label,
    required this.valueLabel,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
    this.divisions,
  });
  final String label;
  final String valueLabel;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  final int? divisions;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.secondaryContainer,
                borderRadius: BorderRadius.circular(99),
              ),
              child: Text(valueLabel, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
            ),
          ],
        ),
        Slider(value: value, min: min, max: max, divisions: divisions, onChanged: onChanged),
      ],
    );
  }
}

class ColorDotPicker extends StatelessWidget {
  const ColorDotPicker({super.key, required this.colors, required this.selected, required this.onChanged});
  final List<Color> colors;
  final Color selected;
  final ValueChanged<Color> onChanged;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: colors.map((color) {
        final active = color.toARGB32() == selected.toARGB32();
        return InkWell(
          borderRadius: BorderRadius.circular(99),
          onTap: () => onChanged(color),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              border: Border.all(color: active ? scheme.primary : scheme.outlineVariant, width: active ? 4 : 1.5),
              boxShadow: active ? [BoxShadow(color: scheme.primary.withValues(alpha: .20), blurRadius: 9)] : null,
            ),
            child: active ? Icon(Icons.check, size: 20, color: color.computeLuminance() > .55 ? Colors.black : Colors.white) : null,
          ),
        );
      }).toList(),
    );
  }
}

class TransparencyGrid extends StatelessWidget {
  const TransparencyGrid({super.key, required this.child, this.radius = 18});
  final Widget child;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: CustomPaint(
        painter: const _TransparencyGridPainter(),
        child: child,
      ),
    );
  }
}

class _TransparencyGridPainter extends CustomPainter {
  const _TransparencyGridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    const cell = 14.0;
    final light = Paint()..color = const Color(0xFFF2F3F5);
    final dark = Paint()..color = const Color(0xFFE1E3E7);
    for (var y = 0.0; y < size.height; y += cell) {
      for (var x = 0.0; x < size.width; x += cell) {
        final even = ((x / cell).floor() + (y / cell).floor()).isEven;
        canvas.drawRect(Rect.fromLTWH(x, y, cell, cell), even ? light : dark);
      }
    }
  }

  @override
  bool shouldRepaint(covariant _TransparencyGridPainter oldDelegate) => false;
}

class OutputDestinationSheet {
  static Future<OutputDestination?> pick(
    BuildContext context, {
    required String title,
    required bool allowGallery,
    String sanadyarLabel = 'ذخیره داخل سندیار',
  }) {
    return showModalBottomSheet<OutputDestination>(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text('محل ذخیره خروجی را انتخاب کن.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 14),
              _destinationTile(
                sheetContext,
                icon: Icons.inventory_2_outlined,
                title: sanadyarLabel,
                subtitle: 'برای استفاده دوباره در ابزارها و پرونده‌ها',
                value: OutputDestination.sanadyar,
              ),
              if (allowGallery)
                _destinationTile(
                  sheetContext,
                  icon: Icons.photo_library_outlined,
                  title: 'ذخیره در گالری',
                  subtitle: 'داخل آلبوم Sanadyar در گالری گوشی',
                  value: OutputDestination.gallery,
                ),
              _destinationTile(
                sheetContext,
                icon: Icons.folder_open_outlined,
                title: 'ذخیره در حافظه گوشی',
                subtitle: 'انتخاب پوشه و نام فایل با فایل‌منیجر',
                value: OutputDestination.device,
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Widget _destinationTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required OutputDestination value,
  }) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: colors.primaryContainer, child: Icon(icon, color: colors.primary)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left),
        onTap: () => Navigator.pop(context, value),
      ),
    );
  }
}

class OutputService {
  static Future<OutputDestination?> save({
    required BuildContext context,
    required LocalStore store,
    required Uint8List bytes,
    required String fileName,
    required String title,
    required bool allowGallery,
    Future<bool> Function(File file)? saveInsideSanadyar,
  }) async {
    final destination = await OutputDestinationSheet.pick(
      context,
      title: title,
      allowGallery: allowGallery,
    );
    if (destination == null || !context.mounted) return null;

    try {
      switch (destination) {
        case OutputDestination.sanadyar:
          final file = await store.saveBytes(fileName, bytes);
          final accepted = saveInsideSanadyar == null ? true : await saveInsideSanadyar(file);
          if (!accepted) {
            if (await file.exists()) await file.delete();
            return null;
          }
          if (context.mounted) _message(context, 'خروجی با موفقیت داخل سندیار ذخیره شد.');
          break;
        case OutputDestination.gallery:
          final tempDirectory = await getTemporaryDirectory();
          final file = File('${tempDirectory.path}/$fileName');
          await file.writeAsBytes(bytes, flush: true);
          try {
            var allowed = await Gal.hasAccess(toAlbum: true);
            if (!allowed) allowed = await Gal.requestAccess(toAlbum: true);
            if (!allowed) throw StateError('دسترسی گالری داده نشد.');
            await Gal.putImage(file.path, album: 'Sanadyar');
          } finally {
            if (await file.exists()) await file.delete();
          }
          if (context.mounted) _message(context, 'تصویر با موفقیت در گالری ذخیره شد.');
          break;
        case OutputDestination.device:
          final extension = fileName.split('.').last.toLowerCase();
          final output = await FilePicker.platform.saveFile(
            dialogTitle: 'ذخیره خروجی سندیار',
            fileName: fileName,
            type: FileType.custom,
            allowedExtensions: [extension],
            bytes: bytes,
          );
          if (output == null) return null;
          if (context.mounted) _message(context, 'فایل با موفقیت در حافظه گوشی ذخیره شد.');
          break;
      }
      return destination;
    } catch (error) {
      if (context.mounted) _message(context, 'ذخیره خروجی انجام نشد: $error', error: true);
      return null;
    }
  }

  static void _message(BuildContext context, String message, {bool error = false}) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
          backgroundColor: error ? Theme.of(context).colorScheme.error : null,
        ),
      );
  }
}

class DocumentProject {
  DocumentProject({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.isPrivate = false,
    this.notes = '',
    this.files = const [],
    this.history = const [],
  });

  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPrivate;
  final String notes;
  final List<DocumentFile> files;
  final List<EditHistory> history;

  DocumentProject copyWith({
    String? title,
    DateTime? updatedAt,
    bool? isPrivate,
    String? notes,
    List<DocumentFile>? files,
    List<EditHistory>? history,
  }) {
    return DocumentProject(
      id: id,
      title: title ?? this.title,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isPrivate: isPrivate ?? this.isPrivate,
      notes: notes ?? this.notes,
      files: files ?? this.files,
      history: history ?? this.history,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isPrivate': isPrivate,
        'notes': notes,
        'files': files.map((e) => e.toJson()).toList(),
        'history': history.map((e) => e.toJson()).toList(),
      };

  factory DocumentProject.fromJson(Map<String, dynamic> json) => DocumentProject(
        id: json['id'] as String,
        title: json['title'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        updatedAt: DateTime.parse(json['updatedAt'] as String),
        isPrivate: json['isPrivate'] == true,
        notes: (json['notes'] ?? '') as String,
        files: ((json['files'] ?? []) as List).map((e) => DocumentFile.fromJson(Map<String, dynamic>.from(e))).toList(),
        history: ((json['history'] ?? []) as List).map((e) => EditHistory.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class DocumentFile {
  DocumentFile({required this.id, required this.name, required this.path, required this.type, required this.createdAt});
  final String id;
  final String name;
  final String path;
  final String type;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'path': path, 'type': type, 'createdAt': createdAt.toIso8601String()};
  factory DocumentFile.fromJson(Map<String, dynamic> json) => DocumentFile(
        id: json['id'] as String,
        name: json['name'] as String,
        path: json['path'] as String,
        type: json['type'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class EditHistory {
  EditHistory({required this.id, required this.title, required this.createdAt, this.snapshotPath});
  final String id;
  final String title;
  final DateTime createdAt;
  final String? snapshotPath;
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'createdAt': createdAt.toIso8601String(), 'snapshotPath': snapshotPath};
  factory EditHistory.fromJson(Map<String, dynamic> json) => EditHistory(
        id: json['id'] as String,
        title: json['title'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        snapshotPath: json['snapshotPath'] as String?,
      );
}

class StampPreset {
  StampPreset({
    required this.id,
    required this.text,
    required this.shape,
    required this.opacity,
    required this.createdAt,
    this.colorValue = 0xFFC62828,
    this.textWeight = 650,
    this.isBold = true,
    this.insetFactor = .34,
    this.borderWidth = 3.0,
  });

  final String id;
  final String text;
  final StampShape shape;
  final double opacity;
  final DateTime createdAt;
  final int colorValue;
  final int textWeight;
  final bool isBold;
  final double insetFactor;
  final double borderWidth;

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'shape': shape.name,
        'opacity': opacity,
        'createdAt': createdAt.toIso8601String(),
        'colorValue': colorValue,
        'textWeight': textWeight,
        'isBold': isBold,
        'insetFactor': insetFactor,
        'borderWidth': borderWidth,
      };

  factory StampPreset.fromJson(Map<String, dynamic> json) => StampPreset(
        id: json['id'] as String,
        text: json['text'] as String,
        shape: StampShape.values.firstWhere((e) => e.name == json['shape'], orElse: () => StampShape.circle),
        opacity: _jsonDouble(json['opacity'], fallback: .72),
        createdAt: DateTime.parse(json['createdAt'] as String),
        colorValue: _jsonInt(json['colorValue'], fallback: 0xFFC62828),
        textWeight: _jsonInt(json['textWeight'], fallback: 650),
        isBold: _jsonBool(json['isBold'], fallback: true),
        insetFactor: _jsonDouble(json['insetFactor'], fallback: .34),
        borderWidth: _jsonDouble(json['borderWidth'], fallback: 3.0),
      );
}

Color stampColorFromPreset(StampPreset preset) => Color(preset.colorValue);

FontWeight stampFontWeightFromPreset(StampPreset preset) {
  final normalized = preset.textWeight.clamp(100, 900).toInt();
  final snapped = ((normalized / 100).round() * 100).clamp(100, 900).toInt();
  return FontWeight.values.firstWhere(
    (value) => value.value == snapped,
    orElse: () => preset.isBold ? FontWeight.w800 : FontWeight.w600,
  );
}


class SavedAsset {
  SavedAsset({
    required this.id,
    required this.name,
    required this.path,
    required this.kind,
    required this.createdAt,
  });

  final String id;
  final String name;
  final String path;
  final AssetKind kind;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'path': path,
        'kind': kind.name,
        'createdAt': createdAt.toIso8601String(),
      };

  factory SavedAsset.fromJson(Map<String, dynamic> json) => SavedAsset(
        id: json['id'] as String,
        name: json['name'] as String,
        path: json['path'] as String,
        kind: AssetKind.values.firstWhere(
          (value) => value.name == json['kind'],
          orElse: () => AssetKind.signature,
        ),
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}


class InkStroke {
  InkStroke({required this.points, required this.color, required this.width});
  final List<Offset> points;
  final Color color;
  final double width;
}

Rect calculateInkStrokeBounds(List<InkStroke> strokes, {double minimumPadding = 18}) {
  if (strokes.isEmpty) return const Rect.fromLTWH(0, 0, 1, 1);
  var minX = double.infinity;
  var minY = double.infinity;
  var maxX = double.negativeInfinity;
  var maxY = double.negativeInfinity;
  var maxWidth = 1.0;
  for (final stroke in strokes) {
    maxWidth = math.max(maxWidth, stroke.width);
    for (final point in stroke.points) {
      minX = math.min(minX, point.dx);
      minY = math.min(minY, point.dy);
      maxX = math.max(maxX, point.dx);
      maxY = math.max(maxY, point.dy);
    }
  }
  if (!minX.isFinite || !minY.isFinite || !maxX.isFinite || !maxY.isFinite) {
    return const Rect.fromLTWH(0, 0, 1, 1);
  }
  final padding = math.max(minimumPadding, maxWidth * 2.5);
  return Rect.fromLTRB(minX, minY, maxX, maxY).inflate(padding);
}

void paintInkStrokes(Canvas canvas, List<InkStroke> strokes) {
  for (final stroke in strokes) {
    if (stroke.points.isEmpty) continue;
    final paint = Paint()
      ..color = stroke.color
      ..strokeWidth = stroke.width
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke
      ..isAntiAlias = true;
    if (stroke.points.length == 1) {
      canvas.drawCircle(stroke.points.first, stroke.width / 2, paint..style = PaintingStyle.fill);
      continue;
    }
    final path = Path()..moveTo(stroke.points.first.dx, stroke.points.first.dy);
    for (var i = 1; i < stroke.points.length; i++) {
      final previous = stroke.points[i - 1];
      final current = stroke.points[i];
      final mid = Offset((previous.dx + current.dx) / 2, (previous.dy + current.dy) / 2);
      path.quadraticBezierTo(previous.dx, previous.dy, mid.dx, mid.dy);
    }
    final last = stroke.points.last;
    path.lineTo(last.dx, last.dy);
    canvas.drawPath(path, paint);
  }
}

class PurchaseActionResult {
  const PurchaseActionResult({required this.success, required this.message});
  final bool success;
  final String message;
}

class MonetizationService {
  MonetizationService._();
  static final MonetizationService instance = MonetizationService._();

  bool _adsInitialized = false;
  bool _interstitialDue = false;
  bool _interstitialShownForLaunch = false;
  Completer<bool>? _rewardCompleter;
  LocalStore? _store;

  Future<void> initialize(LocalStore store) async {
    _store = store;
    if (!_adsInitialized) {
      AdiveryPlugin.addListener(
        onInterstitialLoaded: _onInterstitialLoaded,
        onInterstitialClosed: _onInterstitialClosed,
        onRewardedClosed: _onRewardedClosed,
        onError: _onAdError,
      );
      _adsInitialized = true;
    }

    if (store.shouldShowAds) {
      AdiveryPlugin.prepareRewardedAd(AppBuildInfo.rewardedPlacementId);
      AdiveryPlugin.prepareInterstitialAd(AppBuildInfo.interstitialPlacementId);
      _interstitialDue = store.launchCount.isEven && store.launchCount > 0;
      if (_interstitialDue) {
        unawaited(_tryShowDueInterstitial());
      }
    }

    unawaited(restorePurchase(store, silent: true));
  }

  Future<void> _tryShowDueInterstitial() async {
    if (!_interstitialDue || _interstitialShownForLaunch) return;
    final store = _store;
    if (store == null || !store.shouldShowAds) return;
    try {
      final loaded = await AdiveryPlugin.isLoaded(AppBuildInfo.interstitialPlacementId);
      if (loaded == true && !_interstitialShownForLaunch) {
        _interstitialShownForLaunch = true;
        _interstitialDue = false;
        AdiveryPlugin.show(AppBuildInfo.interstitialPlacementId);
      }
    } catch (_) {
      // Advertising must never crash or block the document workflow.
    }
  }

  void _onInterstitialLoaded(String placement) {
    if (placement == AppBuildInfo.interstitialPlacementId) {
      unawaited(_tryShowDueInterstitial());
    }
  }

  void _onInterstitialClosed(String placement) {
    if (placement == AppBuildInfo.interstitialPlacementId && (_store?.shouldShowAds ?? false)) {
      AdiveryPlugin.prepareInterstitialAd(AppBuildInfo.interstitialPlacementId);
    }
  }

  void _onAdError(String placement, String reason) {
    if (placement == AppBuildInfo.rewardedPlacementId) {
      final completer = _rewardCompleter;
      if (completer != null && !completer.isCompleted) completer.complete(false);
    }
  }

  void _onRewardedClosed(String placement, bool isRewarded) {
    if (placement != AppBuildInfo.rewardedPlacementId) return;
    final completer = _rewardCompleter;
    if (!isRewarded) {
      if (completer != null && !completer.isCompleted) completer.complete(false);
      AdiveryPlugin.prepareRewardedAd(AppBuildInfo.rewardedPlacementId);
      return;
    }
    unawaited(() async {
      final store = _store;
      var granted = false;
      if (store != null) {
        granted = await store.grantOneHourAccess();
      }
      if (completer != null && !completer.isCompleted) completer.complete(granted);
      AdiveryPlugin.prepareRewardedAd(AppBuildInfo.rewardedPlacementId);
    }());
  }

  Future<bool> showRewarded(LocalStore store) async {
    _store = store;
    if (store.hasActivePro) return true;
    if (_rewardCompleter != null && !(_rewardCompleter?.isCompleted ?? true)) return false;

    try {
      var loaded = await AdiveryPlugin.isLoaded(AppBuildInfo.rewardedPlacementId) == true;
      if (!loaded) {
        AdiveryPlugin.prepareRewardedAd(AppBuildInfo.rewardedPlacementId);
        for (var attempt = 0; attempt < 20 && !loaded; attempt++) {
          await Future<void>.delayed(const Duration(milliseconds: 500));
          loaded = await AdiveryPlugin.isLoaded(AppBuildInfo.rewardedPlacementId) == true;
        }
      }
      if (!loaded) return false;

      final completer = Completer<bool>();
      _rewardCompleter = completer;
      AdiveryPlugin.show(AppBuildInfo.rewardedPlacementId);
      return await completer.future.timeout(
        const Duration(minutes: 3),
        onTimeout: () => false,
      );
    } catch (_) {
      return false;
    } finally {
      _rewardCompleter = null;
    }
  }

  Future<PurchaseActionResult> purchasePro(LocalStore store) async {
    try {
      if (AppBuildInfo.storeChannel == 'bazaar') {
        return await _purchaseBazaar(store);
      }
      if (AppBuildInfo.storeChannel == 'myket') {
        return await _purchaseMyket(store);
      }
      return const PurchaseActionResult(
        success: false,
        message: 'این نسخه برای پرداخت بازار یا مایکت ساخته نشده است.',
      );
    } on PlatformException catch (error) {
      final message = error.message?.trim();
      return PurchaseActionResult(
        success: false,
        message: message == null || message.isEmpty ? 'پرداخت لغو شد یا انجام نشد.' : message,
      );
    } catch (error) {
      return PurchaseActionResult(success: false, message: 'فعال‌سازی Pro انجام نشد: $error');
    }
  }

  Future<PurchaseActionResult> _purchaseBazaar(LocalStore store) async {
    if (AppBuildInfo.bazaarRsaKey.trim().isEmpty) {
      return const PurchaseActionResult(success: false, message: 'کلید پرداخت بازار در Workflow تنظیم نشده است.');
    }
    final connected = await _connectBazaar();
    if (!connected) {
      return const PurchaseActionResult(success: false, message: 'اتصال به پرداخت بازار برقرار نشد.');
    }
    final purchase = await FlutterPoolakey.subscribe(
      AppBuildInfo.proProductId,
      payload: store.installationId,
    );
    await store.activatePro(source: 'bazaar');
    unawaited(store.syncPurchaseToBackend(
      storeName: 'bazaar',
      productId: purchase.productId,
      orderId: purchase.orderId,
      purchaseToken: purchase.purchaseToken,
      purchaseTime: purchase.purchaseTime,
      payload: purchase.payload,
      originalJson: purchase.originalJson,
      signature: purchase.dataSignature,
    ));
    return const PurchaseActionResult(success: true, message: 'اشتراک Pro بازار فعال شد.');
  }

  Future<PurchaseActionResult> _purchaseMyket(LocalStore store) async {
    if (AppBuildInfo.myketRsaKey.trim().isEmpty) {
      return const PurchaseActionResult(success: false, message: 'کلید پرداخت مایکت در Workflow تنظیم نشده است.');
    }
    final setup = await MyketIAP.init(
      rsaKey: AppBuildInfo.myketRsaKey,
      enableDebugLogging: kDebugMode,
    );
    if (setup?.isFailure() == true) {
      return PurchaseActionResult(success: false, message: 'اتصال به پرداخت مایکت برقرار نشد: $setup');
    }
    final resultMap = await MyketIAP.launchPurchaseFlow(
      sku: AppBuildInfo.proProductId,
      payload: store.installationId,
    );
    final result = resultMap[MyketIAP.RESULT];
    final purchase = resultMap[MyketIAP.PURCHASE];
    if (result?.isFailure() == true || purchase == null) {
      return PurchaseActionResult(success: false, message: 'پرداخت مایکت کامل نشد: $result');
    }
    await store.activatePro(source: 'myket');
    unawaited(store.syncPurchaseToBackend(
      storeName: 'myket',
      productId: purchase.mSku.toString(),
      orderId: purchase.mOrderId.toString(),
      purchaseToken: purchase.mToken.toString(),
      purchaseTime: _jsonInt(purchase.mPurchaseTime),
      payload: (purchase.mDeveloperPayload ?? '').toString(),
      originalJson: purchase.mOriginalJson.toString(),
      signature: purchase.mSignature.toString(),
    ));
    return const PurchaseActionResult(success: true, message: 'اشتراک Pro مایکت فعال شد.');
  }

  Future<PurchaseActionResult> restorePurchase(LocalStore store, {bool silent = false}) async {
    try {
      bool active;
      if (AppBuildInfo.storeChannel == 'bazaar') {
        if (AppBuildInfo.bazaarRsaKey.trim().isEmpty) {
          return const PurchaseActionResult(success: false, message: 'کلید بازار تنظیم نشده است.');
        }
        final connected = await _connectBazaar();
        if (!connected) throw StateError('اتصال بازار برقرار نشد');
        final subscriptions = await FlutterPoolakey.getAllSubscribedProducts();
        active = subscriptions.any((item) => item.productId == AppBuildInfo.proProductId);
      } else if (AppBuildInfo.storeChannel == 'myket') {
        if (AppBuildInfo.myketRsaKey.trim().isEmpty) {
          return const PurchaseActionResult(success: false, message: 'کلید مایکت تنظیم نشده است.');
        }
        final setup = await MyketIAP.init(
          rsaKey: AppBuildInfo.myketRsaKey,
          enableDebugLogging: kDebugMode,
        );
        if (setup?.isFailure() == true) throw StateError(setup.toString());
        final resultMap = await MyketIAP.getPurchase(
          sku: AppBuildInfo.proProductId,
          querySkuDetails: false,
        );
        final result = resultMap[MyketIAP.RESULT];
        final purchase = resultMap[MyketIAP.PURCHASE];
        if (result?.isFailure() == true) throw StateError(result.toString());
        active = purchase != null && purchase.mSku.toString() == AppBuildInfo.proProductId;
      } else {
        return const PurchaseActionResult(success: false, message: 'کانال فروشگاه پشتیبانی نمی‌شود.');
      }

      if (active) {
        await store.activatePro(source: AppBuildInfo.storeChannel);
        return const PurchaseActionResult(success: true, message: 'اشتراک فعال بازیابی شد.');
      }
      await store.deactivateProAfterVerifiedStoreQuery();
      return const PurchaseActionResult(success: false, message: 'اشتراک فعالی در فروشگاه پیدا نشد.');
    } catch (error) {
      if (silent) {
        return const PurchaseActionResult(success: false, message: 'بررسی خودکار خرید انجام نشد.');
      }
      return PurchaseActionResult(success: false, message: 'بازیابی خرید انجام نشد: $error');
    }
  }

  Future<bool> _connectBazaar() async {
    final completer = Completer<bool>();
    try {
      await FlutterPoolakey.connect(
        AppBuildInfo.bazaarRsaKey,
        onSucceed: () {
          if (!completer.isCompleted) completer.complete(true);
        },
        onFailed: () {
          if (!completer.isCompleted) completer.complete(false);
        },
        onDisconnected: () {},
      );
      if (!completer.isCompleted) {
        return await completer.future.timeout(
          const Duration(seconds: 10),
          onTimeout: () => false,
        );
      }
      return completer.future;
    } catch (_) {
      return false;
    }
  }

  Future<void> dispose() async {
    try {
      if (AppBuildInfo.storeChannel == 'bazaar') await FlutterPoolakey.disconnect();
      if (AppBuildInfo.storeChannel == 'myket') await MyketIAP.dispose();
    } catch (_) {}
  }
}


class LocalStore extends ChangeNotifier {
  static const _projectsKey = 'sanadyar.projects.v17';
  static const _stampsKey = 'sanadyar.stamps.v17';
  static const _tipsKey = 'sanadyar.tips.seen.v17';
  static const _assetsKey = 'sanadyar.assets.v23';
  static const _installationKey = 'sanadyar.installation.id.v1';
  static const _proKey = 'sanadyar.pro.active.v2';
  static const _proSourceKey = 'sanadyar.pro.source.v2';
  static const _freeAccessUntilKey = 'sanadyar.free_access_until.v2';
  static const _launchCountKey = 'sanadyar.launch_count.v2';
  static const _installationTokenKey = 'sanadyar.installation.token.v1';
  final _uuid = const Uuid();
  final _secure = const FlutterSecureStorage();
  final _auth = LocalAuthentication();

  List<DocumentProject> projects = [];
  List<StampPreset> stamps = [];
  List<SavedAsset> assets = [];
  bool tipsEnabled = true;
  bool isPro = false;
  String proSource = '';
  DateTime? freeAccessUntil;
  int launchCount = 0;
  String installationId = '';
  BackendClient? backend;

  bool get hasActivePro => isPro;
  bool get hasActiveFreeAccess => freeAccessUntil?.isAfter(DateTime.now()) ?? false;
  bool get hasFullAccess => hasActivePro || hasActiveFreeAccess;
  bool get shouldShowAds => !hasActivePro;
  Duration get remainingFreeAccess {
    final until = freeAccessUntil;
    if (until == null) return Duration.zero;
    final remaining = until.difference(DateTime.now());
    return remaining.isNegative ? Duration.zero : remaining;
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    projects = ((jsonDecode(prefs.getString(_projectsKey) ?? '[]')) as List)
        .map((e) => DocumentProject.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    stamps = ((jsonDecode(prefs.getString(_stampsKey) ?? '[]')) as List)
        .map((e) => StampPreset.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    assets = ((jsonDecode(prefs.getString(_assetsKey) ?? '[]')) as List)
        .map((e) => SavedAsset.fromJson(Map<String, dynamic>.from(e)))
        .where((asset) => File(asset.path).existsSync())
        .toList();
    tipsEnabled = prefs.getBool(_tipsKey) ?? true;
    isPro = prefs.getBool(_proKey) ?? false;
    proSource = prefs.getString(_proSourceKey) ?? '';
    freeAccessUntil = _jsonDate(prefs.getString(_freeAccessUntilKey));
    launchCount = (prefs.getInt(_launchCountKey) ?? 0) + 1;
    await prefs.setInt(_launchCountKey, launchCount);
    installationId = prefs.getString(_installationKey) ?? '';
    if (installationId.isEmpty) {
      installationId = _uuid.v4();
      await prefs.setString(_installationKey, installationId);
    }
    final installationToken = await _secure.read(key: _installationTokenKey) ?? '';
    backend = BackendClient(installationId: installationId, installationToken: installationToken);
    if (stamps.isEmpty) {
      stamps = [
        StampPreset(
          id: _uuid.v4(),
          text: 'کپی برابر اصل',
          shape: StampShape.circle,
          opacity: .70,
          createdAt: DateTime.now(),
          colorValue: 0xFFC62828,
          textWeight: 700,
          isBold: true,
          insetFactor: .28,
          borderWidth: 3.2,
        ),
        StampPreset(
          id: _uuid.v4(),
          text: 'محرمانه',
          shape: StampShape.rectangle,
          opacity: .65,
          createdAt: DateTime.now(),
          colorValue: 0xFF2356C8,
          textWeight: 700,
          isBold: true,
          insetFactor: .34,
          borderWidth: 2.6,
        ),
      ];
      await _saveStamps();
    }
    notifyListeners();
    unawaited(syncBackend());
  }

  Future<BackendClient> ensureBackendSession() async {
    final client = backend;
    if (client == null || !client.isConfigured) {
      throw StateError('آدرس Backend تنظیم نشده است.');
    }
    if (client.installationToken.isEmpty) {
      final token = await client.registerInstallation(isPro: hasActivePro);
      if (token != null && token.isNotEmpty) {
        await _secure.write(key: _installationTokenKey, value: token);
      }
    }
    if (client.installationToken.isEmpty) {
      throw StateError('نشست امن دستگاه با سرور ساخته نشد.');
    }
    return client;
  }

  Future<void> syncBackend() async {
    final client = backend;
    if (client == null || !client.isConfigured) return;
    try {
      await ensureBackendSession();
      await refreshEntitlementFromBackend();
    } catch (_) {
      // Offline-first: analytics/support sync must never block the app.
    }
  }

  Future<void> heartbeat() async {
    final client = backend;
    if (client == null || !client.isConfigured) return;
    try {
      await ensureBackendSession();
      await client.heartbeat(isPro: hasActivePro);
      await refreshEntitlementFromBackend();
    } catch (_) {
      // Ignore transient network failures.
    }
  }

  Future<void> refreshEntitlementFromBackend() async {
    final client = backend;
    if (client == null || !client.isConfigured || client.installationToken.isEmpty) return;
    final entitlement = await client.entitlementStatus();
    await _applyEntitlement(entitlement, allowProDowngrade: false);
  }

  Future<bool> grantOneHourAccess() async {
    final now = DateTime.now();
    final base = hasActiveFreeAccess ? freeAccessUntil! : now;
    freeAccessUntil = base.add(const Duration(hours: 1));
    await _saveEntitlement();
    notifyListeners();

    final client = backend;
    if (client != null && client.isConfigured) {
      try {
        await ensureBackendSession();
        final entitlement = await client.grantRewardAccess(rewardNonce: _uuid.v4());
        await _applyEntitlement(entitlement, allowProDowngrade: false);
      } catch (_) {
        // The verified ad callback already granted the local hour; sync can retry later.
      }
    }
    return true;
  }

  Future<void> activatePro({required String source}) async {
    isPro = true;
    proSource = source;
    await _saveEntitlement();
    notifyListeners();
    unawaited(syncBackend());
  }

  Future<void> deactivateProAfterVerifiedStoreQuery() async {
    isPro = false;
    proSource = '';
    await _saveEntitlement();
    notifyListeners();
  }

  Future<void> syncPurchaseToBackend({
    required String storeName,
    required String productId,
    required String orderId,
    required String purchaseToken,
    required int purchaseTime,
    required String payload,
    required String originalJson,
    required String signature,
  }) async {
    final client = backend;
    if (client == null || !client.isConfigured) return;
    await ensureBackendSession();
    final entitlement = await client.syncPurchase(
      store: storeName,
      productId: productId,
      orderId: orderId,
      purchaseToken: purchaseToken,
      purchaseTime: purchaseTime,
      payload: payload,
      originalJson: originalJson,
      signature: signature,
    );
    await _applyEntitlement(entitlement, allowProDowngrade: false);
  }

  Future<void> _applyEntitlement(Map<String, dynamic> data, {required bool allowProDowngrade}) async {
    final serverPro = _jsonBool(data['is_pro']);
    if (serverPro || allowProDowngrade) {
      isPro = serverPro;
      proSource = (data['pro_source'] ?? proSource).toString();
    }
    final serverFreeUntil = _jsonDate(data['free_access_until']);
    if (serverFreeUntil != null && (freeAccessUntil == null || serverFreeUntil.isAfter(freeAccessUntil!))) {
      freeAccessUntil = serverFreeUntil;
    }
    await _saveEntitlement();
    notifyListeners();
  }

  Future<void> _saveEntitlement() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_proKey, isPro);
    await prefs.setString(_proSourceKey, proSource);
    final until = freeAccessUntil;
    if (until == null) {
      await prefs.remove(_freeAccessUntilKey);
    } else {
      await prefs.setString(_freeAccessUntilKey, until.toUtc().toIso8601String());
    }
  }

  Future<void> setTips(bool value) async {
    tipsEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_tipsKey, value);
    notifyListeners();
  }

  Future<DocumentProject> createProject(String title, {bool isPrivate = false}) async {
    final now = DateTime.now();
    final project = DocumentProject(id: _uuid.v4(), title: title.trim().isEmpty ? 'پرونده جدید' : title.trim(), createdAt: now, updatedAt: now, isPrivate: isPrivate);
    projects = [project, ...projects];
    await _saveProjects();
    notifyListeners();
    return project;
  }

  Future<void> updateProject(DocumentProject project) async {
    projects = projects.map((p) => p.id == project.id ? project.copyWith(updatedAt: DateTime.now()) : p).toList();
    await _saveProjects();
    notifyListeners();
  }

  Future<void> addStamp(StampPreset stamp) async {
    stamps = [stamp, ...stamps];
    await _saveStamps();
    notifyListeners();
  }

  Future<void> addAsset(SavedAsset asset) async {
    assets = [asset, ...assets];
    await _saveAssets();
    notifyListeners();
  }

  Future<void> deleteAsset(String id) async {
    final target = assets.where((asset) => asset.id == id).firstOrNull;
    if (target != null) {
      final file = File(target.path);
      if (file.existsSync()) {
        await file.delete();
      }
    }
    assets = assets.where((asset) => asset.id != id).toList();
    await _saveAssets();
    notifyListeners();
  }

  Future<void> addFile(String projectId, DocumentFile file, String historyTitle) async {
    projects = projects.map((project) {
      if (project.id != projectId) return project;
      final history = EditHistory(id: _uuid.v4(), title: historyTitle, createdAt: DateTime.now(), snapshotPath: file.path);
      return project.copyWith(files: [file, ...project.files], history: [history, ...project.history], updatedAt: DateTime.now());
    }).toList();
    await _saveProjects();
    notifyListeners();
  }

  Future<bool> unlockPrivateArea() async {
    try {
      final canAuth = await _auth.canCheckBiometrics || await _auth.isDeviceSupported();
      if (canAuth) {
        return _auth.authenticate(localizedReason: 'برای مشاهده پرونده خصوصی، احراز هویت کنید.', options: const AuthenticationOptions(biometricOnly: false));
      }
      final marker = await _secure.read(key: 'private_area_enabled');
      if (marker == null) await _secure.write(key: 'private_area_enabled', value: '1');
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<File> saveBytes(String filename, Uint8List bytes) async {
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory('${dir.path}/sanadyar_outputs');
    if (!folder.existsSync()) folder.createSync(recursive: true);
    final file = File('${folder.path}/$filename');
    return file.writeAsBytes(bytes, flush: true);
  }

  Future<void> _saveProjects() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_projectsKey, jsonEncode(projects.map((e) => e.toJson()).toList()));
  }

  Future<void> _saveStamps() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_stampsKey, jsonEncode(stamps.map((e) => e.toJson()).toList()));
  }

  Future<void> _saveAssets() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_assetsKey, jsonEncode(assets.map((e) => e.toJson()).toList()));
  }
}



class AdiveryNativeAdCard extends StatefulWidget {
  const AdiveryNativeAdCard({super.key, this.compact = false});
  final bool compact;

  @override
  State<AdiveryNativeAdCard> createState() => _AdiveryNativeAdCardState();
}

class _AdiveryNativeAdCardState extends State<AdiveryNativeAdCard> {
  adivery_ads.NativeAd? _ad;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    try {
      final ad = adivery_ads.NativeAd(
        AppBuildInfo.nativePlacementId,
        onAdLoaded: () {
          if (!mounted) return;
          setState(() => _loaded = true);
        },
      );
      _ad = ad;
      ad.loadAd();
    } catch (_) {
      // A missing ad must not affect the rest of the app.
    }
  }

  @override
  void dispose() {
    try {
      _ad?.destroy();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _ad;
    final height = widget.compact ? 142.0 : 172.0;
    if (!_loaded || ad == null || ad.isLoaded != true) {
      return Container(
        height: height,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: .55),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant.withValues(alpha: .7)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(Icons.campaign_outlined, color: Theme.of(context).colorScheme.primary),
                ),
                const SizedBox(width: 12),
                const Expanded(child: Text('در حال آماده‌سازی پیشنهاد', style: TextStyle(fontWeight: FontWeight.w800))),
                const _AdLabel(),
              ],
            ),
            const SizedBox(height: 14),
            const LinearProgressIndicator(minHeight: 4),
          ],
        ),
      );
    }

    return Semantics(
      button: true,
      label: 'تبلیغ همسان',
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: ad.recordClick,
          child: Ink(
            height: height,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainer,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
            ),
            child: Row(
              children: [
                if (ad.icon != null)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: SizedBox(width: widget.compact ? 64 : 76, height: widget.compact ? 64 : 76, child: ad.icon!),
                  )
                else
                  Container(
                    width: widget.compact ? 64 : 76,
                    height: widget.compact ? 64 : 76,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(Icons.local_offer_outlined, color: Theme.of(context).colorScheme.primary),
                  ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          const _AdLabel(),
                          const SizedBox(width: 8),
                          if ((ad.advertiser ?? '').trim().isNotEmpty)
                            Expanded(
                              child: Text(
                                ad.advertiser!,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(context).textTheme.labelMedium,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 7),
                      Text(
                        (ad.headline ?? 'پیشنهاد ویژه').trim(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                      ),
                      if ((ad.description ?? '').trim().isNotEmpty) ...[
                        const SizedBox(height: 5),
                        Text(
                          ad.description!,
                          maxLines: widget.compact ? 1 : 2,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                      const Spacer(),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: FilledButton.tonal(
                          style: FilledButton.styleFrom(
                            minimumSize: const Size(94, 36),
                            padding: const EdgeInsets.symmetric(horizontal: 14),
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          onPressed: ad.recordClick,
                          child: Text((ad.callToAction ?? 'مشاهده').trim()),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AdLabel extends StatelessWidget {
  const _AdLabel();

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.tertiaryContainer,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text('تبلیغ', style: Theme.of(context).textTheme.labelSmall?.copyWith(fontWeight: FontWeight.w800)),
      );
}

class AdiveryNativeAdCarousel extends StatefulWidget {
  const AdiveryNativeAdCarousel({super.key});

  @override
  State<AdiveryNativeAdCarousel> createState() => _AdiveryNativeAdCarouselState();
}

class _AdiveryNativeAdCarouselState extends State<AdiveryNativeAdCarousel> {
  final PageController _controller = PageController(viewportFraction: .94);
  Timer? _timer;
  int _page = 0;
  bool _userScrolling = false;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 7), (_) {
      if (!mounted || !_controller.hasClients || _userScrolling) return;
      _page = (_page + 1) % 3;
      _controller.animateToPage(_page, duration: const Duration(milliseconds: 520), curve: Curves.easeOutCubic);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 182,
        child: NotificationListener<ScrollNotification>(
          onNotification: (notification) {
            if (notification is ScrollStartNotification && notification.dragDetails != null) {
              _userScrolling = true;
            } else if (notification is ScrollEndNotification) {
              _userScrolling = false;
            }
            return false;
          },
          child: PageView.builder(
            controller: _controller,
            itemCount: 3,
            onPageChanged: (value) => _page = value,
            itemBuilder: (_, index) => Padding(
              padding: EdgeInsetsDirectional.only(end: index == 2 ? 0 : 9),
              child: AdiveryNativeAdCard(key: ValueKey('native-ad-$index')),
            ),
          ),
        ),
      );
}

class AccessStatusCard extends StatefulWidget {
  const AccessStatusCard({super.key, required this.store, this.showMetrics = false});
  final LocalStore store;
  final bool showMetrics;

  @override
  State<AccessStatusCard> createState() => _AccessStatusCardState();
}

class _AccessStatusCardState extends State<AccessStatusCard> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && !widget.store.hasActivePro) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _durationLabel(Duration value) {
    final hours = value.inHours.toString().padLeft(2, '0');
    final minutes = (value.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (value.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    final active = store.hasFullAccess;
    final title = store.hasActivePro
        ? 'نسخه Pro فعال است'
        : store.hasActiveFreeAccess
            ? 'دسترسی کامل فعال است'
            : 'برای شروع ابزارها، دسترسی را فعال کنید';
    final subtitle = store.hasActivePro
        ? 'اشتراک ${store.proSource == 'myket' ? 'مایکت' : store.proSource == 'bazaar' ? 'بازار' : 'فروشگاه'} • بدون تبلیغات'
        : store.hasActiveFreeAccess
            ? 'زمان باقی‌مانده: ${_durationLabel(store.remainingFreeAccess)} • تبلیغات نسخه رایگان نمایش داده می‌شود'
            : 'با تماشای هر ویدئو، یک ساعت تمام امکانات فعال می‌شود.';

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProAccessScreen(store: store))),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: (active ? Colors.green : Theme.of(context).colorScheme.primary).withValues(alpha: .12),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Icon(store.hasActivePro ? Icons.workspace_premium : active ? Icons.timer_outlined : Icons.lock_clock_outlined,
                    color: active ? Colors.green.shade700 : Theme.of(context).colorScheme.primary),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 5),
                    Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left),
            ],
          ),
        ),
      ),
    );
  }
}

class AccessGate {
  static Future<bool> ensure(BuildContext context, LocalStore store) async {
    if (store.hasFullAccess) return true;
    final granted = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: _AccessGateSheet(store: store),
      ),
    );
    return granted == true || store.hasFullAccess;
  }
}

class _AccessGateSheet extends StatefulWidget {
  const _AccessGateSheet({required this.store});
  final LocalStore store;

  @override
  State<_AccessGateSheet> createState() => _AccessGateSheetState();
}

class _AccessGateSheetState extends State<_AccessGateSheet> {
  bool _loading = false;

  Future<void> _watch() async {
    if (_loading) return;
    setState(() => _loading = true);
    final granted = await MonetizationService.instance.showRewarded(widget.store);
    if (!mounted) return;
    setState(() => _loading = false);
    if (granted) {
      Navigator.pop(context, true);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تبلیغ فعلاً آماده نیست. چند لحظه دیگر دوباره تلاش کنید.')));
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: EdgeInsets.only(left: 20, right: 20, bottom: 20 + MediaQuery.viewInsetsOf(context).bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(22)),
                child: Icon(Icons.lock_clock_outlined, size: 34, color: Theme.of(context).colorScheme.primary),
              ),
              const SizedBox(height: 14),
              Text('دسترسی ابزارها غیرفعال است', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('یک تبلیغ ویدئویی را کامل ببینید تا یک ساعت به همه امکانات دسترسی داشته باشید. کار در حال انجام هیچ‌وقت با پایان زمان متوقف نمی‌شود.', textAlign: TextAlign.center),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _loading ? null : _watch,
                  icon: _loading
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.play_circle_fill_rounded),
                  label: const Text('تماشای ویدئو و فعال‌سازی یک‌ساعته'),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => ProAccessScreen(store: widget.store)));
                    if (mounted && widget.store.hasFullAccess) Navigator.pop(context, true);
                  },
                  icon: const Icon(Icons.workspace_premium_outlined),
                  label: const Text('ارتقا به Pro ماهانه'),
                ),
              ),
            ],
          ),
        ),
      );
}

class ProAccessScreen extends StatefulWidget {
  const ProAccessScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<ProAccessScreen> createState() => _ProAccessScreenState();
}

class _ProAccessScreenState extends State<ProAccessScreen> {
  Timer? _timer;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _durationLabel(Duration value) {
    final hours = value.inHours.toString().padLeft(2, '0');
    final minutes = (value.inMinutes % 60).toString().padLeft(2, '0');
    final seconds = (value.inSeconds % 60).toString().padLeft(2, '0');
    return '$hours:$minutes:$seconds';
  }

  Future<void> _run(Future<PurchaseActionResult> Function() action) async {
    if (_busy) return;
    setState(() => _busy = true);
    final result = await action();
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result.message)));
  }

  Future<void> _watch() async {
    if (_busy) return;
    setState(() => _busy = true);
    final ok = await MonetizationService.instance.showRewarded(widget.store);
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(ok ? 'یک ساعت دسترسی کامل به زمان شما اضافه شد.' : 'تبلیغ فعلاً آماده نیست. دوباره تلاش کنید.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ارتقا و دسترسی کامل')),
        body: AnimatedBuilder(
          animation: store,
          builder: (_, __) => ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: const LinearGradient(colors: [Color(0xFF162A5B), Color(0xFF6857FF)], begin: Alignment.topRight, end: Alignment.bottomLeft),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.workspace_premium_rounded, color: Colors.amber, size: 42),
                    const SizedBox(height: 12),
                    Text(store.hasActivePro ? 'سندیار Pro فعال است' : 'سندیار Pro', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 24)),
                    const SizedBox(height: 7),
                    const Text('دسترسی همیشگی در طول اشتراک، بدون تبلیغات و بدون نیاز به ویدئو.', style: TextStyle(color: Colors.white70, height: 1.6)),
                    const SizedBox(height: 16),
                    Text(AppBuildInfo.proPriceLabel, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              AccessStatusCard(store: store),
              const SizedBox(height: 14),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('مزایای Pro', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                      const SizedBox(height: 12),
                      const _BenefitRow(icon: Icons.block, text: 'حذف کامل تبلیغات همسان و تمام‌صفحه'),
                      const _BenefitRow(icon: Icons.all_inclusive, text: 'دسترسی کامل به تمام ابزارها در طول اشتراک'),
                      const _BenefitRow(icon: Icons.storefront_outlined, text: 'خرید و بازیابی از همان فروشگاه نصب‌شده'),
                      const SizedBox(height: 14),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _busy || store.hasActivePro ? null : () => _run(() => MonetizationService.instance.purchasePro(store)),
                          icon: _busy
                              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                              : const Icon(Icons.shopping_bag_outlined),
                          label: Text(store.hasActivePro ? 'اشتراک فعال است' : 'خرید اشتراک ماهانه'),
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: TextButton.icon(
                          onPressed: _busy ? null : () => _run(() => MonetizationService.instance.restorePurchase(store)),
                          icon: const Icon(Icons.restore),
                          label: const Text('بازیابی خرید'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (!store.hasActivePro) ...[
                const SizedBox(height: 14),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('دسترسی رایگان یک‌ساعته', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                        const SizedBox(height: 8),
                        Text(
                          store.hasActiveFreeAccess
                              ? 'زمان فعال فعلی: ${_durationLabel(store.remainingFreeAccess)}'
                              : 'با هر بار مشاهده کامل ویدئو، یک ساعت دسترسی اضافه می‌شود.',
                        ),
                        const SizedBox(height: 12),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.tonalIcon(
                            onPressed: _busy ? null : _watch,
                            icon: const Icon(Icons.ondemand_video_rounded),
                            label: const Text('دیدن تبلیغ و افزودن یک ساعت'),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text('نسخه رایگان در زمان فعال نیز تبلیغات را نمایش می‌دهد.', style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                ),
                if (store.shouldShowAds) ...[
                  const SizedBox(height: 14),
                  const AdiveryNativeAdCard(),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _BenefitRow extends StatelessWidget {
  const _BenefitRow({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Row(
          children: [
            Icon(icon, size: 21, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 10),
            Expanded(child: Text(text)),
          ],
        ),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final store = LocalStore();
  Timer? _heartbeatTimer;
  int tab = 0;

  @override
  void initState() {
    super.initState();
    store.load().then((_) {
      if (!mounted) return;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) unawaited(MonetizationService.instance.initialize(store));
      });
      unawaited(store.heartbeat());
      _heartbeatTimer = Timer.periodic(const Duration(minutes: 5), (_) => unawaited(store.heartbeat()));
    });
  }

  @override
  void dispose() {
    _heartbeatTimer?.cancel();
    unawaited(MonetizationService.instance.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: ChangeNotifierProviderLite(
        notifier: store,
        child: AnimatedBuilder(
          animation: store,
          builder: (context, _) => PopScope<Object?>(
            canPop: false,
            onPopInvokedWithResult: (didPop, result) {
              if (didPop) return;
              unawaited(_showExitDialog(context));
            },
            child: Scaffold(
              appBar: AppBar(
              centerTitle: false,
              title: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('سندیار'),
                  if (store.hasActivePro) ...[
                    const SizedBox(width: 8),
                    const Badge(label: Text('PRO')),
                  ],
                ],
              ),
              actions: [
                IconButton(
                  tooltip: 'ارتقا به Pro',
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProAccessScreen(store: store))),
                  icon: Icon(store.hasActivePro ? Icons.workspace_premium : Icons.workspace_premium_outlined),
                ),
                IconButton(onPressed: () => _showGuide(context), icon: const Icon(Icons.help_outline)),
                IconButton(onPressed: () => setState(() {}), icon: const Icon(Icons.refresh)),
              ],
            ),
            body: IndexedStack(
              index: tab,
              children: [
                DashboardScreen(store: store),
                ToolsScreen(store: store),
                ProjectsScreen(store: store),
                SettingsScreen(store: store),
              ],
            ),
            floatingActionButton: FloatingActionButton.extended(
              heroTag: 'support-ticket-fab',
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TicketsScreen(store: store))),
              icon: const Icon(Icons.support_agent_outlined),
              label: const Text('پشتیبانی'),
            ),
              bottomNavigationBar: NavigationBar(
              selectedIndex: tab,
              onDestinationSelected: (value) => setState(() => tab = value),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'داشبورد'),
                NavigationDestination(icon: Icon(Icons.auto_fix_high_outlined), selectedIcon: Icon(Icons.auto_fix_high), label: 'ابزارها'),
                NavigationDestination(icon: Icon(Icons.folder_copy_outlined), selectedIcon: Icon(Icons.folder_copy), label: 'پرونده‌ها'),
                NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
              ],
            ),
          ),
          ),
        ),
      ),
    );
  }

  Future<void> _showExitDialog(BuildContext context) async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: AlertDialog(
          title: const Row(
            children: [
              Icon(Icons.logout_rounded),
              SizedBox(width: 10),
              Text('خروج از سندیار'),
            ],
          ),
          content: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('آیا می‌خواهید از برنامه خارج شوید؟'),
                if (store.shouldShowAds) ...[
                  const SizedBox(height: 14),
                  const AdiveryNativeAdCard(compact: true),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('ماندن')),
            FilledButton.icon(
              onPressed: () => Navigator.pop(dialogContext, true),
              icon: const Icon(Icons.exit_to_app),
              label: const Text('خروج'),
            ),
          ],
        ),
      ),
    );
    if (shouldExit == true) {
      await SystemNavigator.pop();
    }
  }

  void _showGuide(BuildContext context) => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (_) => const SmartGuideSheet(section: 'home'),
      );
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    final recent = [...store.projects]..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        if (store.shouldShowAds) ...[
          const AdiveryNativeAdCarousel(),
          const SizedBox(height: 10),
        ],
        AccessStatusCard(store: store),
        const SizedBox(height: 18),
        Text('ابزارهای اصلی', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        ToolGrid(store: store, compact: true),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(child: _ActionCard(icon: Icons.create_new_folder, title: 'پرونده جدید', subtitle: 'ساخت پوشه اسناد', onTap: () => _createProject(context))),
            const SizedBox(width: 12),
            Expanded(child: _ActionCard(icon: Icons.picture_as_pdf, title: 'خروجی چاپی', subtitle: 'A4 و PDF', onTap: () async {
              if (!await AccessGate.ensure(context, store) || !context.mounted) return;
              Navigator.push(context, MaterialPageRoute(builder: (_) => PrintPrepScreen(store: store)));
            })),
          ],
        ),
        const SizedBox(height: 18),
        Text('فایل‌های اخیر', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        if (recent.isEmpty) const EmptyState(title: 'هنوز پرونده‌ای ساخته نشده', subtitle: 'برای شروع، یک پرونده بساز و فایل‌های سند را داخل آن نگه‌دار.'),
        for (final project in recent.take(6)) ProjectTile(project: project, store: store),
      ],
    );
  }

  Future<void> _createProject(BuildContext context) async {
    if (!await AccessGate.ensure(context, store) || !context.mounted) return;
    final title = await TextInputDialog.show(context, title: 'نام پرونده', hint: 'مثلاً قرارداد اجاره');
    if (title == null) return;
    final project = await store.createProject(title);
    if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectDetailScreen(store: store, projectId: project.id)));
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        ),
      );
}

class ProjectsScreen extends StatelessWidget {
  const ProjectsScreen({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          if (!await AccessGate.ensure(context, store) || !context.mounted) return;
          final title = await TextInputDialog.show(context, title: 'پرونده جدید', hint: 'نام پرونده');
          if (title != null) store.createProject(title);
        },
        icon: const Icon(Icons.add),
        label: const Text('پرونده'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const SectionTitle(title: 'پرونده‌ها', subtitle: 'هر سند، فایل، یادداشت و تاریخچه داخل پرونده خودش ذخیره می‌شود.'),
          const SizedBox(height: 12),
          if (store.projects.isEmpty) const EmptyState(title: 'پرونده‌ای وجود ندارد', subtitle: 'پرونده بساز تا مدارک پراکنده نشوند.'),
          ...store.projects.map((p) => ProjectTile(project: p, store: store)),
        ],
      ),
    );
  }
}

class ProjectTile extends StatelessWidget {
  const ProjectTile({super.key, required this.project, required this.store});
  final DocumentProject project;
  final LocalStore store;
  @override
  Widget build(BuildContext context) {
    final date = DateFormat('yyyy/MM/dd HH:mm').format(project.updatedAt);
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(child: Icon(project.isPrivate ? Icons.lock : Icons.folder)),
        title: Text(project.title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${project.files.length} فایل • آخرین ویرایش $date'),
        trailing: const Icon(Icons.chevron_left),
        onTap: () async {
          if (project.isPrivate) {
            final ok = await store.unlockPrivateArea();
            if (!ok) return;
          }
          if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectDetailScreen(store: store, projectId: project.id)));
        },
      ),
    );
  }
}

class ProjectDetailScreen extends StatefulWidget {
  const ProjectDetailScreen({super.key, required this.store, required this.projectId});
  final LocalStore store;
  final String projectId;
  @override
  State<ProjectDetailScreen> createState() => _ProjectDetailScreenState();
}

class _ProjectDetailScreenState extends State<ProjectDetailScreen> {
  DocumentProject get project => widget.store.projects.firstWhere((p) => p.id == widget.projectId);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(project.title)),
        body: AnimatedBuilder(
          animation: widget.store,
          builder: (_, __) => ListView(
            padding: const EdgeInsets.all(18),
            children: [
              SmartTip(enabled: widget.store.tipsEnabled, text: 'هر بار خروجی گرفتن، یک رکورد در تاریخچه ثبت می‌کند تا برگشت‌پذیری سند حفظ شود.'),
              Row(children: [
                Expanded(child: _ActionCard(icon: Icons.upload_file, title: 'افزودن فایل', subtitle: 'PDF یا عکس', onTap: _pickFile)),
                const SizedBox(width: 12),
                Expanded(child: _ActionCard(icon: Icons.history, title: 'تاریخچه', subtitle: '${project.history.length} تغییر', onTap: () => _showHistory(context))),
              ]),
              const SizedBox(height: 14),
              FilledButton.icon(onPressed: () async {
                if (!await AccessGate.ensure(context, widget.store) || !context.mounted) return;
                Navigator.push(context, MaterialPageRoute(builder: (_) => ExportComposerScreen(store: widget.store, projectId: project.id)));
              }, icon: const Icon(Icons.tune), label: const Text('ساخت خروجی حرفه‌ای')),
              const SizedBox(height: 20),
              const SectionTitle(title: 'فایل‌های پرونده', subtitle: 'فایل‌ها با برچسب نوع و زمان ذخیره می‌شوند.'),
              if (project.files.isEmpty) const EmptyState(title: 'فایلی داخل پرونده نیست', subtitle: 'PDF یا عکس را اضافه کن تا خروجی مهر/واترمارک بسازی.'),
              ...project.files.map((f) => Card(
                    child: ListTile(
                      leading: Icon(f.type == 'pdf' ? Icons.picture_as_pdf : Icons.image),
                      title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(f.type.toUpperCase()),
                      trailing: IconButton(icon: const Icon(Icons.open_in_new), onPressed: () => _openFile(context, f)),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickFile() async {
    if (!await AccessGate.ensure(context, widget.store) || !mounted) return;
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png'],
        allowMultiple: false,
      );
      if (result == null || result.files.isEmpty) return;

      final selected = result.files.first;
      final path = selected.path;
      if (path == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('مسیر فایل انتخاب‌شده در دسترس نیست.')),
          );
        }
        return;
      }

      final name = selected.name;
      final ext = name.split('.').last.toLowerCase();
      await widget.store.addFile(
        project.id,
        DocumentFile(
          id: const Uuid().v4(),
          name: name,
          path: path,
          type: ext == 'pdf' ? 'pdf' : 'image',
          createdAt: DateTime.now(),
        ),
        'افزودن فایل $name',
      );
    } on PlatformException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('انتخاب فایل انجام نشد: ${error.message ?? error.code}')),
      );
    }
  }

  void _showHistory(BuildContext context) => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (_) => Directionality(
          textDirection: ui.TextDirection.rtl,
          child: ListView(padding: const EdgeInsets.all(18), children: [
            const SectionTitle(title: 'تاریخچه ویرایش', subtitle: 'نسخه‌ها و عملیات مهم این پرونده'),
            if (project.history.isEmpty) const EmptyState(title: 'تاریخچه خالی است', subtitle: 'با افزودن فایل یا خروجی گرفتن، تاریخچه ساخته می‌شود.'),
            ...project.history.map((h) => ListTile(leading: const Icon(Icons.restore), title: Text(h.title), subtitle: Text(DateFormat('yyyy/MM/dd HH:mm').format(h.createdAt)))),
          ]),
        ),
      );

  void _openFile(BuildContext context, DocumentFile file) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => FilePreviewScreen(file: file)));
  }
}

class FilePreviewScreen extends StatelessWidget {
  const FilePreviewScreen({super.key, required this.file});
  final DocumentFile file;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text(file.name)),
          body: _buildPreview(),
        ),
      );

  Widget _buildPreview() {
    final source = File(file.path);
    if (!source.existsSync()) {
      return const Center(child: Text('فایل در حافظه پیدا نشد.'));
    }
    if (file.type == 'image') {
      return Center(child: InteractiveViewer(child: Image.file(source)));
    }
    if (file.type == 'text') {
      return FutureBuilder<String>(
        future: source.readAsString(),
        builder: (context, snapshot) => SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: SelectableText(snapshot.data ?? (snapshot.hasError ? 'خواندن متن انجام نشد.' : 'در حال خواندن...')),
        ),
      );
    }
    if (file.type == 'pdf') {
      return PdfPreview(
        canChangeOrientation: false,
        canChangePageFormat: false,
        allowPrinting: true,
        allowSharing: true,
        build: (_) => source.readAsBytes(),
      );
    }
    return Center(child: Text(file.path, textAlign: TextAlign.center));
  }
}

class StampStudioScreen extends StatefulWidget {
  const StampStudioScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<StampStudioScreen> createState() => _StampStudioScreenState();
}

class _StampStudioScreenState extends State<StampStudioScreen> {
  final controller = TextEditingController(text: 'کپی برابر اصل');
  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final previewKey = GlobalKey();
  StampShape shape = StampShape.rectangle;
  double opacity = .90;
  Color stampColor = const Color(0xFFC62828);
  int textWeight = 600;
  double insetFactor = .10;
  double borderWidth = 3.0;
  bool busy = false;
  bool advancedOpen = false;

  String get _effectiveText {
    final name = '${firstNameController.text.trim()} ${lastNameController.text.trim()}'.trim();
    final title = controller.text.trim();
    if (name.isNotEmpty && title.isNotEmpty) return '$name\n$title';
    if (name.isNotEmpty) return name;
    return title;
  }

  String get _shapeLabel => switch (shape) {
        StampShape.circle => 'دایره‌ای',
        StampShape.rectangle => 'مستطیلی',
        StampShape.oval => 'بیضی',
        StampShape.rounded => 'گوشه‌گرد',
      };

  @override
  void dispose() {
    controller.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مهر حرفه‌ای'),
        actions: [
          IconButton(
            tooltip: 'مهرهای ذخیره‌شده',
            onPressed: _showSavedStamps,
            icon: Badge(label: Text('${widget.store.stamps.length}'), child: const Icon(Icons.collections_bookmark_outlined)),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                children: [
                  const ToolHeader(
                    icon: Icons.verified_outlined,
                    title: 'ساخت مهر اختصاصی',
                    subtitle: 'تنظیمات ضروری مرتب شده‌اند؛ گزینه‌های کم‌کاربرد داخل بخش پیشرفته قرار دارند.',
                  ),
                  const SizedBox(height: 12),
                  ToolPanel(
                    title: 'پیش‌نمایش زنده',
                    subtitle: 'هر تغییر بلافاصله روی مهر و خروجی نهایی اعمال می‌شود.',
                    child: Container(
                      height: 210,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surfaceContainerLowest,
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: RepaintBoundary(
                        key: previewKey,
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: StampPreview(
                            text: _effectiveText,
                            shape: shape,
                            opacity: opacity,
                            size: 190,
                            color: stampColor,
                            textWeight: textWeight,
                            isBold: textWeight >= 700,
                            insetFactor: insetFactor,
                            borderWidth: borderWidth,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ToolPanel(
                    title: 'متن و قالب',
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: firstNameController,
                                decoration: const InputDecoration(labelText: 'نام', isDense: true, border: OutlineInputBorder()),
                                onChanged: (_) => setState(() {}),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextField(
                                controller: lastNameController,
                                decoration: const InputDecoration(labelText: 'نام خانوادگی', isDense: true, border: OutlineInputBorder()),
                                onChanged: (_) => setState(() {}),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: controller,
                          decoration: const InputDecoration(
                            labelText: 'عنوان یا متن تکمیلی',
                            hintText: 'مثلاً تأیید شد یا کپی برابر اصل',
                            isDense: true,
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<StampShape>(
                          initialValue: shape,
                          decoration: const InputDecoration(labelText: 'قالب مهر', isDense: true, border: OutlineInputBorder()),
                          items: StampShape.values
                              .map((value) => DropdownMenuItem(
                                    value: value,
                                    child: Text(switch (value) {
                                      StampShape.circle => 'دایره‌ای',
                                      StampShape.rectangle => 'مستطیلی',
                                      StampShape.oval => 'بیضی',
                                      StampShape.rounded => 'گوشه‌گرد',
                                    }),
                                  ))
                              .toList(),
                          onChanged: (value) => setState(() => shape = value ?? shape),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  ToolPanel(
                    title: 'ظاهر مهر',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const Text('رنگ', style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 9),
                        ColorDotPicker(
                          colors: const [Color(0xFFC62828), Color(0xFF2356C8), Color(0xFF202124), Color(0xFF0B8C58)],
                          selected: stampColor,
                          onChanged: (value) => setState(() => stampColor = value),
                        ),
                        const SizedBox(height: 14),
                        SegmentedButton<int>(
                          segments: const [
                            ButtonSegment(value: 400, label: Text('نازک')),
                            ButtonSegment(value: 500, label: Text('معمولی')),
                            ButtonSegment(value: 600, label: Text('نیمه‌بولد')),
                            ButtonSegment(value: 800, label: Text('بولد')),
                          ],
                          selected: {textWeight},
                          onSelectionChanged: (value) => setState(() => textWeight = value.first),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  ToolPanel(
                    title: 'تنظیمات پیشرفته',
                    subtitle: advancedOpen ? 'برای کنترل دقیق فاصله و شفافیت' : 'برای خلوت ماندن صفحه، در حالت بسته قرار دارد.',
                    trailing: IconButton(
                      onPressed: () => setState(() => advancedOpen = !advancedOpen),
                      icon: Icon(advancedOpen ? Icons.expand_less : Icons.tune),
                    ),
                    child: AnimatedCrossFade(
                      duration: const Duration(milliseconds: 180),
                      crossFadeState: advancedOpen ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                      firstChild: Row(
                        children: [
                          _summaryPill('فاصله', '${(insetFactor * 100).round()}٪'),
                          const SizedBox(width: 8),
                          _summaryPill('شفافیت', '${(opacity * 100).round()}٪'),
                          const SizedBox(width: 8),
                          _summaryPill('قاب', borderWidth.toStringAsFixed(1)),
                          const Spacer(),
                          Text(_shapeLabel, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
                        ],
                      ),
                      secondChild: Column(
                        children: [
                          CompactSlider(
                            label: 'فاصله واقعی متن تا قاب',
                            valueLabel: '${(insetFactor * 100).round()}٪',
                            value: insetFactor,
                            min: .03,
                            max: .24,
                            onChanged: (value) => setState(() => insetFactor = value),
                          ),
                          CompactSlider(
                            label: 'ضخامت دور قاب',
                            valueLabel: borderWidth.toStringAsFixed(1),
                            value: borderWidth,
                            min: 1.0,
                            max: 8.0,
                            divisions: 28,
                            onChanged: (value) => setState(() => borderWidth = value),
                          ),
                          CompactSlider(
                            label: 'شفافیت مهر',
                            valueLabel: '${(opacity * 100).round()}٪',
                            value: opacity,
                            min: .35,
                            max: 1,
                            onChanged: (value) => setState(() => opacity = value),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                border: Border(top: BorderSide(color: Theme.of(context).colorScheme.outlineVariant)),
              ),
              child: FilledButton.icon(
                onPressed: _effectiveText.isEmpty || busy ? null : _saveOrExport,
                icon: busy
                    ? const SizedBox.square(dimension: 19, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.save_outlined),
                label: const Text('ذخیره و خروجی مهر'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryPill(String label, String value) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(99),
        ),
        child: Text('$label: $value', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
      );

  Future<Uint8List> _capturePreview() async {
    await WidgetsBinding.instance.endOfFrame;
    final boundary = previewKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) throw StateError('پیش‌نمایش مهر آماده نیست.');
    final image = await boundary.toImage(pixelRatio: 3);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('خروجی مهر ساخته نشد.');
    return data.buffer.asUint8List();
  }

  StampPreset _preset() => StampPreset(
        id: const Uuid().v4(),
        text: _effectiveText,
        shape: shape,
        opacity: opacity,
        createdAt: DateTime.now(),
        colorValue: stampColor.toARGB32(),
        textWeight: textWeight,
        isBold: textWeight >= 700,
        insetFactor: insetFactor,
        borderWidth: borderWidth,
      );

  Future<void> _saveOrExport() async {
    setState(() => busy = true);
    try {
      final preset = _preset();
      final bytes = await _capturePreview();
      await OutputService.save(
        context: context,
        store: widget.store,
        bytes: bytes,
        fileName: 'stamp_${DateTime.now().millisecondsSinceEpoch}.png',
        title: 'ذخیره مهر',
        allowGallery: true,
        saveInsideSanadyar: (_) async {
          await widget.store.addStamp(preset);
          return true;
        },
      );
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _showSavedStamps() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            const SectionTitle(title: 'مهرهای ذخیره‌شده', subtitle: 'برای مشاهده و استفاده مجدد'),
            const SizedBox(height: 8),
            if (widget.store.stamps.isEmpty)
              const EmptyState(title: 'مهری ذخیره نشده', subtitle: 'اولین مهر را از صفحه ساخت ذخیره کن.'),
            ...widget.store.stamps.map(
              (stamp) => Card(
                child: ListTile(
                  leading: StampPreview(
                    text: stamp.text,
                    shape: stamp.shape,
                    opacity: stamp.opacity,
                    size: 58,
                    color: stampColorFromPreset(stamp),
                    textWeight: stamp.textWeight,
                    isBold: stamp.isBold,
                    insetFactor: stamp.insetFactor,
                    borderWidth: stamp.borderWidth,
                  ),
                  title: Text(stamp.text.replaceAll('\n', ' — '), maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${stamp.textWeight >= 700 ? 'بولد' : 'معمولی'} • فاصله ${(StampPreview.normalizedInset(stamp.insetFactor) * 100).round()}٪ • قاب ${stamp.borderWidth.toStringAsFixed(1)}'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class StampPreview extends StatelessWidget {
  const StampPreview({
    super.key,
    required this.text,
    required this.shape,
    required this.opacity,
    required this.size,
    this.color = Colors.red,
    this.textWeight = 600,
    this.isBold = false,
    this.insetFactor = .10,
    this.borderWidth = 3.0,
  });

  final String text;
  final StampShape shape;
  final double opacity;
  final double size;
  final Color color;
  final int textWeight;
  final bool isBold;
  final double insetFactor;
  final double borderWidth;

  static double normalizedInset(double value) {
    if (value <= .25) return value.clamp(.02, .24).toDouble();
    return (.03 + ((value - .16) / .36) * .21).clamp(.03, .24).toDouble();
  }

  static double normalizedBorderWidth(double value, double size) {
    final reference = value.clamp(1.0, 8.0).toDouble();
    return math.max(.8, reference * size / 190);
  }

  @override
  Widget build(BuildContext context) {
    final width = switch (shape) {
      StampShape.circle => size,
      StampShape.oval => size * 1.25,
      StampShape.rectangle || StampShape.rounded => size * 1.25,
    };
    final height = switch (shape) {
      StampShape.circle => size,
      StampShape.oval => size * .72,
      StampShape.rectangle || StampShape.rounded => size * .68,
    };
    final radius = switch (shape) {
      StampShape.circle => size,
      StampShape.oval => size,
      StampShape.rectangle => 7.0,
      StampShape.rounded => 24.0,
    };
    final weight = ((textWeight / 100).round() * 100).clamp(100, 900).toInt();
    final fontWeight = FontWeight.values.firstWhere(
      (item) => item.value == weight,
      orElse: () => isBold ? FontWeight.w800 : FontWeight.w600,
    );
    final inset = normalizedInset(insetFactor);
    return Opacity(
      opacity: opacity,
      child: Container(
        width: width,
        height: height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(color: color, width: normalizedBorderWidth(borderWidth, size)),
          borderRadius: BorderRadius.circular(radius),
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: width * inset, vertical: height * inset),
          child: SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.contain,
              child: Text(
                text.isEmpty ? 'مهر' : text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: color,
                  fontWeight: fontWeight,
                  fontSize: size / 5.8,
                  height: 1.04,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ExportComposerScreen extends StatefulWidget {
  const ExportComposerScreen({super.key, required this.store, required this.projectId});
  final LocalStore store;
  final String projectId;
  @override
  State<ExportComposerScreen> createState() => _ExportComposerScreenState();
}

class _ExportComposerScreenState extends State<ExportComposerScreen> {
  OutputQuality quality = OutputQuality.printReady;
  String watermark = '';
  bool datedSignature = true;
  bool printMargins = true;
  StampPreset? stamp;
  final signer = TextEditingController();
  final tracking = TextEditingController();

  DocumentProject get project => widget.store.projects.firstWhere((p) => p.id == widget.projectId);

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('خروجی حرفه‌ای')),
          body: ListView(padding: const EdgeInsets.all(18), children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'برای چاپ، کیفیت چاپی و حاشیه A4 را فعال نگه‌دار. برای واتساپ، خروجی سبک مناسب‌تر است.'),
            const SectionTitle(title: 'کیفیت خروجی', subtitle: 'سبک برای ارسال، چاپی برای پرینتر، فشرده برای PDF کم‌حجم.'),
            SegmentedButton<OutputQuality>(
              segments: const [
                ButtonSegment(value: OutputQuality.light, label: Text('سبک')),
                ButtonSegment(value: OutputQuality.printReady, label: Text('چاپی')),
                ButtonSegment(value: OutputQuality.compressed, label: Text('فشرده')),
              ],
              selected: {quality},
              onSelectionChanged: (value) => setState(() => quality = value.first),
            ),
            const SizedBox(height: 16),
            TextField(decoration: const InputDecoration(labelText: 'واترمارک اختیاری', hintText: 'مثلاً محرمانه / نمونه / پرداخت شد', border: OutlineInputBorder()), onChanged: (v) => watermark = v),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'مهر', border: OutlineInputBorder()),
              initialValue: stamp?.id,
              items: widget.store.stamps.map((s) => DropdownMenuItem(value: s.id, child: Text(s.text))).toList(),
              onChanged: (id) => setState(() => stamp = widget.store.stamps.where((s) => s.id == id).firstOrNull),
            ),
            SwitchListTile(value: datedSignature, title: const Text('امضای تاریخ‌دار'), subtitle: const Text('نام، تاریخ و کد پیگیری کنار خروجی ثبت شود.'), onChanged: (v) => setState(() => datedSignature = v)),
            if (datedSignature) ...[
              TextField(controller: signer, decoration: const InputDecoration(labelText: 'نام امضاکننده', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              TextField(controller: tracking, decoration: const InputDecoration(labelText: 'کد پیگیری دستی', border: OutlineInputBorder())),
            ],
            SwitchListTile(value: printMargins, title: const Text('آماده‌سازی چاپ A4'), subtitle: const Text('حاشیه امن و اندازه استاندارد PDF'), onChanged: (v) => setState(() => printMargins = v)),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: _exportPdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('ساخت PDF خروجی')),
          ]),
        ),
      );

  Future<void> _exportPdf() async {
    final doc = pw.Document(compress: quality != OutputQuality.printReady);
    final pageTheme = pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: printMargins ? const pw.EdgeInsets.all(36) : pw.EdgeInsets.zero,
    );
    final font = await PdfGoogleFonts.vazirmatnRegular();
    final bold = await PdfGoogleFonts.vazirmatnBold();
    final files = project.files.take(12).toList();
    final date = DateFormat('yyyy/MM/dd HH:mm').format(DateTime.now());

    doc.addPage(pw.MultiPage(
      pageTheme: pageTheme,
      textDirection: pw.TextDirection.rtl,
      build: (context) => [
        pw.Text(project.title, style: pw.TextStyle(font: bold, fontSize: 22)),
        pw.SizedBox(height: 10),
        pw.Text('خروجی سندیار Pro - کیفیت: ${_qualityLabel(quality)}', style: pw.TextStyle(font: font)),
        if (watermark.trim().isNotEmpty) ...[
          pw.SizedBox(height: 20),
          pw.Center(child: pw.Opacity(opacity: .15, child: pw.Text(watermark.trim(), style: pw.TextStyle(font: bold, fontSize: 54, color: PdfColors.red700)))),
        ],
        if (stamp != null) ...[
          pw.SizedBox(height: 16),
          _pdfStamp(stamp!, font: font, boldFont: bold),
        ],
        if (datedSignature) ...[
          pw.SizedBox(height: 22),
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600), borderRadius: pw.BorderRadius.circular(10)),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('امضای تاریخ‌دار', style: pw.TextStyle(font: bold)),
              pw.Text('نام: ${signer.text.trim().isEmpty ? '-' : signer.text.trim()}', style: pw.TextStyle(font: font)),
              pw.Text('تاریخ: $date', style: pw.TextStyle(font: font)),
              pw.Text('کد پیگیری: ${tracking.text.trim().isEmpty ? '-' : tracking.text.trim()}', style: pw.TextStyle(font: font)),
            ]),
          ),
        ],
        pw.SizedBox(height: 22),
        pw.Text('فایل‌های پرونده', style: pw.TextStyle(font: bold, fontSize: 16)),
        ...files.map((f) => pw.Bullet(text: '${f.name} - ${f.type}', style: pw.TextStyle(font: font))),
      ],
    ));
    final bytes = await doc.save();
    final safeName = project.title.replaceAll(RegExp(r'[^A-Za-z0-9آ-ی_-]+'), '_');
    if (!mounted) return;
    await OutputService.save(
      context: context,
      store: widget.store,
      bytes: bytes,
      fileName: 'sanadyar_${safeName}_${DateTime.now().millisecondsSinceEpoch}.pdf',
      title: 'ذخیره PDF پرونده',
      allowGallery: false,
      saveInsideSanadyar: (file) async {
        await widget.store.addFile(
          project.id,
          DocumentFile(
            id: const Uuid().v4(),
            name: file.uri.pathSegments.last,
            path: file.path,
            type: 'pdf',
            createdAt: DateTime.now(),
          ),
          'خروجی PDF با ${_qualityLabel(quality)}',
        );
        return true;
      },
    );
  }

  pw.Widget _pdfStamp(StampPreset preset, {required pw.Font font, required pw.Font boldFont}) {
    final sourceColor = stampColorFromPreset(preset);
    final pdfColor = PdfColor(sourceColor.r, sourceColor.g, sourceColor.b);
    final width = switch (preset.shape) {
      StampShape.circle => 112.0,
      StampShape.oval => 172.0,
      StampShape.rectangle || StampShape.rounded => 172.0,
    };
    final height = switch (preset.shape) {
      StampShape.circle => 112.0,
      StampShape.oval => 78.0,
      StampShape.rectangle || StampShape.rounded => 76.0,
    };
    final radius = switch (preset.shape) {
      StampShape.circle || StampShape.oval => 90.0,
      StampShape.rectangle => 5.0,
      StampShape.rounded => 18.0,
    };
    final inset = StampPreview.normalizedInset(preset.insetFactor);
    return pw.Opacity(
      opacity: preset.opacity,
      child: pw.Container(
        width: width,
        height: height,
        alignment: pw.Alignment.center,
        padding: pw.EdgeInsets.symmetric(horizontal: width * inset, vertical: height * inset),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: pdfColor, width: StampPreview.normalizedBorderWidth(preset.borderWidth, width)),
          borderRadius: pw.BorderRadius.circular(radius),
        ),
        child: pw.FittedBox(
          fit: pw.BoxFit.contain,
          child: pw.Text(
            preset.text,
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              font: preset.textWeight >= 700 ? boldFont : font,
              fontSize: 18,
              color: pdfColor,
            ),
          ),
        ),
      ),
    );
  }

  String _qualityLabel(OutputQuality q) => switch (q) { OutputQuality.light => 'سبک', OutputQuality.printReady => 'چاپی', OutputQuality.compressed => 'فشرده' };
}

class PrintPrepScreen extends StatelessWidget {
  const PrintPrepScreen({super.key, required this.store});
  final LocalStore store;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('آماده‌سازی چاپ')),
          body: ListView(padding: const EdgeInsets.all(18), children: const [
            SectionTitle(title: 'چاپ A4', subtitle: 'این بخش برای کنترل خروجی نهایی قبل از پرینت طراحی شده است.'),
            SmartTip(enabled: true, text: 'حاشیه امن باعث می‌شود امضا، مهر یا متن نزدیک لبه کاغذ بریده نشود.'),
            PrintMockupCard(),
          ]),
        ),
      );
}

class PrintMockupCard extends StatelessWidget {
  const PrintMockupCard({super.key});
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: AspectRatio(
            aspectRatio: 1 / 1.414,
            child: Container(
              decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.outlineVariant), color: Colors.white),
              padding: const EdgeInsets.all(22),
              child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.blueGrey.shade100, style: BorderStyle.solid)), child: const Center(child: Text('پیش‌نمایش حاشیه امن A4'))),
            ),
          ),
        ),
      );
}

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  int _versionTapCount = 0;
  Timer? _tapResetTimer;

  @override
  void dispose() {
    _tapResetTimer?.cancel();
    super.dispose();
  }

  void _handleVersionTap() {
    _tapResetTimer?.cancel();
    _tapResetTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _versionTapCount = 0);
    });
    setState(() => _versionTapCount++);
    if (_versionTapCount < 7) return;
    _versionTapCount = 0;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => AdminLoginScreen(store: widget.store)),
    );
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const SectionTitle(title: 'تنظیمات', subtitle: 'امنیت، پشتیبانی و اطلاعات برنامه'),
          AccessStatusCard(store: widget.store),
          const SizedBox(height: 8),
          SwitchListTile(
            value: widget.store.tipsEnabled,
            title: const Text('راهنمای هوشمند داخل اپ'),
            subtitle: const Text('نمایش نکات کوتاه در بخش‌های مهم'),
            onChanged: widget.store.setTips,
          ),
          ListTile(
            leading: const Icon(Icons.support_agent_outlined),
            title: const Text('تیکت و پشتیبانی'),
            subtitle: const Text('مشاهده تاریخچه تیکت‌ها و ارسال درخواست جدید'),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TicketsScreen(store: widget.store))),
          ),
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              leading: const CircleAvatar(child: Icon(Icons.lock_outline)),
              title: const Text('پوشه خصوصی', style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('پرونده خصوصی با رمز یا اثر انگشت دستگاه باز می‌شود.'),
              isThreeLine: true,
              trailing: SizedBox(
                width: 92,
                child: FilledButton.tonal(
                  style: FilledButton.styleFrom(
                    minimumSize: const Size(0, 42),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  onPressed: () async {
                    final unlocked = await widget.store.unlockPrivateArea();
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(unlocked ? 'قفل خصوصی با موفقیت تأیید شد.' : 'احراز هویت انجام نشد.')),
                    );
                  },
                  child: const Text('بررسی قفل', maxLines: 1),
                ),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.draw),
            title: const Text('دارایی‌های ذخیره‌شده'),
            subtitle: Text('${widget.store.assets.length} امضا، اثر انگشت یا عکس ۳×۴'),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('سندیار'),
              subtitle: Text('نسخه ${AppBuildInfo.versionLabel} • کانال ${AppBuildInfo.storeChannel}'),
              onTap: _handleVersionTap,
            ),
          ),
        ],
      );
}

class TicketsScreen extends StatefulWidget {
  const TicketsScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<TicketsScreen> createState() => _TicketsScreenState();
}

class _TicketsScreenState extends State<TicketsScreen> {
  bool loading = true;
  String? error;
  List<SupportTicket> tickets = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final client = widget.store.backend;
    if (client == null || !client.isConfigured) {
      setState(() {
        loading = false;
        error = 'Backend پشتیبانی هنوز روی دامنه تنظیم نشده است.';
      });
      return;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await widget.store.ensureBackendSession();
      final result = await client.listTickets();
      if (mounted) setState(() => tickets = result);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _newTicket() async {
    final created = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => NewTicketScreen(store: widget.store)),
    );
    if (created == true) await _load();
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('تیکت‌های پشتیبانی')),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _newTicket,
            icon: const Icon(Icons.add_comment_outlined),
            label: const Text('تیکت جدید'),
          ),
          body: RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
              children: [
                const ToolHeader(
                  icon: Icons.support_agent_outlined,
                  title: 'تاریخچه تیکت‌ها',
                  subtitle: 'درخواست‌های قبلی و آخرین وضعیت پاسخ‌گویی را اینجا می‌بینی.',
                ),
                const SizedBox(height: 12),
                if (loading) const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator())),
                if (error != null)
                  EmptyState(title: 'اتصال به پشتیبانی انجام نشد', subtitle: error!),
                if (!loading && error == null && tickets.isEmpty)
                  const EmptyState(title: 'تیکتی ثبت نشده', subtitle: 'برای ارسال درخواست، دکمه «تیکت جدید» را بزن.'),
                ...tickets.map(
                  (ticket) => Card(
                    child: ListTile(
                      leading: CircleAvatar(child: Text('${ticket.id}')),
                      title: Text(ticket.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${_ticketStatusLabel(ticket.status)} • ${DateFormat('yyyy/MM/dd HH:mm').format(ticket.updatedAt)}\n${ticket.lastMessage}', maxLines: 2, overflow: TextOverflow.ellipsis),
                      isThreeLine: true,
                      trailing: ticket.unreadCount > 0 ? Badge(label: Text('${ticket.unreadCount}')) : const Icon(Icons.chevron_left),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => TicketThreadScreen(store: widget.store, ticket: ticket)),
                      ).then((_) => _load()),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
}

String _ticketStatusLabel(String status) => switch (status) {
      'answered' => 'پاسخ داده‌شده',
      'closed' => 'بسته‌شده',
      'pending' => 'در انتظار پاسخ',
      _ => 'باز',
    };

class NewTicketScreen extends StatefulWidget {
  const NewTicketScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<NewTicketScreen> createState() => _NewTicketScreenState();
}

class _NewTicketScreenState extends State<NewTicketScreen> {
  final titleController = TextEditingController();
  final messageController = TextEditingController();
  String category = 'فنی';
  bool sending = false;

  @override
  void dispose() {
    titleController.dispose();
    messageController.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    if (titleController.text.trim().isEmpty || messageController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('عنوان و متن تیکت را کامل کن.')));
      return;
    }
    final client = widget.store.backend;
    if (client == null || !client.isConfigured) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('آدرس Backend پشتیبانی تنظیم نشده است.')));
      return;
    }
    setState(() => sending = true);
    try {
      await widget.store.ensureBackendSession();
      await client.createTicket(title: titleController.text.trim(), category: category, message: messageController.text.trim());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تیکت با موفقیت ارسال شد.')));
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ارسال تیکت انجام نشد: $e')));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('تیکت جدید')),
          body: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              TextField(controller: titleController, decoration: const InputDecoration(labelText: 'عنوان', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue: category,
                decoration: const InputDecoration(labelText: 'دسته‌بندی', border: OutlineInputBorder()),
                items: const ['فنی', 'پرداخت و Pro', 'پیشنهاد', 'گزارش خطا', 'سایر']
                    .map((value) => DropdownMenuItem(value: value, child: Text(value)))
                    .toList(),
                onChanged: (value) => setState(() => category = value ?? category),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: messageController,
                minLines: 6,
                maxLines: 10,
                decoration: const InputDecoration(labelText: 'شرح درخواست', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: sending ? null : _send,
                icon: sending ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send_outlined),
                label: const Text('ارسال تیکت'),
              ),
            ],
          ),
        ),
      );
}

class TicketThreadScreen extends StatefulWidget {
  const TicketThreadScreen({super.key, required this.store, required this.ticket});
  final LocalStore store;
  final SupportTicket ticket;

  @override
  State<TicketThreadScreen> createState() => _TicketThreadScreenState();
}

class _TicketThreadScreenState extends State<TicketThreadScreen> {
  final controller = TextEditingController();
  List<TicketMessage> messages = [];
  bool loading = true;
  bool sending = false;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final client = await widget.store.ensureBackendSession();
      final result = await client.ticketMessages(widget.ticket.id);
      if (mounted) setState(() => messages = result);
    } catch (exception) {
      if (mounted) {
        setState(() => error = 'دریافت پیام‌های تیکت انجام نشد: $exception');
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _reply() async {
    final message = controller.text.trim();
    if (message.isEmpty || sending) return;
    setState(() => sending = true);
    try {
      final client = await widget.store.ensureBackendSession();
      await client.sendTicketMessage(widget.ticket.id, message);
      controller.clear();
      await _load();
    } catch (exception) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ارسال پاسخ انجام نشد: $exception')),
        );
      }
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text(widget.ticket.title)),
          body: Column(
            children: [
              Expanded(
                child: loading
                    ? const Center(child: CircularProgressIndicator())
                    : error != null
                        ? Center(
                            child: Padding(
                              padding: const EdgeInsets.all(24),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.cloud_off_outlined, size: 44),
                                  const SizedBox(height: 12),
                                  Text(error!, textAlign: TextAlign.center),
                                  const SizedBox(height: 12),
                                  FilledButton.tonalIcon(
                                    onPressed: _load,
                                    icon: const Icon(Icons.refresh),
                                    label: const Text('تلاش دوباره'),
                                  ),
                                ],
                              ),
                            ),
                          )
                        : ListView(
                        padding: const EdgeInsets.all(16),
                        children: messages.map((message) {
                          final admin = message.senderRole == 'admin';
                          return Align(
                            alignment: admin ? Alignment.centerLeft : Alignment.centerRight,
                            child: Container(
                              margin: const EdgeInsets.only(bottom: 10),
                              padding: const EdgeInsets.all(12),
                              constraints: const BoxConstraints(maxWidth: 310),
                              decoration: BoxDecoration(
                                color: admin ? Theme.of(context).colorScheme.secondaryContainer : Theme.of(context).colorScheme.primaryContainer,
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(message.message),
                                const SizedBox(height: 5),
                                Text(DateFormat('yyyy/MM/dd HH:mm').format(message.createdAt), style: const TextStyle(fontSize: 11)),
                              ]),
                            ),
                          );
                        }).toList(),
                      ),
              ),
              SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'پاسخ شما', border: OutlineInputBorder()))),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: sending ? null : _reply,
                      icon: sending
                          ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.send),
                    ),
                  ]),
                ),
              ),
            ],
          ),
        ),
      );
}

class AdminLoginScreen extends StatefulWidget {
  const AdminLoginScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<AdminLoginScreen> createState() => _AdminLoginScreenState();
}

class _AdminLoginScreenState extends State<AdminLoginScreen> {
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  bool busy = false;
  bool obscure = true;

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final client = widget.store.backend;
    if (client == null || !client.isConfigured) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا Backend را روی دامنه نصب و آدرس API را در Workflow تنظیم کن.')));
      return;
    }
    setState(() => busy = true);
    try {
      final session = await client.adminLogin(usernameController.text.trim(), passwordController.text);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => AdminDashboardScreen(store: widget.store, session: session)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ورود انجام نشد: $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('ورود مدیریت')),
          body: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(children: [
                      const Icon(Icons.admin_panel_settings_outlined, size: 58),
                      const SizedBox(height: 14),
                      const Text('پنل مدیریت سندیار', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 18),
                      TextField(controller: usernameController, decoration: const InputDecoration(labelText: 'نام کاربری', border: OutlineInputBorder())),
                      const SizedBox(height: 12),
                      TextField(
                        controller: passwordController,
                        obscureText: obscure,
                        decoration: InputDecoration(
                          labelText: 'رمز عبور',
                          border: const OutlineInputBorder(),
                          suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      FilledButton.icon(onPressed: busy ? null : _login, icon: const Icon(Icons.login), label: const Text('ورود امن')),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key, required this.store, required this.session});
  final LocalStore store;
  final AdminSession session;

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool loading = true;
  Map<String, dynamic> stats = {};
  List<SupportTicket> tickets = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final client = widget.store.backend!;
      final results = await Future.wait([
        client.adminStats(widget.session.token),
        client.adminTickets(widget.session.token),
      ]);
      if (mounted) {
        setState(() {
          stats = results[0] as Map<String, dynamic>;
          tickets = results[1] as List<SupportTicket>;
        });
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _replyTicket(SupportTicket ticket) async {
    final controller = TextEditingController();
    final message = await showDialog<String>(
      context: context,
      builder: (dialogContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: AlertDialog(
          title: Text('پاسخ به #${ticket.id}'),
          content: TextField(controller: controller, minLines: 4, maxLines: 8, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'متن پاسخ مدیر')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('انصراف')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text.trim()), child: const Text('ارسال')),
          ],
        ),
      ),
    );
    controller.dispose();
    if (message == null || message.isEmpty) return;
    await widget.store.backend!.adminReply(widget.session.token, ticket.id, message);
    await _load();
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text('مدیریت • ${widget.session.displayName}'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
          body: loading
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      GridView.count(
                        crossAxisCount: 2,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        childAspectRatio: 1.55,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                        children: [
                          _AdminMetricCard(label: 'کل کاربران', value: '${stats['total_users'] ?? 0}', icon: Icons.people_outline),
                          _AdminMetricCard(label: 'فعال امروز', value: '${stats['active_today'] ?? 0}', icon: Icons.bolt_outlined),
                          _AdminMetricCard(label: 'فعال اکنون', value: '${stats['active_now'] ?? 0}', icon: Icons.online_prediction),
                          _AdminMetricCard(label: 'کاربران Pro', value: '${stats['pro_users'] ?? 0}', icon: Icons.workspace_premium_outlined),
                        ],
                      ),
                      const SizedBox(height: 18),
                      SectionTitle(title: 'مدیریت تیکت‌ها', subtitle: '${tickets.length} تیکت'),
                      const SizedBox(height: 8),
                      ...tickets.map((ticket) => Card(
                            child: ListTile(
                              title: Text('#${ticket.id} • ${ticket.title}'),
                              subtitle: Text('${_ticketStatusLabel(ticket.status)} • ${ticket.category}\n${ticket.lastMessage}', maxLines: 2, overflow: TextOverflow.ellipsis),
                              isThreeLine: true,
                              trailing: IconButton.filledTonal(onPressed: () => _replyTicket(ticket), icon: const Icon(Icons.reply)),
                            ),
                          )),
                    ],
                  ),
                ),
        ),
      );
}

class _AdminMetricCard extends StatelessWidget {
  const _AdminMetricCard({required this.label, required this.value, required this.icon});
  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon),
            const Spacer(),
            Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
          ]),
        ),
      );
}

class SmartGuideSheet extends StatelessWidget {
  const SmartGuideSheet({super.key, required this.section});
  final String section;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: const [
            SectionTitle(title: 'راهنمای سریع سندیار', subtitle: 'مسیر پیشنهادی برای خروجی حرفه‌ای'),
            ListTile(leading: Icon(Icons.document_scanner), title: Text('از داشبورد ابزار را انتخاب کن'), subtitle: Text('اسکن، امضا، اثر انگشت، عکس ۳×۴ و OCR همگی مستقیم در دسترس‌اند.')),
            ListTile(leading: Icon(Icons.folder), title: Text('خروجی را داخل پرونده ذخیره کن'), subtitle: Text('تاریخچه و فایل‌ها در پرونده باقی می‌مانند و دوباره قابل استفاده‌اند.')),
            ListTile(leading: Icon(Icons.edit_document), title: Text('در ویرایشگر لایه اضافه کن'), subtitle: Text('امضا، اثر انگشت، مهر و متن را روی PDF یا عکس جابه‌جا و اندازه‌گذاری کن.')),
          ]),
        ),
      );
}

class SmartTip extends StatelessWidget {
  const SmartTip({super.key, required this.enabled, required this.text});
  final bool enabled;
  final String text;
  @override
  Widget build(BuildContext context) => enabled
      ? Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: .55), borderRadius: BorderRadius.circular(18)),
          child: Row(children: [Icon(Icons.lightbulb_outline, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), Expanded(child: Text(text))]),
        )
      : const SizedBox.shrink();
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
        if (subtitle.isNotEmpty) ...[const SizedBox(height: 4), Text(subtitle, style: Theme.of(context).textTheme.bodyMedium)],
      ]);
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(children: [Icon(Icons.inbox_outlined, size: 42, color: Theme.of(context).colorScheme.outline), const SizedBox(height: 10), Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(subtitle, textAlign: TextAlign.center)]),
        ),
      );
}

class TextInputDialog {
  static Future<String?> show(BuildContext context, {required String title, required String hint}) async {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: AlertDialog(
          title: Text(title),
          content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(hintText: hint)),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('تأیید'))],
        ),
      ),
    );
  }
}


class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SectionTitle(
          title: 'ابزارهای سندیار',
          subtitle: 'اسکن، امضا، اثر انگشت، عکس ۳×۴، OCR و ویرایش PDF یا عکس.',
        ),
        const SizedBox(height: 12),
        ToolGrid(store: store),
        const SizedBox(height: 22),
        SectionTitle(
          title: 'دارایی‌های ذخیره‌شده',
          subtitle: '${store.assets.length} مورد قابل استفاده در ویرایشگر',
        ),
        const SizedBox(height: 10),
        if (store.assets.isEmpty)
          const EmptyState(
            title: 'هنوز امضا یا اثر انگشتی ذخیره نشده',
            subtitle: 'از ابزار امضا، اثر انگشت یا عکس ۳×۴ خروجی ذخیره کن.',
          ),
        ...store.assets.take(10).map((asset) => AssetListTile(store: store, asset: asset)),
      ],
    );
  }
}

class ToolGrid extends StatelessWidget {
  const ToolGrid({super.key, required this.store, this.compact = false});
  final LocalStore store;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final tools = <_ToolSpec>[
      _ToolSpec('اسکن سند', 'چندصفحه‌ای و PDF', Icons.document_scanner, () => ScannerScreen(store: store)),
      _ToolSpec('امضا', 'دستی و شفاف', Icons.draw, () => SignatureStudioScreen(store: store)),
      _ToolSpec('اثر انگشت', 'گالری و PNG شفاف', Icons.fingerprint, () => FingerprintStudioScreen(store: store)),
      _ToolSpec('عکس ۳×۴', 'برش و پس‌زمینه', Icons.badge, () => PortraitPhotoScreen(store: store)),
      _ToolSpec('OCR', 'فارسی و انگلیسی', Icons.text_snippet, () => OcrScreen(store: store)),
      _ToolSpec('حذف پس‌زمینه', 'خروجی PNG شفاف', Icons.auto_fix_high, () => BackgroundRemovalScreen(store: store)),
      _ToolSpec('ویرایش سند', 'PDF، عکس و لایه‌ها', Icons.edit_document, () => DocumentEditorScreen(store: store)),
      _ToolSpec('مهر حرفه‌ای', 'دایره‌ای و مستطیلی', Icons.verified, () => StampStudioPage(store: store)),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: tools.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: compact ? 1.25 : 1.18,
      ),
      itemBuilder: (context, index) {
        final tool = tools[index];
        return Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () async {
              if (!await AccessGate.ensure(context, store) || !context.mounted) return;
              Navigator.push(context, MaterialPageRoute(builder: (_) => tool.builder()));
            },
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(tool.icon, color: Theme.of(context).colorScheme.primary),
                  ),
                  const SizedBox(height: 10),
                  Text(tool.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text(tool.subtitle, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ToolSpec {
  const _ToolSpec(this.title, this.subtitle, this.icon, this.builder);
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget Function() builder;
}

class AssetListTile extends StatelessWidget {
  const AssetListTile({super.key, required this.store, required this.asset});
  final LocalStore store;
  final SavedAsset asset;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (!store.assets.any((item) => item.id == asset.id)) {
          return const SizedBox.shrink();
        }
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: 52,
                height: 52,
                color: Colors.white,
                child: File(asset.path).existsSync()
                    ? Image.file(File(asset.path), fit: BoxFit.contain)
                    : const Icon(Icons.broken_image_outlined),
              ),
            ),
            title: Text(asset.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(_assetKindLabel(asset.kind)),
            trailing: IconButton(
              tooltip: 'حذف',
              onPressed: () => store.deleteAsset(asset.id),
              icon: const Icon(Icons.delete_outline),
            ),
          ),
        );
      },
    );
  }
}

String _assetKindLabel(AssetKind kind) => switch (kind) {
      AssetKind.signature => 'امضا',
      AssetKind.fingerprint => 'اثر انگشت',
      AssetKind.portrait => 'عکس ۳×۴',
    };

class StampStudioPage extends StatelessWidget {
  const StampStudioPage({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: StampStudioScreen(store: store),
    );
  }
}

class ProjectPicker {
  static Future<DocumentProject?> pick(BuildContext context, LocalStore store) async {
    if (store.projects.isEmpty) {
      final name = await TextInputDialog.show(context, title: 'ساخت پرونده', hint: 'نام پرونده خروجی');
      if (name == null) return null;
      return store.createProject(name);
    }

    return showModalBottomSheet<DocumentProject>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              const SectionTitle(title: 'انتخاب پرونده', subtitle: 'خروجی در کدام پرونده ذخیره شود؟'),
              const SizedBox(height: 8),
              ListTile(
                leading: const CircleAvatar(child: Icon(Icons.create_new_folder)),
                title: const Text('پرونده جدید'),
                onTap: () async {
                  final name = await TextInputDialog.show(sheetContext, title: 'پرونده جدید', hint: 'نام پرونده');
                  if (name == null || !sheetContext.mounted) return;
                  final project = await store.createProject(name);
                  if (sheetContext.mounted) Navigator.pop(sheetContext, project);
                },
              ),
              ...store.projects.map(
                (project) => ListTile(
                  leading: Icon(project.isPrivate ? Icons.lock : Icons.folder),
                  title: Text(project.title),
                  subtitle: Text('${project.files.length} فایل'),
                  onTap: () => Navigator.pop(sheetContext, project),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GeneratedFileSaver {
  static Future<bool> attach({
    required BuildContext context,
    required LocalStore store,
    required File file,
    required String type,
    required String historyTitle,
  }) async {
    final project = await ProjectPicker.pick(context, store);
    if (project == null) return false;
    await store.addFile(
      project.id,
      DocumentFile(
        id: const Uuid().v4(),
        name: file.uri.pathSegments.last,
        path: file.path,
        type: type,
        createdAt: DateTime.now(),
      ),
      historyTitle,
    );
    return true;
  }
}


class PortraitSegmentationResult {
  const PortraitSegmentationResult({required this.bytes, required this.faceDetected});
  final Uint8List bytes;
  final bool faceDetected;
}

class PortraitSegmentationService {
  static Future<PortraitSegmentationResult> removePersonBackground({
    required String imagePath,
    required double threshold,
    Color? background,
    bool portraitCanvas = false,
  }) async {
    final segmenter = SelfieSegmenter(mode: SegmenterMode.single, enableRawSizeMask: true);
    mlface.FaceDetector? faceDetector;
    try {
      final input = InputImage.fromFilePath(imagePath);
      final mask = await segmenter.processImage(input);
      if (mask == null) throw StateError('سوژه انسانی در تصویر تشخیص داده نشد.');

      List<double>? faceBounds;
      if (portraitCanvas) {
        faceDetector = mlface.FaceDetector(
          options: mlface.FaceDetectorOptions(
            performanceMode: mlface.FaceDetectorMode.accurate,
            enableLandmarks: false,
            enableContours: false,
            enableClassification: false,
            enableTracking: false,
            minFaceSize: .12,
          ),
        );
        final faces = await faceDetector.processImage(mlface.InputImage.fromFilePath(imagePath));
        if (faces.isNotEmpty) {
          final face = faces.reduce((a, b) {
            final aArea = a.boundingBox.width * a.boundingBox.height;
            final bArea = b.boundingBox.width * b.boundingBox.height;
            return aArea >= bArea ? a : b;
          });
          faceBounds = [
            face.boundingBox.left,
            face.boundingBox.top,
            face.boundingBox.right,
            face.boundingBox.bottom,
          ];
        }
      }

      final bytes = await File(imagePath).readAsBytes();
      final result = ImageOperations.applyPersonMask(
        bytes,
        maskWidth: mask.width,
        maskHeight: mask.height,
        confidences: mask.confidences,
        threshold: threshold,
        background: background,
        portraitCanvas: portraitCanvas,
        faceBounds: faceBounds,
      );
      return PortraitSegmentationResult(bytes: result, faceDetected: faceBounds != null);
    } finally {
      await segmenter.close();
      await faceDetector?.close();
    }
  }
}

class OcrTextCleaner {
  static String clean(String input, {required String language}) {
    var value = input
        .replaceAll('\r', '')
        .replaceAll(RegExp(r'[\u200e\u200f\ufeff]'), '')
        .replaceAll(RegExp(r'[ \t]{2,}'), ' ')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();

    final lines = <String>[];
    for (final raw in value.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) {
        if (lines.isNotEmpty && lines.last.isNotEmpty) lines.add('');
        continue;
      }
      final letters = RegExp(r'[A-Za-z\u0600-\u06FF0-9۰-۹]').allMatches(line).length;
      final noise = RegExp(r'[^A-Za-z\u0600-\u06FF0-9۰-۹\s:/.,()\-]').allMatches(line).length;
      if (letters == 0 || (noise > letters && line.length < 8)) continue;
      lines.add(line);
    }
    value = lines.join('\n').replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();

    if (language.contains('fas')) {
      value = value
          .replaceAll('ي', 'ی')
          .replaceAll('ك', 'ک')
          .replaceAll(RegExp(r' +([،؛؟])'), r'$1');
    }
    return value;
  }
}

class ImageOperations {
  static Uint8List applyPersonMask(
    Uint8List bytes, {
    required int maskWidth,
    required int maskHeight,
    required List<double> confidences,
    required double threshold,
    Color? background,
    bool portraitCanvas = false,
    List<double>? faceBounds,
  }) {
    final decoded = im.decodeImage(bytes);
    if (decoded == null) throw const FormatException('تصویر قابل پردازش نیست.');
    var source = im.bakeOrientation(decoded);
    final orientedWidth = source.width;
    final orientedHeight = source.height;
    source = _resizeLarge(source, maxSide: 1800);
    final scaledFaceBounds = faceBounds == null || faceBounds.length != 4
        ? null
        : <double>[
            faceBounds[0] * source.width / math.max(1, orientedWidth),
            faceBounds[1] * source.height / math.max(1, orientedHeight),
            faceBounds[2] * source.width / math.max(1, orientedWidth),
            faceBounds[3] * source.height / math.max(1, orientedHeight),
          ];
    if (maskWidth <= 0 || maskHeight <= 0 || confidences.length < maskWidth * maskHeight) {
      throw const FormatException('ماسک تشخیص سوژه معتبر نیست.');
    }

    double sample(double x, double y) {
      final fx = (x * (maskWidth - 1) / math.max(1, source.width - 1)).clamp(0, maskWidth - 1).toDouble();
      final fy = (y * (maskHeight - 1) / math.max(1, source.height - 1)).clamp(0, maskHeight - 1).toDouble();
      final x0 = fx.floor();
      final y0 = fy.floor();
      final x1 = math.min(maskWidth - 1, x0 + 1);
      final y1 = math.min(maskHeight - 1, y0 + 1);
      final tx = fx - x0;
      final ty = fy - y0;
      final a = confidences[y0 * maskWidth + x0];
      final b = confidences[y0 * maskWidth + x1];
      final c = confidences[y1 * maskWidth + x0];
      final d = confidences[y1 * maskWidth + x1];
      final top = a + (b - a) * tx;
      final bottom = c + (d - c) * tx;
      return top + (bottom - top) * ty;
    }

    final transparent = im.Image(width: source.width, height: source.height, numChannels: 4);
    final low = (threshold - .16).clamp(.02, .94).toDouble();
    final high = (threshold + .12).clamp(.06, .98).toDouble();
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        final confidence = sample(x.toDouble(), y.toDouble());
        final normalized = ((confidence - low) / math.max(.001, high - low)).clamp(0.0, 1.0).toDouble();
        final smooth = normalized * normalized * (3 - 2 * normalized);
        final pixel = source.getPixel(x, y);
        transparent.setPixelRgba(
          x,
          y,
          pixel.r.toInt(),
          pixel.g.toInt(),
          pixel.b.toInt(),
          (smooth * 255).round(),
        );
      }
    }

    if (portraitCanvas) {
      final subjectBounds = _subjectBounds(transparent) ?? _fallbackPortraitBounds(source);
      final cropBounds = scaledFaceBounds != null
          ? _portraitBoundsFromFace(
              source,
              scaledFaceBounds,
              fallback: subjectBounds,
            )
          : _expandRect(
              subjectBounds,
              transparent.width,
              transparent.height,
              horizontalFactor: .13,
              topFactor: .18,
              bottomFactor: .10,
            );
      final subject = im.copyCrop(
        transparent,
        x: cropBounds.left,
        y: cropBounds.top,
        width: cropBounds.width,
        height: cropBounds.height,
      );
      final canvas = im.Image(width: 900, height: 1200, numChannels: 4);
      final fill = background ?? Colors.white;
      im.fill(
        canvas,
        color: im.ColorRgba8((fill.r * 255).round(), (fill.g * 255).round(), (fill.b * 255).round(), 255),
      );
      const targetWidth = 760;
      const targetHeight = 1060;
      final fit = math.min(targetWidth / subject.width, targetHeight / subject.height);
      final width = math.max(1, (subject.width * fit).round());
      final height = math.max(1, (subject.height * fit).round());
      final resized = im.copyResize(subject, width: width, height: height, interpolation: im.Interpolation.cubic);
      final dx = ((canvas.width - width) / 2).round();
      final dy = math.max(34, canvas.height - height - 62);
      im.compositeImage(canvas, resized, dstX: dx, dstY: dy);
      return Uint8List.fromList(im.encodePng(canvas));
    }

    if (background != null) {
      final canvas = im.Image(width: transparent.width, height: transparent.height, numChannels: 4);
      im.fill(
        canvas,
        color: im.ColorRgba8((background.r * 255).round(), (background.g * 255).round(), (background.b * 255).round(), 255),
      );
      im.compositeImage(canvas, transparent);
      return Uint8List.fromList(im.encodePng(canvas));
    }

    return Uint8List.fromList(im.encodePng(transparent));
  }

  static Uint8List prepareOcrImage(
    Uint8List bytes, {
    required OcrProfile profile,
    double deskew = 0,
  }) {
    var source = im.decodeImage(bytes);
    if (source == null) throw const FormatException('تصویر قابل پردازش نیست.');
    source = im.bakeOrientation(source);
    source = _resizeLarge(source, maxSide: 2200);
    if (deskew.abs() >= .1) {
      source = im.copyRotate(source, angle: deskew, interpolation: im.Interpolation.cubic);
    }

    if (profile == OcrProfile.label) {
      final region = _largestLightRegion(source);
      if (region != null) {
        final expanded = _expandRect(region, source.width, source.height, horizontalFactor: .035, topFactor: .035, bottomFactor: .035);
        source = im.copyCrop(source, x: expanded.left, y: expanded.top, width: expanded.width, height: expanded.height);
      }
    }

    source = im.grayscale(source);
    source = im.adjustColor(
      source,
      contrast: switch (profile) {
        OcrProfile.document => 1.42,
        OcrProfile.label => 1.72,
        OcrProfile.receipt => 1.86,
      },
      brightness: switch (profile) {
        OcrProfile.document => 1.03,
        OcrProfile.label => 1.08,
        OcrProfile.receipt => 1.12,
      },
    );
    source = im.gaussianBlur(source, radius: 1);
    final threshold = _otsuThreshold(source);
    final result = im.Image(width: source.width, height: source.height, numChannels: 4);
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        final pixel = source.getPixel(x, y);
        final luma = ((pixel.r + pixel.g + pixel.b) / 3).round();
        final value = luma > threshold ? 255 : 0;
        result.setPixelRgba(x, y, value, value, value, 255);
      }
    }

    final padded = im.Image(width: result.width + 64, height: result.height + 64, numChannels: 4);
    im.fill(padded, color: im.ColorRgba8(255, 255, 255, 255));
    im.compositeImage(padded, result, dstX: 32, dstY: 32);
    return Uint8List.fromList(im.encodePng(padded));
  }

  static int _otsuThreshold(im.Image image) {
    final histogram = List<int>.filled(256, 0);
    for (var y = 0; y < image.height; y++) {
      for (var x = 0; x < image.width; x++) {
        final p = image.getPixel(x, y);
        final luma = ((p.r + p.g + p.b) / 3).round().clamp(0, 255).toInt();
        histogram[luma]++;
      }
    }
    final total = image.width * image.height;
    var sum = 0.0;
    for (var i = 0; i < 256; i++) sum += i * histogram[i];
    var sumBackground = 0.0;
    var weightBackground = 0;
    var maximum = -1.0;
    var threshold = 160;
    for (var i = 0; i < 256; i++) {
      weightBackground += histogram[i];
      if (weightBackground == 0) continue;
      final weightForeground = total - weightBackground;
      if (weightForeground == 0) break;
      sumBackground += i * histogram[i];
      final meanBackground = sumBackground / weightBackground;
      final meanForeground = (sum - sumBackground) / weightForeground;
      final between = weightBackground * weightForeground * math.pow(meanBackground - meanForeground, 2);
      if (between > maximum) {
        maximum = between.toDouble();
        threshold = i;
      }
    }
    return threshold.clamp(85, 225).toInt();
  }

  static _Rect? _largestLightRegion(im.Image source) {
    final detection = _resizeLarge(source, maxSide: 650);
    final width = detection.width;
    final height = detection.height;
    final mask = Uint8List(width * height);
    for (var y = 0; y < height; y++) {
      for (var x = 0; x < width; x++) {
        final p = detection.getPixel(x, y);
        final luma = p.r * .2126 + p.g * .7152 + p.b * .0722;
        final maxChannel = math.max(p.r, math.max(p.g, p.b));
        final minChannel = math.min(p.r, math.min(p.g, p.b));
        final saturation = maxChannel == 0 ? 0 : (maxChannel - minChannel) / maxChannel;
        if (luma > 155 && saturation < .34) mask[y * width + x] = 1;
      }
    }

    final visited = Uint8List(mask.length);
    _Rect? best;
    var bestScore = 0.0;
    final queue = ListQueue<int>();
    for (var seed = 0; seed < mask.length; seed++) {
      if (mask[seed] == 0 || visited[seed] == 1) continue;
      visited[seed] = 1;
      queue.add(seed);
      var minX = width, minY = height, maxX = 0, maxY = 0, area = 0;
      while (queue.isNotEmpty) {
        final idx = queue.removeFirst();
        final x = idx % width;
        final y = idx ~/ width;
        area++;
        minX = math.min(minX, x);
        minY = math.min(minY, y);
        maxX = math.max(maxX, x);
        maxY = math.max(maxY, y);
        const steps = <Offset>[Offset(1, 0), Offset(-1, 0), Offset(0, 1), Offset(0, -1)];
        for (final step in steps) {
          final nx = x + step.dx.toInt();
          final ny = y + step.dy.toInt();
          if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
          final next = ny * width + nx;
          if (mask[next] == 0 || visited[next] == 1) continue;
          visited[next] = 1;
          queue.add(next);
        }
      }
      final boxWidth = maxX - minX + 1;
      final boxHeight = maxY - minY + 1;
      final fraction = area / (width * height);
      final density = area / math.max(1, boxWidth * boxHeight);
      final aspect = boxWidth / math.max(1, boxHeight);
      if (fraction < .018 || density < .35 || aspect < .35 || aspect > 4.8) continue;
      final cx = (minX + maxX) / 2;
      final cy = (minY + maxY) / 2;
      final centerDistance = math.sqrt(math.pow((cx - width / 2) / width, 2) + math.pow((cy - height / 2) / height, 2));
      final score = area * density * (1.25 - math.min(1.0, centerDistance));
      if (score > bestScore) {
        bestScore = score;
        best = _Rect(minX, minY, boxWidth, boxHeight);
      }
    }
    if (best == null) return null;
    final scaleX = source.width / width;
    final scaleY = source.height / height;
    return _Rect(
      (best.left * scaleX).floor(),
      (best.top * scaleY).floor(),
      math.max(1, (best.width * scaleX).ceil()),
      math.max(1, (best.height * scaleY).ceil()),
    );
  }

  static Uint8List applyScanFilter(Uint8List bytes, ScanFilter filter, {int maxSide = 1800, int jpgQuality = 88}) {
    var image = im.decodeImage(bytes);
    if (image == null) throw const FormatException('تصویر قابل پردازش نیست.');
    image = im.bakeOrientation(image);
    image = _resizeLarge(image, maxSide: maxSide);
    switch (filter) {
      case ScanFilter.color:
        image = im.adjustColor(image, contrast: 1.08, saturation: 1.04);
        break;
      case ScanFilter.grayscale:
        image = im.grayscale(image);
        image = im.adjustColor(image, contrast: 1.18);
        break;
      case ScanFilter.document:
        image = im.grayscale(image);
        image = im.adjustColor(image, contrast: 1.55, brightness: 1.06);
        image = _thresholdDocument(image);
        break;
    }
    return Uint8List.fromList(im.encodeJpg(image, quality: jpgQuality));
  }

  static Uint8List extractInk(Uint8List bytes, double threshold, {Color color = Colors.black}) {
    var source = im.decodeImage(bytes);
    if (source == null) throw const FormatException('تصویر قابل پردازش نیست.');
    source = im.bakeOrientation(source);
    source = _resizeLarge(source, maxSide: 1600);
    source = im.grayscale(source);
    source = im.adjustColor(source, contrast: 1.55, brightness: 1.01);
    source = im.gaussianBlur(source, radius: 1);
    final output = im.Image(width: source.width, height: source.height, numChannels: 4);
    final cut = (threshold * 255).round();
    final cr = (color.r * 255).round();
    final cg = (color.g * 255).round();
    final cb = (color.b * 255).round();
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        final pixel = source.getPixel(x, y);
        final light = ((pixel.r + pixel.g + pixel.b) / 3).round();
        final alpha = light >= cut ? 0 : (((cut - light) / math.max(cut, 1)) * 255).round().clamp(0, 255).toInt();
        output.setPixelRgba(x, y, cr, cg, cb, alpha);
      }
    }
    final bounds = _subjectBounds(output);
    if (bounds == null) {
      return Uint8List.fromList(im.encodePng(output));
    }
    final padded = _expandRect(bounds, output.width, output.height, horizontalFactor: .12, topFactor: .12, bottomFactor: .12);
    final cropped = im.copyCrop(output, x: padded.left, y: padded.top, width: padded.width, height: padded.height);
    return Uint8List.fromList(im.encodePng(cropped));
  }

  static Uint8List removeCornerBackground(Uint8List bytes, double tolerance) {
    return removeBackgroundSmart(bytes, tolerance, protectCenter: true);
  }

  static Uint8List removeBackgroundSmart(Uint8List bytes, double tolerance, {bool protectCenter = false}) {
    final decoded = im.decodeImage(bytes);
    if (decoded == null) throw const FormatException('تصویر قابل پردازش نیست.');
    var source = im.bakeOrientation(decoded);
    source = _resizeLarge(source, maxSide: 1600);

    final width = source.width;
    final height = source.height;
    final bg = _estimateBorderBackground(source);
    final baseThreshold = 18 + tolerance * 70;
    final brightThreshold = 26 + tolerance * 90;
    final visited = Uint8List(width * height);
    final bgMask = Uint8List(width * height);
    final queue = ListQueue<int>();

    bool insideProtectedZone(int x, int y) {
      if (!protectCenter) return false;
      final nx = (x - width / 2) / (width * 0.29);
      final ny = (y - height * 0.45) / (height * 0.36);
      return nx * nx + ny * ny <= 1.0;
    }

    void pushIfSeed(int x, int y) {
      final idx = y * width + x;
      if (visited[idx] == 1) return;
      final pixel = source.getPixel(x, y);
      final distance = _colorDistance(pixel, bg);
      final brightness = _brightnessDistance(pixel, bg);
      if (distance <= baseThreshold * 1.3 && brightness <= brightThreshold * 1.4) {
        visited[idx] = 1;
        bgMask[idx] = 1;
        queue.add(idx);
      }
    }

    for (var x = 0; x < width; x++) {
      pushIfSeed(x, 0);
      pushIfSeed(x, height - 1);
    }
    for (var y = 0; y < height; y++) {
      pushIfSeed(0, y);
      pushIfSeed(width - 1, y);
    }

    while (queue.isNotEmpty) {
      final idx = queue.removeFirst();
      final x = idx % width;
      final y = idx ~/ width;
      const neighbors = [
        Offset(1, 0),
        Offset(-1, 0),
        Offset(0, 1),
        Offset(0, -1),
      ];
      for (final step in neighbors) {
        final nx = x + step.dx.toInt();
        final ny = y + step.dy.toInt();
        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
        final nIdx = ny * width + nx;
        if (visited[nIdx] == 1) continue;
        final pixel = source.getPixel(nx, ny);
        final distance = _colorDistance(pixel, bg);
        final brightness = _brightnessDistance(pixel, bg);
        final allowed = insideProtectedZone(nx, ny)
            ? (distance <= baseThreshold * 0.55 && brightness <= brightThreshold * 0.55)
            : (distance <= baseThreshold && brightness <= brightThreshold) ||
                (distance <= baseThreshold * 1.25 && brightness <= brightThreshold * 1.6 && _saturation(pixel) < 0.18);
        if (allowed) {
          visited[nIdx] = 1;
          bgMask[nIdx] = 1;
          queue.add(nIdx);
        }
      }
    }

    final output = im.Image(width: width, height: height, numChannels: 4);
    for (var y = 0; y < height; y++) {
      for (var x = 0; x < width; x++) {
        final idx = y * width + x;
        final pixel = source.getPixel(x, y);
        if (bgMask[idx] == 1) {
          output.setPixelRgba(x, y, pixel.r.toInt(), pixel.g.toInt(), pixel.b.toInt(), 0);
          continue;
        }
        var alpha = 255;
        var bgNeighbors = 0;
        for (var oy = -1; oy <= 1; oy++) {
          for (var ox = -1; ox <= 1; ox++) {
            if (ox == 0 && oy == 0) continue;
            final nx = x + ox;
            final ny = y + oy;
            if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
            if (bgMask[ny * width + nx] == 1) bgNeighbors++;
          }
        }
        if (bgNeighbors > 0) {
          alpha = (255 - bgNeighbors * 18).clamp(110, 255).toInt();
        }
        output.setPixelRgba(x, y, pixel.r.toInt(), pixel.g.toInt(), pixel.b.toInt(), alpha);
      }
    }
    return Uint8List.fromList(im.encodePng(output));
  }

  static Uint8List makePortrait(Uint8List bytes, double tolerance, Color background) {
    var source = im.decodeImage(bytes);
    if (source == null) throw const FormatException('تصویر قابل پردازش نیست.');
    source = im.bakeOrientation(source);
    source = _resizeLarge(source, maxSide: 1700);

    final transparent = im.decodeImage(removeBackgroundSmart(Uint8List.fromList(im.encodePng(source)), tolerance, protectCenter: true))!;
    final box = _subjectBounds(transparent) ?? _fallbackPortraitBounds(source);
    final expanded = _expandRect(box, source.width, source.height, horizontalFactor: 0.17, topFactor: 0.22, bottomFactor: 0.12);
    final subject = im.copyCrop(transparent, x: expanded.left, y: expanded.top, width: expanded.width, height: expanded.height);

    final output = im.Image(width: 900, height: 1200, numChannels: 4);
    final br = (background.r * 255).round();
    final bg = (background.g * 255).round();
    final bb = (background.b * 255).round();
    im.fill(output, color: im.ColorRgba8(br, bg, bb, 255));

    const targetWidth = 760;
    const targetHeight = 1030;
    final fit = math.min(targetWidth / subject.width, targetHeight / subject.height);
    final renderWidth = math.max(1, (subject.width * fit).round());
    final renderHeight = math.max(1, (subject.height * fit).round());
    final resized = im.copyResize(subject, width: renderWidth, height: renderHeight, interpolation: im.Interpolation.cubic);
    final dx = ((output.width - renderWidth) / 2).round();
    final dy = math.max(40, ((output.height - renderHeight) / 2).round() - 30);
    im.compositeImage(output, resized, dstX: dx, dstY: dy, blend: im.BlendMode.direct);
    return Uint8List.fromList(im.encodePng(output));
  }

  static _Rect _portraitBoundsFromFace(
    im.Image image,
    List<double> faceBounds, {
    required _Rect fallback,
  }) {
    if (faceBounds.length != 4) return fallback;
    final left = faceBounds[0];
    final top = faceBounds[1];
    final right = faceBounds[2];
    final bottom = faceBounds[3];
    final faceWidth = math.max(1.0, right - left);
    final faceHeight = math.max(1.0, bottom - top);
    final centerX = (left + right) / 2;

    var cropWidth = math.max(faceWidth * 3.15, fallback.width * .82);
    var cropHeight = cropWidth * 4 / 3;
    final minimumHeight = faceHeight * 4.1;
    if (cropHeight < minimumHeight) {
      cropHeight = minimumHeight;
      cropWidth = cropHeight * 3 / 4;
    }
    cropWidth = math.min(cropWidth, image.width.toDouble());
    cropHeight = math.min(cropHeight, image.height.toDouble());

    final desiredTop = top - faceHeight * .72;
    var cropLeft = centerX - cropWidth / 2;
    var cropTop = desiredTop;
    cropLeft = cropLeft.clamp(0.0, math.max(0.0, image.width - cropWidth)).toDouble();
    cropTop = cropTop.clamp(0.0, math.max(0.0, image.height - cropHeight)).toDouble();

    final rect = _Rect(
      cropLeft.round(),
      cropTop.round(),
      math.max(1, cropWidth.round()),
      math.max(1, cropHeight.round()),
    );
    return _expandRect(rect, image.width, image.height, horizontalFactor: .02, topFactor: .015, bottomFactor: .02);
  }

  static im.Image _resizeLarge(im.Image image, {required int maxSide}) {
    final largest = math.max(image.width, image.height);
    if (largest <= maxSide) return image;
    final scale = maxSide / largest;
    return im.copyResize(
      image,
      width: math.max(1, (image.width * scale).round()),
      height: math.max(1, (image.height * scale).round()),
      interpolation: im.Interpolation.cubic,
    );
  }

  static im.Image _thresholdDocument(im.Image image) {
    final result = im.copyCrop(image, x: 0, y: 0, width: image.width, height: image.height);
    for (var y = 0; y < result.height; y++) {
      for (var x = 0; x < result.width; x++) {
        final p = result.getPixel(x, y);
        final luma = ((p.r * .2126) + (p.g * .7152) + (p.b * .0722)).round();
        final v = luma > 172 ? 255 : (luma < 70 ? 0 : luma);
        result.setPixelRgba(x, y, v, v, v, 255);
      }
    }
    return result;
  }

  static im.Color _estimateBorderBackground(im.Image source) {
    double r = 0, g = 0, b = 0;
    var count = 0;
    final stepX = math.max(1, source.width ~/ 24);
    final stepY = math.max(1, source.height ~/ 24);
    for (var x = 0; x < source.width; x += stepX) {
      final top = source.getPixel(x, 0);
      final bottom = source.getPixel(x, source.height - 1);
      r += top.r + bottom.r;
      g += top.g + bottom.g;
      b += top.b + bottom.b;
      count += 2;
    }
    for (var y = 0; y < source.height; y += stepY) {
      final left = source.getPixel(0, y);
      final right = source.getPixel(source.width - 1, y);
      r += left.r + right.r;
      g += left.g + right.g;
      b += left.b + right.b;
      count += 2;
    }
    return im.ColorRgb8((r / count).round(), (g / count).round(), (b / count).round());
  }

  static double _colorDistance(im.Color pixel, im.Color background) {
    final dr = pixel.r - background.r;
    final dg = pixel.g - background.g;
    final db = pixel.b - background.b;
    return math.sqrt(dr * dr + dg * dg + db * db);
  }

  static double _brightnessDistance(im.Color pixel, im.Color background) {
    final pl = (pixel.r + pixel.g + pixel.b) / 3;
    final bl = (background.r + background.g + background.b) / 3;
    return (pl - bl).abs();
  }

  static double _saturation(im.Color pixel) {
    final maxValue = math.max(pixel.r, math.max(pixel.g, pixel.b));
    final minValue = math.min(pixel.r, math.min(pixel.g, pixel.b));
    if (maxValue == 0) return 0;
    return (maxValue - minValue) / maxValue;
  }

  static _Rect? _subjectBounds(im.Image image) {
    int minX = image.width, minY = image.height, maxX = -1, maxY = -1;
    for (var y = 0; y < image.height; y++) {
      for (var x = 0; x < image.width; x++) {
        if (image.getPixel(x, y).a > 24) {
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX <= minX || maxY <= minY) return null;
    return _Rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
  }

  static _Rect _fallbackPortraitBounds(im.Image image) {
    final width = (image.width * .72).round();
    final height = (width / (3 / 4)).round().clamp(1, image.height).toInt();
    final left = ((image.width - width) / 2).round();
    final top = ((image.height - height) * .18).round().clamp(0, image.height - height).toInt();
    return _Rect(left, top, width, height);
  }

  static _Rect _expandRect(_Rect rect, int maxWidth, int maxHeight, {required double horizontalFactor, required double topFactor, required double bottomFactor}) {
    final left = math.max(0, (rect.left - rect.width * horizontalFactor).floor());
    final right = math.min(maxWidth, (rect.right + rect.width * horizontalFactor).ceil());
    final top = math.max(0, (rect.top - rect.height * topFactor).floor());
    final bottom = math.min(maxHeight, (rect.bottom + rect.height * bottomFactor).ceil());
    return _Rect(left, top, right - left, bottom - top);
  }
}

class _Rect {
  const _Rect(this.left, this.top, this.width, this.height);
  final int left;
  final int top;
  final int width;
  final int height;
  int get right => left + width;
  int get bottom => top + height;
}

class ScanPageData {
  ScanPageData({required this.path, this.filter = ScanFilter.document});
  final String path;
  ScanFilter filter;
}



Uint8List _extractFingerprintJob(Map<String, dynamic> job) {
  return ImageOperations.extractInk(
    job['bytes'] as Uint8List,
    (job['threshold'] as num).toDouble(),
    color: Color((job['color'] as num).toInt()),
  );
}

Uint8List _fallbackPortraitJob(Map<String, dynamic> job) {
  return ImageOperations.makePortrait(
    job['bytes'] as Uint8List,
    (job['tolerance'] as num).toDouble(),
    Color((job['background'] as num).toInt()),
  );
}

Uint8List _fallbackBackgroundJob(Map<String, dynamic> job) {
  return ImageOperations.removeBackgroundSmart(
    job['bytes'] as Uint8List,
    (job['tolerance'] as num).toDouble(),
    protectCenter: true,
  );
}

Uint8List _prepareOcrJob(Map<String, dynamic> job) {
  final profileName = job['profile'] as String;
  return ImageOperations.prepareOcrImage(
    job['bytes'] as Uint8List,
    profile: OcrProfile.values.firstWhere((value) => value.name == profileName, orElse: () => OcrProfile.document),
    deskew: (job['deskew'] as num).toDouble(),
  );
}

Future<Uint8List> buildScannedPdfJob(List<Map<String, String>> jobPages) async {
  final document = pw.Document(compress: true);
  for (final item in jobPages) {
    final path = item['path'];
    final filterName = item['filter'];
    if (path == null || filterName == null) continue;
    final sourceBytes = await File(path).readAsBytes();
    final filter = ScanFilter.values.firstWhere((value) => value.name == filterName, orElse: () => ScanFilter.document);
    final processed = ImageOperations.applyScanFilter(sourceBytes, filter, maxSide: 1400, jpgQuality: 82);
    final memory = pw.MemoryImage(processed);
    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(18),
        build: (_) => pw.Center(child: pw.Image(memory, fit: pw.BoxFit.contain)),
      ),
    );
  }
  return document.save();
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final picker = ImagePicker();
  final pages = <ScanPageData>[];
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('اسکن سند')),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                  children: [
                    const ToolHeader(
                      icon: Icons.document_scanner_outlined,
                      title: 'PDF چندصفحه‌ای',
                      subtitle: 'صفحه‌ها را اضافه کن، فیلتر هر صفحه را انتخاب کن و خروجی را در مقصد دلخواه ذخیره کن.',
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'افزودن صفحه',
                      subtitle: pages.isEmpty ? 'هنوز صفحه‌ای اضافه نشده است.' : '${pages.length} صفحه آماده ساخت PDF است.',
                      child: Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: busy ? null : () => _pick(ImageSource.camera),
                              icon: const Icon(Icons.camera_alt_outlined),
                              label: const Text('دوربین'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: busy ? null : () => _pick(ImageSource.gallery),
                              icon: const Icon(Icons.photo_library_outlined),
                              label: const Text('گالری'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (pages.isEmpty)
                      const ToolPanel(
                        title: 'صفحه‌های سند',
                        child: EmptyState(title: 'صفحه‌ای ثبت نشده', subtitle: 'از دوربین یا گالری اولین صفحه را اضافه کن.'),
                      )
                    else
                      ...pages.asMap().entries.map((entry) => _scanPageCard(entry.key, entry.value)),
                  ],
                ),
              ),
              _pageBottomAction(
                context,
                label: busy ? 'در حال ساخت PDF...' : 'ساخت و ذخیره PDF',
                onPressed: pages.isEmpty || busy ? null : _exportPdf,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _scanPageCard(int index, ScanPageData page) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: ToolPanel(
        title: 'صفحه ${index + 1}',
        trailing: IconButton(
          tooltip: 'حذف صفحه',
          onPressed: busy ? null : () => setState(() => pages.removeAt(index)),
          icon: const Icon(Icons.delete_outline),
        ),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(height: 220, width: double.infinity, child: _filteredPreview(page)),
            ),
            const SizedBox(height: 10),
            SegmentedButton<ScanFilter>(
              segments: const [
                ButtonSegment(value: ScanFilter.color, label: Text('رنگی')),
                ButtonSegment(value: ScanFilter.grayscale, label: Text('خاکستری')),
                ButtonSegment(value: ScanFilter.document, label: Text('سند')),
              ],
              selected: {page.filter},
              onSelectionChanged: busy ? null : (value) => setState(() => page.filter = value.first),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filteredPreview(ScanPageData page) {
    final image = Image.file(File(page.path), fit: BoxFit.contain);
    return switch (page.filter) {
      ScanFilter.color => image,
      ScanFilter.grayscale => ColorFiltered(colorFilter: const ColorFilter.matrix(<double>[.2126, .7152, .0722, 0, 0, .2126, .7152, .0722, 0, 0, .2126, .7152, .0722, 0, 0, 0, 0, 0, 1, 0]), child: image),
      ScanFilter.document => ColorFiltered(colorFilter: const ColorFilter.matrix(<double>[1.5, 0, 0, 0, -45, 0, 1.5, 0, 0, -45, 0, 0, 1.5, 0, -45, 0, 0, 0, 1, 0]), child: image),
    };
  }

  Future<void> _pick(ImageSource sourceType) async {
    if (sourceType == ImageSource.gallery) {
      final files = await picker.pickMultiImage(imageQuality: 82, maxWidth: 2200, maxHeight: 2200);
      if (files.isEmpty) return;
      setState(() => pages.addAll(files.map((file) => ScanPageData(path: file.path))));
      return;
    }
    final file = await picker.pickImage(source: sourceType, imageQuality: 84, maxWidth: 2200, maxHeight: 2200, preferredCameraDevice: CameraDevice.rear);
    if (file == null) return;
    setState(() => pages.add(ScanPageData(path: file.path)));
  }

  Future<void> _exportPdf() async {
    if (pages.isEmpty) return;
    setState(() => busy = true);
    try {
      final jobPages = pages.map((page) => <String, String>{'path': page.path, 'filter': page.filter.name}).toList(growable: false);
      final bytes = await compute(buildScannedPdfJob, jobPages);
      if (!mounted) return;
      await OutputService.save(
        context: context,
        store: widget.store,
        bytes: bytes,
        fileName: 'scan_${DateTime.now().millisecondsSinceEpoch}.pdf',
        title: 'ذخیره PDF چندصفحه‌ای',
        allowGallery: false,
        saveInsideSanadyar: (file) => GeneratedFileSaver.attach(
          context: context,
          store: widget.store,
          file: file,
          type: 'pdf',
          historyTitle: 'اسکن چندصفحه‌ای',
        ),
      );
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ساخت PDF انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}

class InkCanvas extends StatefulWidget {
  const InkCanvas({
    super.key,
    required this.penWidth,
    this.inkColor = Colors.black,
    this.height,
  });

  final double penWidth;
  final Color inkColor;
  final double? height;

  @override
  State<InkCanvas> createState() => InkCanvasState();
}

class InkCanvasState extends State<InkCanvas> {
  final boundaryKey = GlobalKey();
  final strokes = <InkStroke>[];

  bool get isEmpty => strokes.isEmpty;

  void clear() => setState(strokes.clear);

  void undo() {
    if (strokes.isNotEmpty) setState(() => strokes.removeLast());
  }

  void restyle({required Color color, required double width}) {
    if (strokes.isEmpty) return;
    setState(() {
      for (var i = 0; i < strokes.length; i++) {
        final stroke = strokes[i];
        strokes[i] = InkStroke(points: List<Offset>.from(stroke.points), color: color, width: width);
      }
    });
  }

  Future<Uint8List> exportPng() async {
    if (strokes.isEmpty) throw StateError('امضایی برای ذخیره وجود ندارد.');
    final bounds = calculateInkStrokeBounds(strokes);
    const pixelRatio = 3.0;
    final logicalWidth = math.max(1, bounds.width.ceil());
    final logicalHeight = math.max(1, bounds.height.ceil());
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.scale(pixelRatio);
    canvas.translate(-bounds.left, -bounds.top);
    paintInkStrokes(canvas, strokes);
    final picture = recorder.endRecording();
    final image = await picture.toImage(
      math.max(1, (logicalWidth * pixelRatio).ceil()),
      math.max(1, (logicalHeight * pixelRatio).ceil()),
    );
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('خروجی امضا ساخته نشد.');
    return data.buffer.asUint8List();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final canvas = Container(
      decoration: BoxDecoration(
        color: colors.surface,
        border: Border.all(color: colors.outlineVariant, width: 1.2),
        borderRadius: BorderRadius.circular(20),
      ),
      clipBehavior: Clip.antiAlias,
      child: RepaintBoundary(
        key: boundaryKey,
        child: ColoredBox(
          color: Colors.transparent,
          child: CustomPaint(
            painter: InkStrokePainter(strokes: strokes),
            child: strokes.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.gesture, size: 42, color: colors.outline),
                        const SizedBox(height: 8),
                        Text('اینجا امضا کن', style: TextStyle(color: colors.onSurfaceVariant, fontWeight: FontWeight.w700)),
                      ],
                    ),
                  )
                : null,
          ),
        ),
      ),
    );

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      dragStartBehavior: DragStartBehavior.down,
      onPanStart: (details) {
        setState(() => strokes.add(InkStroke(points: [details.localPosition], color: widget.inkColor, width: widget.penWidth)));
      },
      onPanUpdate: (details) {
        if (strokes.isEmpty) return;
        final point = details.localPosition;
        final box = context.findRenderObject() as RenderBox?;
        if (box == null || point.dx < 0 || point.dy < 0 || point.dx > box.size.width || point.dy > box.size.height) return;
        setState(() => strokes.last.points.add(point));
      },
      child: widget.height == null ? SizedBox.expand(child: canvas) : SizedBox(height: widget.height, width: double.infinity, child: canvas),
    );
  }
}

class InkStrokePainter extends CustomPainter {
  const InkStrokePainter({required this.strokes});
  final List<InkStroke> strokes;

  @override
  void paint(Canvas canvas, Size size) => paintInkStrokes(canvas, strokes);

  @override
  bool shouldRepaint(covariant InkStrokePainter oldDelegate) => true;
}

class PenSettingsResult {
  const PenSettingsResult({required this.tool, required this.color, required this.thickness});
  final String tool;
  final Color color;
  final double thickness;
}

class PenSettingsSheet extends StatefulWidget {
  const PenSettingsSheet({super.key, required this.initialTool, required this.initialColor, required this.initialThickness});
  final String initialTool;
  final Color initialColor;
  final double initialThickness;

  @override
  State<PenSettingsSheet> createState() => _PenSettingsSheetState();
}

class _PenSettingsSheetState extends State<PenSettingsSheet> {
  late String tool;
  late Color color;
  late double thickness;

  @override
  void initState() {
    super.initState();
    tool = widget.initialTool;
    color = widget.initialColor;
    thickness = widget.initialThickness;
  }

  double get effectiveThickness => switch (tool) {
        'fineliner' => thickness * .72,
        'marker' => thickness * 1.45,
        'brush' => thickness * 1.18,
        _ => thickness,
      };

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: SafeArea(
          top: false,
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.viewInsetsOf(context).bottom),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text('تنظیم قلم امضا', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                const SizedBox(height: 14),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'pen', label: Text('خودکار')),
                    ButtonSegment(value: 'fineliner', label: Text('روان‌نویس')),
                    ButtonSegment(value: 'marker', label: Text('ماژیک')),
                    ButtonSegment(value: 'brush', label: Text('قلم‌مو')),
                  ],
                  selected: {tool},
                  onSelectionChanged: (value) => setState(() => tool = value.first),
                ),
                const SizedBox(height: 18),
                const Text('رنگ امضا', style: TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                ColorDotPicker(
                  colors: const [Color(0xFF15264D), Colors.black, Color(0xFF2157D6), Color(0xFFC62828), Color(0xFF1B8E5A)],
                  selected: color,
                  onChanged: (value) => setState(() => color = value),
                ),
                const SizedBox(height: 16),
                CompactSlider(
                  label: 'ضخامت',
                  valueLabel: effectiveThickness.toStringAsFixed(1),
                  value: thickness,
                  min: 1,
                  max: 9,
                  onChanged: (value) => setState(() => thickness = value),
                ),
                const SizedBox(height: 14),
                FilledButton.icon(
                  onPressed: () => Navigator.pop(context, PenSettingsResult(tool: tool, color: color, thickness: thickness)),
                  icon: const Icon(Icons.check),
                  label: const Text('اعمال تنظیمات'),
                ),
              ],
            ),
          ),
        ),
      );
}

class SignatureStudioScreen extends StatefulWidget {
  const SignatureStudioScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<SignatureStudioScreen> createState() => _SignatureStudioScreenState();
}

class _SignatureStudioScreenState extends State<SignatureStudioScreen> {
  final padKey = GlobalKey<InkCanvasState>();
  double thickness = 3.2;
  Color color = const Color(0xFF15264D);
  String tool = 'pen';
  bool busy = false;

  double get _effectiveThickness => switch (tool) {
        'fineliner' => thickness * .72,
        'marker' => thickness * 1.45,
        'brush' => thickness * 1.18,
        _ => thickness,
      };

  Color get _effectiveColor => color.withValues(
        alpha: switch (tool) {
          'marker' => .82,
          'brush' => .92,
          _ => 1.0,
        },
      );

  String get _toolLabel => switch (tool) {
        'fineliner' => 'روان‌نویس',
        'marker' => 'ماژیک',
        'brush' => 'قلم‌مو',
        _ => 'خودکار',
      };

  void _applyStyle() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      padKey.currentState?.restyle(color: _effectiveColor, width: _effectiveThickness);
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final signatures = widget.store.assets.where((asset) => asset.kind == AssetKind.signature).toList();
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ساخت امضا'),
          actions: [
            IconButton(
              tooltip: 'تنظیم قلم',
              onPressed: _showPenSettings,
              icon: const Icon(Icons.tune),
            ),
            IconButton(
              tooltip: 'امضاهای ذخیره‌شده',
              onPressed: () => _showSavedSignatures(signatures),
              icon: Badge(label: Text('${signatures.length}'), child: const Icon(Icons.collections_bookmark_outlined)),
            ),
            const SizedBox(width: 6),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 10),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(17),
                  border: Border.all(color: colors.outlineVariant),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
                      child: const Icon(Icons.draw_outlined, size: 18, color: Colors.white),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_toolLabel, style: const TextStyle(fontWeight: FontWeight.w900)),
                          Text('ضخامت ${_effectiveThickness.toStringAsFixed(1)}', style: TextStyle(fontSize: 12, color: colors.onSurfaceVariant)),
                        ],
                      ),
                    ),
                    TextButton.icon(onPressed: _showPenSettings, icon: const Icon(Icons.tune, size: 18), label: const Text('تنظیمات')),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: InkCanvas(key: padKey, penWidth: _effectiveThickness, inkColor: _effectiveColor),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
                decoration: BoxDecoration(color: colors.surface, border: Border(top: BorderSide(color: colors.outlineVariant))),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => padKey.currentState?.undo(),
                            icon: const Icon(Icons.undo),
                            label: const Text('برگشت'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => padKey.currentState?.clear(),
                            icon: const Icon(Icons.delete_sweep_outlined),
                            label: const Text('پاک‌کردن'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: busy ? null : _save,
                      icon: busy
                          ? const SizedBox.square(dimension: 19, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.save_outlined),
                      label: const Text('ذخیره و خروجی امضا'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showPenSettings() async {
    final result = await showModalBottomSheet<PenSettingsResult>(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (_) => PenSettingsSheet(
        initialTool: tool,
        initialColor: color,
        initialThickness: thickness,
      ),
    );
    if (!mounted || result == null) return;
    setState(() {
      tool = result.tool;
      color = result.color;
      thickness = result.thickness;
    });
    _applyStyle();
  }

  Future<void> _showSavedSignatures(List<SavedAsset> signatures) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            SectionTitle(title: 'امضاهای ذخیره‌شده', subtitle: '${signatures.length} امضا'),
            if (signatures.isEmpty) const EmptyState(title: 'امضایی ذخیره نشده', subtitle: 'امضای خود را رسم و داخل سندیار ذخیره کن.'),
            ...signatures.map((asset) => AssetListTile(store: widget.store, asset: asset)),
          ],
        ),
      ),
    );
  }

  Future<void> _save() async {
    final pad = padKey.currentState;
    if (pad == null || pad.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا امضا را رسم کن.')));
      return;
    }
    final name = await TextInputDialog.show(context, title: 'نام امضا', hint: 'مثلاً امضای اصلی');
    if (name == null) return;
    setState(() => busy = true);
    try {
      final bytes = await pad.exportPng();
      final destination = await OutputService.save(
        context: context,
        store: widget.store,
        bytes: bytes,
        fileName: 'signature_${DateTime.now().millisecondsSinceEpoch}.png',
        title: 'ذخیره امضا',
        allowGallery: true,
        saveInsideSanadyar: (file) async {
          await widget.store.addAsset(
            SavedAsset(
              id: const Uuid().v4(),
              name: name.trim().isEmpty ? 'امضا' : name.trim(),
              path: file.path,
              kind: AssetKind.signature,
              createdAt: DateTime.now(),
            ),
          );
          return true;
        },
      );
      if (destination != null && mounted) pad.clear();
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}

class FingerprintStudioScreen extends StatefulWidget {
  const FingerprintStudioScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<FingerprintStudioScreen> createState() => _FingerprintStudioScreenState();
}

class _FingerprintStudioScreenState extends State<FingerprintStudioScreen> {
  final picker = ImagePicker();
  XFile? source;
  Uint8List? preview;
  double threshold = .72;
  Color inkColor = Colors.black;
  bool busy = false;
  bool advancedOpen = false;

  @override
  Widget build(BuildContext context) {
    final fingerprints = widget.store.assets.where((asset) => asset.kind == AssetKind.fingerprint).toList();
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('اثر انگشت'),
          actions: [
            IconButton(
              onPressed: () => _showSavedFingerprints(fingerprints),
              icon: Badge(label: Text('${fingerprints.length}'), child: const Icon(Icons.collections_bookmark_outlined)),
            ),
            const SizedBox(width: 6),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                  children: [
                    const ToolHeader(
                      icon: Icons.fingerprint,
                      title: 'استخراج اثر انگشت',
                      subtitle: 'تصویر اثر روی کاغذ روشن را انتخاب کن؛ خروجی تمیز و شفاف ساخته می‌شود.',
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'تصویر ورودی',
                      child: FilledButton.icon(
                        onPressed: busy ? null : _pickFromGallery,
                        icon: const Icon(Icons.photo_library_outlined),
                        label: Text(source == null ? 'انتخاب از گالری' : 'تغییر تصویر'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'پیش‌نمایش خروجی',
                      child: Container(
                        height: 310,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: busy
                            ? const Center(child: CircularProgressIndicator())
                            : preview != null
                                ? Image.memory(preview!, fit: BoxFit.contain)
                                : const EmptyState(title: 'خروجی آماده نیست', subtitle: 'ابتدا تصویر اثر انگشت را انتخاب کن.'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'ظاهر خروجی',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          const Text('رنگ اثر', style: TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 10),
                          ColorDotPicker(
                            colors: const [Colors.black, Color(0xFF2157D6), Color(0xFFC62828), Color(0xFF1B8E5A)],
                            selected: inkColor,
                            onChanged: (value) {
                              setState(() => inkColor = value);
                              _refreshPreview();
                            },
                          ),
                          const SizedBox(height: 10),
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('تنظیم دقیق استخراج', style: TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text('حساسیت ${(threshold * 100).round()}٪'),
                            trailing: IconButton(
                              onPressed: () => setState(() => advancedOpen = !advancedOpen),
                              icon: Icon(advancedOpen ? Icons.expand_less : Icons.tune),
                            ),
                          ),
                          if (advancedOpen)
                            CompactSlider(
                              label: 'حساسیت',
                              valueLabel: '${(threshold * 100).round()}٪',
                              value: threshold,
                              min: .35,
                              max: .92,
                              onChanged: (value) => setState(() => threshold = value),
                            ),
                          if (advancedOpen)
                            Align(
                              alignment: Alignment.centerLeft,
                              child: TextButton.icon(onPressed: _refreshPreview, icon: const Icon(Icons.refresh), label: const Text('پردازش مجدد')),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              _bottomAction(
                context,
                label: 'ذخیره و خروجی اثر انگشت',
                icon: Icons.save_outlined,
                onPressed: preview == null || busy ? null : _save,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bottomAction(BuildContext context, {required String label, required IconData icon, required VoidCallback? onPressed}) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
      decoration: BoxDecoration(color: colors.surface, border: Border(top: BorderSide(color: colors.outlineVariant))),
      child: FilledButton.icon(onPressed: onPressed, icon: Icon(icon), label: Text(label)),
    );
  }

  Future<void> _pickFromGallery() async {
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 96, maxWidth: 2000, maxHeight: 2000);
    if (file == null) return;
    source = file;
    await _refreshPreview();
  }

  Future<void> _refreshPreview() async {
    if (source == null || busy) return;
    setState(() => busy = true);
    try {
      final result = await compute(
        _extractFingerprintJob,
        <String, dynamic>{
          'bytes': await source!.readAsBytes(),
          'threshold': threshold,
          'color': inkColor.toARGB32(),
        },
      );
      if (mounted) setState(() => preview = result);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('پردازش اثر انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final bytes = preview;
    if (bytes == null) return;
    final name = await TextInputDialog.show(context, title: 'نام اثر انگشت', hint: 'مثلاً انگشت اشاره');
    if (name == null) return;
    await OutputService.save(
      context: context,
      store: widget.store,
      bytes: bytes,
      fileName: 'fingerprint_${DateTime.now().millisecondsSinceEpoch}.png',
      title: 'ذخیره اثر انگشت',
      allowGallery: true,
      saveInsideSanadyar: (file) async {
        await widget.store.addAsset(
          SavedAsset(
            id: const Uuid().v4(),
            name: name.trim().isEmpty ? 'اثر انگشت' : name.trim(),
            path: file.path,
            kind: AssetKind.fingerprint,
            createdAt: DateTime.now(),
          ),
        );
        return true;
      },
    );
  }

  Future<void> _showSavedFingerprints(List<SavedAsset> assets) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
          children: [
            SectionTitle(title: 'اثرهای ذخیره‌شده', subtitle: '${assets.length} مورد'),
            if (assets.isEmpty) const EmptyState(title: 'اثری ذخیره نشده', subtitle: 'خروجی را داخل سندیار ذخیره کن.'),
            ...assets.map((asset) => AssetListTile(store: widget.store, asset: asset)),
          ],
        ),
      ),
    );
  }
}

class PortraitPhotoScreen extends StatefulWidget {
  const PortraitPhotoScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<PortraitPhotoScreen> createState() => _PortraitPhotoScreenState();
}

class _PortraitPhotoScreenState extends State<PortraitPhotoScreen> {
  final picker = ImagePicker();
  XFile? source;
  Uint8List? result;
  Color background = Colors.white;
  double confidence = .48;
  bool busy = false;
  bool advancedOpen = false;
  bool faceDetected = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('عکس ۳×۴')),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                  children: [
                    const ToolHeader(
                      icon: Icons.badge_outlined,
                      title: 'عکس پرسنلی هوشمند',
                      subtitle: 'تشخیص سوژه انسانی با ML Kit انجام می‌شود تا صورت، مو، گردن و لباس بهتر حفظ شوند.',
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'انتخاب تصویر',
                      child: Row(
                        children: [
                          Expanded(child: FilledButton.icon(onPressed: busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('دوربین'))),
                          const SizedBox(width: 8),
                          Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('گالری'))),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'پیش‌نمایش ۹۰۰×۱۲۰۰',
                      child: Column(
                        children: [
                          Center(
                            child: Container(
                              width: 250,
                              decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(18), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
                              child: AspectRatio(
                                aspectRatio: 3 / 4,
                                child: busy
                                    ? const Center(child: CircularProgressIndicator())
                                    : result != null
                                        ? ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.memory(result!, fit: BoxFit.cover))
                                        : source != null
                                            ? ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(File(source!.path), fit: BoxFit.cover))
                                            : const Center(child: Icon(Icons.person_outline, size: 70)),
                              ),
                            ),
                          ),
                          if (result != null) ...[
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                              decoration: BoxDecoration(
                                color: faceDetected
                                    ? Theme.of(context).colorScheme.primaryContainer
                                    : Theme.of(context).colorScheme.errorContainer,
                                borderRadius: BorderRadius.circular(99),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    faceDetected ? Icons.face_retouching_natural : Icons.warning_amber_rounded,
                                    size: 18,
                                    color: faceDetected
                                        ? Theme.of(context).colorScheme.onPrimaryContainer
                                        : Theme.of(context).colorScheme.onErrorContainer,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    faceDetected ? 'چهره تشخیص داده شد و قاب‌بندی بر اساس صورت انجام شد' : 'چهره تشخیص داده نشد؛ قاب‌بندی بر اساس سوژه انجام شد',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      color: faceDetected
                                          ? Theme.of(context).colorScheme.onPrimaryContainer
                                          : Theme.of(context).colorScheme.onErrorContainer,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'پس‌زمینه',
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ColorDotPicker(
                            colors: const [Colors.white, Color(0xFFD9EDFF), Color(0xFFE8E8E8)],
                            selected: background,
                            onChanged: (value) {
                              setState(() => background = value);
                              if (source != null) _process();
                            },
                          ),
                          const SizedBox(height: 8),
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('تنظیم تشخیص سوژه', style: TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text('دقت مرز ${(confidence * 100).round()}٪'),
                            trailing: IconButton(onPressed: () => setState(() => advancedOpen = !advancedOpen), icon: Icon(advancedOpen ? Icons.expand_less : Icons.tune)),
                          ),
                          if (advancedOpen)
                            CompactSlider(
                              label: 'حفظ لبه مو و لباس',
                              valueLabel: '${(confidence * 100).round()}٪',
                              value: confidence,
                              min: .30,
                              max: .72,
                              onChanged: (value) => setState(() => confidence = value),
                            ),
                          if (advancedOpen)
                            Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: source == null ? null : _process, icon: const Icon(Icons.refresh), label: const Text('پردازش مجدد'))),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              _pageBottomAction(
                context,
                label: 'ذخیره و خروجی عکس ۳×۴',
                onPressed: result == null || busy ? null : _save,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pick(ImageSource imageSource) async {
    final file = await picker.pickImage(source: imageSource, imageQuality: 98, maxWidth: 2400, maxHeight: 2400, preferredCameraDevice: CameraDevice.front);
    if (file == null) return;
    setState(() {
      source = file;
      result = null;
      faceDetected = false;
    });
    await _process();
  }

  Future<void> _process() async {
    if (source == null || busy) return;
    setState(() => busy = true);
    try {
      Uint8List bytes;
      var detectedFace = false;
      try {
        final segmented = await PortraitSegmentationService.removePersonBackground(
          imagePath: source!.path,
          threshold: confidence,
          background: background,
          portraitCanvas: true,
        );
        bytes = segmented.bytes;
        detectedFace = segmented.faceDetected;
      } catch (_) {
        bytes = await compute(
          _fallbackPortraitJob,
          <String, dynamic>{'bytes': await source!.readAsBytes(), 'tolerance': .22, 'background': background.toARGB32()},
        );
      }
      if (mounted) {
        setState(() {
          result = bytes;
          faceDetected = detectedFace;
        });
      }
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ساخت عکس انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final bytes = result;
    if (bytes == null) return;
    final name = await TextInputDialog.show(context, title: 'نام عکس', hint: 'مثلاً عکس پرسنلی');
    if (name == null) return;
    await OutputService.save(
      context: context,
      store: widget.store,
      bytes: bytes,
      fileName: 'portrait_${DateTime.now().millisecondsSinceEpoch}.png',
      title: 'ذخیره عکس ۳×۴',
      allowGallery: true,
      saveInsideSanadyar: (file) async {
        await widget.store.addAsset(
          SavedAsset(
            id: const Uuid().v4(),
            name: name.trim().isEmpty ? 'عکس ۳×۴' : name.trim(),
            path: file.path,
            kind: AssetKind.portrait,
            createdAt: DateTime.now(),
          ),
        );
        return true;
      },
    );
  }
}

class OcrScreen extends StatefulWidget {
  const OcrScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<OcrScreen> createState() => _OcrScreenState();
}

class _OcrScreenState extends State<OcrScreen> {
  final picker = ImagePicker();
  final textController = TextEditingController();
  XFile? source;
  Uint8List? processedPreview;
  String language = 'fas+eng';
  OcrProfile profile = OcrProfile.label;
  double deskew = 0;
  bool busy = false;
  bool advancedOpen = false;
  bool ocrFailed = false;
  String ocrStatus = 'تصویر را انتخاب کن و سپس استخراج متن را بزن.';

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تشخیص متن OCR')),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                  children: [
                    const ToolHeader(
                      icon: Icons.text_snippet_outlined,
                      title: 'OCR حرفه‌ای آفلاین',
                      subtitle: 'چند مرحله تشخیص روی تصویر پردازش‌شده و نسخه اصلی اجرا می‌شود تا نتیجه خالی نماند.',
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'تصویر و حالت تشخیص',
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(child: FilledButton.icon(onPressed: busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('دوربین'))),
                              const SizedBox(width: 8),
                              Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('گالری'))),
                            ],
                          ),
                          const SizedBox(height: 12),
                          DropdownButtonFormField<OcrProfile>(
                            initialValue: profile,
                            decoration: const InputDecoration(labelText: 'نوع تصویر', isDense: true, border: OutlineInputBorder()),
                            items: const [
                              DropdownMenuItem(value: OcrProfile.document, child: Text('سند و متن چاپی')),
                              DropdownMenuItem(value: OcrProfile.label, child: Text('برچسب و لیبل')),
                              DropdownMenuItem(value: OcrProfile.receipt, child: Text('رسید و متن ریز')),
                            ],
                            onChanged: busy ? null : (value) => setState(() => profile = value ?? profile),
                          ),
                          const SizedBox(height: 10),
                          SegmentedButton<String>(
                            segments: const [
                              ButtonSegment(value: 'fas', label: Text('فارسی')),
                              ButtonSegment(value: 'eng', label: Text('English')),
                              ButtonSegment(value: 'fas+eng', label: Text('هر دو')),
                            ],
                            selected: {language},
                            onSelectionChanged: busy ? null : (value) => setState(() => language = value.first),
                          ),
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('تنظیمات پیشرفته', style: TextStyle(fontWeight: FontWeight.w700)),
                            subtitle: Text('اصلاح زاویه ${deskew.toStringAsFixed(1)} درجه'),
                            trailing: IconButton(onPressed: busy ? null : () => setState(() => advancedOpen = !advancedOpen), icon: Icon(advancedOpen ? Icons.expand_less : Icons.tune)),
                          ),
                          if (advancedOpen)
                            CompactSlider(
                              label: 'اصلاح زاویه تصویر',
                              valueLabel: '${deskew.toStringAsFixed(1)}°',
                              value: deskew,
                              min: -6,
                              max: 6,
                              divisions: 48,
                              onChanged: (value) => setState(() => deskew = value),
                            ),
                        ],
                      ),
                    ),
                    if (source != null) ...[
                      const SizedBox(height: 12),
                      ToolPanel(
                        title: processedPreview == null ? 'تصویر ورودی' : 'تصویر آماده‌شده برای OCR',
                        subtitle: processedPreview == null ? 'پس از استخراج، نسخه پردازش‌شده نمایش داده می‌شود.' : 'موتور OCR این تصویر و نسخه اصلی را برای بهترین نتیجه بررسی کرده است.',
                        child: Container(
                          height: 250,
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                          child: processedPreview != null
                              ? Image.memory(processedPreview!, fit: BoxFit.contain)
                              : Image.file(File(source!.path), fit: BoxFit.contain),
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: source == null || busy ? null : _recognize,
                      icon: busy ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.document_scanner_outlined),
                      label: Text(busy ? 'در حال اجرای موتور OCR...' : 'پردازش و استخراج متن'),
                    ),
                    const SizedBox(height: 10),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: ocrFailed ? colors.errorContainer : colors.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        children: [
                          if (busy)
                            const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2))
                          else
                            Icon(ocrFailed ? Icons.error_outline : (textController.text.trim().isNotEmpty ? Icons.check_circle_outline : Icons.info_outline), color: ocrFailed ? colors.error : colors.primary),
                          const SizedBox(width: 9),
                          Expanded(child: Text(ocrStatus, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, height: 1.4))),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'متن استخراج‌شده',
                      trailing: IconButton(
                        tooltip: 'کپی',
                        onPressed: textController.text.isEmpty ? null : _copyText,
                        icon: const Icon(Icons.copy_outlined),
                      ),
                      child: TextField(
                        controller: textController,
                        minLines: 8,
                        maxLines: 18,
                        textDirection: language == 'eng' ? ui.TextDirection.ltr : ui.TextDirection.rtl,
                        onChanged: (_) => setState(() {}),
                        decoration: const InputDecoration(hintText: 'نتیجه OCR اینجا نمایش داده می‌شود.', border: OutlineInputBorder()),
                      ),
                    ),
                  ],
                ),
              ),
              _pageBottomAction(
                context,
                label: 'ذخیره متن استخراج‌شده',
                onPressed: textController.text.trim().isEmpty || busy ? null : _saveText,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pick(ImageSource sourceType) async {
    final file = await picker.pickImage(source: sourceType, imageQuality: 98, maxWidth: 2800, maxHeight: 2800);
    if (file == null) return;
    setState(() {
      source = file;
      processedPreview = null;
      textController.clear();
      ocrFailed = false;
      ocrStatus = 'تصویر آماده است؛ دکمه پردازش و استخراج متن را بزن.';
    });
  }

  List<String> get _pageSegmentationCandidates => switch (profile) {
        OcrProfile.document => [PageSegmentationMode.auto, PageSegmentationMode.singleBlock, PageSegmentationMode.sparseText],
        OcrProfile.label => [PageSegmentationMode.sparseText, PageSegmentationMode.auto, PageSegmentationMode.singleBlock],
        OcrProfile.receipt => [PageSegmentationMode.singleBlock, PageSegmentationMode.auto, PageSegmentationMode.sparseText],
      };

  int _textScore(String text) {
    final meaningful = RegExp(r'[A-Za-zآ-ی0-9۰-۹]').allMatches(text).length;
    final lines = text.split('\n').where((line) => line.trim().length >= 2).length;
    return meaningful + lines * 3;
  }

  Future<String> _runOcrPass(String path, {required String passLanguage, required String pageSegMode}) async {
    final config = OCRConfig(
      language: passLanguage,
      engine: OCREngine.tesseract,
      options: <String, dynamic>{
        TesseractConfig.preserveInterwordSpaces: '1',
        TesseractConfig.pageSegMode: pageSegMode,
        'user_defined_dpi': '300',
        'textord_min_linesize': profile == OcrProfile.receipt ? '1.5' : '2.0',
      },
    );
    return TesseractOcr.extractText(path, config: config);
  }

  Future<String> _recognizeBest(String preparedPath, String originalPath) async {
    var best = '';
    var bestScore = 0;
    final errors = <String>[];
    final segmentation = _pageSegmentationCandidates;

    Future<void> attempt(String path, String passLanguage, String psm, String label) async {
      if (mounted) setState(() => ocrStatus = label);
      try {
        final raw = await _runOcrPass(path, passLanguage: passLanguage, pageSegMode: psm);
        final cleaned = OcrTextCleaner.clean(raw, language: passLanguage);
        final score = _textScore(cleaned);
        if (score > bestScore) {
          best = cleaned;
          bestScore = score;
        }
      } catch (error) {
        errors.add(error.toString());
      }
    }

    await attempt(preparedPath, language, segmentation.first, 'مرحله ۱ از ۴: تشخیص متن از تصویر پردازش‌شده');
    if (bestScore >= 18) return best;

    await attempt(preparedPath, language, segmentation[1], 'مرحله ۲ از ۴: تغییر روش خواندن خطوط');
    if (bestScore >= 18) return best;

    await attempt(originalPath, language, segmentation.first, 'مرحله ۳ از ۴: بررسی نسخه اصلی تصویر');
    if (bestScore >= 18) return best;

    if (language == 'fas+eng') {
      await attempt(preparedPath, 'fas', segmentation.first, 'مرحله ۴ از ۴: تشخیص اختصاصی متن فارسی');
      final persian = best;
      final persianScore = bestScore;
      await attempt(preparedPath, 'eng', segmentation.first, 'مرحله ۴ از ۴: تشخیص اختصاصی اعداد و انگلیسی');
      if (persianScore > 0 && persian.isNotEmpty && best != persian && !best.contains(persian)) {
        final combined = OcrTextCleaner.clean('$persian\n$best', language: language);
        if (_textScore(combined) > bestScore) best = combined;
      }
    } else {
      await attempt(preparedPath, language, segmentation.last, 'مرحله ۴ از ۴: آخرین روش تشخیص متن');
    }

    if (best.trim().isEmpty || bestScore < 3) {
      final detail = errors.isEmpty ? '' : ' جزئیات: ${errors.first}';
      throw StateError('موتور OCR اجرا شد اما متن قابل‌اعتمادی پیدا نشد.$detail');
    }
    return best;
  }

  Future<void> _recognize() async {
    if (source == null) return;
    setState(() {
      busy = true;
      ocrFailed = false;
      ocrStatus = 'در حال آماده‌سازی تصویر...';
    });
    File? temporary;
    try {
      final prepared = await compute(
        _prepareOcrJob,
        <String, dynamic>{'bytes': await source!.readAsBytes(), 'profile': profile.name, 'deskew': deskew},
      );
      final directory = await getTemporaryDirectory();
      temporary = File('${directory.path}/ocr_prepared_${DateTime.now().microsecondsSinceEpoch}.png');
      await temporary.writeAsBytes(prepared, flush: true);
      final cleaned = await _recognizeBest(temporary.path, source!.path);
      if (!mounted) return;
      setState(() {
        processedPreview = prepared;
        textController.text = cleaned;
        ocrStatus = 'استخراج متن با موفقیت انجام شد؛ ${cleaned.length} نویسه شناسایی شد.';
        ocrFailed = false;
      });
    } catch (error) {
      if (mounted) {
        setState(() {
          ocrFailed = true;
          ocrStatus = 'استخراج متن انجام نشد. تصویر واضح‌تر انتخاب کن یا نوع تصویر و زبان را تغییر بده.';
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('OCR انجام نشد: $error')));
      }
    } finally {
      if (temporary != null && await temporary.exists()) await temporary.delete();
      if (mounted) setState(() => busy = false);
    }
  }

  void _copyText() {
    Clipboard.setData(ClipboardData(text: textController.text));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('متن کپی شد.')));
  }

  Future<void> _saveText() async {
    final bytes = Uint8List.fromList(utf8.encode(textController.text.trim()));
    await OutputService.save(
      context: context,
      store: widget.store,
      bytes: bytes,
      fileName: 'ocr_${DateTime.now().millisecondsSinceEpoch}.txt',
      title: 'ذخیره متن OCR',
      allowGallery: false,
      saveInsideSanadyar: (file) => GeneratedFileSaver.attach(
        context: context,
        store: widget.store,
        file: file,
        type: 'text',
        historyTitle: 'ذخیره متن OCR',
      ),
    );
  }
}

class BackgroundRemovalScreen extends StatefulWidget {
  const BackgroundRemovalScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<BackgroundRemovalScreen> createState() => _BackgroundRemovalScreenState();
}

class _BackgroundRemovalScreenState extends State<BackgroundRemovalScreen> {
  final picker = ImagePicker();
  XFile? source;
  Uint8List? result;
  double confidence = .46;
  bool busy = false;
  bool advancedOpen = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حذف پس‌زمینه')),
        body: SafeArea(
          child: Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                  children: [
                    const ToolHeader(
                      icon: Icons.layers_clear_outlined,
                      title: 'جداسازی هوشمند سوژه',
                      subtitle: 'مدل تشخیص انسان برای حفظ چهره، مو، گردن و لباس استفاده می‌شود.',
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'انتخاب تصویر',
                      child: Row(
                        children: [
                          Expanded(child: FilledButton.icon(onPressed: busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('دوربین'))),
                          const SizedBox(width: 8),
                          Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('گالری'))),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'پیش‌نمایش PNG شفاف',
                      child: Container(
                        height: 360,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                        ),
                        child: TransparencyGrid(
                          child: busy
                              ? const Center(child: CircularProgressIndicator())
                              : result != null
                                  ? Image.memory(result!, fit: BoxFit.contain)
                                  : source != null
                                      ? Image.file(File(source!.path), fit: BoxFit.contain)
                                      : const Center(child: Icon(Icons.person_outline, size: 72)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ToolPanel(
                      title: 'تنظیم مرز سوژه',
                      subtitle: 'فقط وقتی بخشی از مو یا لباس حذف شد این مقدار را تغییر بده.',
                      trailing: IconButton(onPressed: () => setState(() => advancedOpen = !advancedOpen), icon: Icon(advancedOpen ? Icons.expand_less : Icons.tune)),
                      child: advancedOpen
                          ? Column(
                              children: [
                                CompactSlider(
                                  label: 'حفظ جزئیات سوژه',
                                  valueLabel: '${(confidence * 100).round()}٪',
                                  value: confidence,
                                  min: .28,
                                  max: .72,
                                  onChanged: (value) => setState(() => confidence = value),
                                ),
                                Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: source == null ? null : _process, icon: const Icon(Icons.refresh), label: const Text('پردازش مجدد'))),
                              ],
                            )
                          : Text('دقت فعلی ${(confidence * 100).round()}٪', style: const TextStyle(fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
              ),
              _pageBottomAction(
                context,
                label: 'ذخیره PNG شفاف',
                onPressed: result == null || busy ? null : _save,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pick(ImageSource imageSource) async {
    final file = await picker.pickImage(source: imageSource, imageQuality: 98, maxWidth: 2400, maxHeight: 2400);
    if (file == null) return;
    setState(() {
      source = file;
      result = null;
    });
    await _process();
  }

  Future<void> _process() async {
    if (source == null || busy) return;
    setState(() => busy = true);
    try {
      Uint8List bytes;
      try {
        final segmented = await PortraitSegmentationService.removePersonBackground(
          imagePath: source!.path,
          threshold: confidence,
        );
        bytes = segmented.bytes;
      } catch (_) {
        bytes = await compute(
          _fallbackBackgroundJob,
          <String, dynamic>{'bytes': await source!.readAsBytes(), 'tolerance': .20},
        );
      }
      if (mounted) setState(() => result = bytes);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حذف پس‌زمینه انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final bytes = result;
    if (bytes == null) return;
    await OutputService.save(
      context: context,
      store: widget.store,
      bytes: bytes,
      fileName: 'transparent_${DateTime.now().millisecondsSinceEpoch}.png',
      title: 'ذخیره تصویر شفاف',
      allowGallery: true,
      saveInsideSanadyar: (file) => GeneratedFileSaver.attach(
        context: context,
        store: widget.store,
        file: file,
        type: 'image',
        historyTitle: 'حذف پس‌زمینه',
      ),
    );
  }
}

Widget _pageBottomAction(BuildContext context, {required String label, required VoidCallback? onPressed}) {
  final colors = Theme.of(context).colorScheme;
  return Container(
    padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
    decoration: BoxDecoration(color: colors.surface, border: Border(top: BorderSide(color: colors.outlineVariant))),
    child: FilledButton.icon(onPressed: onPressed, icon: const Icon(Icons.save_outlined), label: Text(label)),
  );
}

class EditorLayer {
  EditorLayer({required this.id, required this.kind, required this.offset, this.text, this.path, this.stamp, this.scale = 1});
  final String id;
  final EditorOverlayKind kind;
  Offset offset;
  String? text;
  String? path;
  StampPreset? stamp;
  double scale;
}

class DocumentEditorScreen extends StatefulWidget {
  const DocumentEditorScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<DocumentEditorScreen> createState() => _DocumentEditorScreenState();
}

class _DocumentEditorScreenState extends State<DocumentEditorScreen> {
  final boundaryKey = GlobalKey();
  final pages = <Uint8List>[];
  final layers = <EditorLayer>[];
  int selectedPage = 0;
  String? selectedLayerId;
  bool busy = false;

  EditorLayer? get selectedLayer => layers.where((layer) => layer.id == selectedLayerId).firstOrNull;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ویرایش PDF و عکس')),
        body: pages.isEmpty ? _emptyEditor() : _editorBody(),
      ),
    );
  }

  Widget _emptyEditor() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        SmartTip(enabled: widget.store.tipsEnabled, text: 'PDF به تصویر تبدیل می‌شود تا امضا، اثر انگشت، مهر و متن دقیقاً روی صفحه قرار بگیرند.'),
        const EmptyState(title: 'سندی انتخاب نشده', subtitle: 'یک PDF یا تصویر انتخاب کن و لایه‌های موردنیاز را روی آن بگذار.'),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: busy ? null : _openDocument, icon: const Icon(Icons.upload_file), label: const Text('انتخاب PDF یا عکس')),
      ],
    );
  }

  Widget _editorBody() {
    final selected = selectedLayer;
    return Column(
      children: [
        if (pages.length > 1)
          SizedBox(
            height: 64,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: pages.length,
              itemBuilder: (_, index) => Padding(
                padding: const EdgeInsets.only(left: 6),
                child: ChoiceChip(
                  label: Text('صفحه ${index + 1}'),
                  selected: selectedPage == index,
                  onSelected: (_) => setState(() { selectedPage = index; layers.clear(); selectedLayerId = null; }),
                ),
              ),
            ),
          ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(12),
            child: Center(
              child: RepaintBoundary(
                key: boundaryKey,
                child: Container(
                  width: 340,
                  height: 480,
                  color: Colors.white,
                  child: Stack(
                    clipBehavior: Clip.hardEdge,
                    children: [
                      Positioned.fill(child: Image.memory(pages[selectedPage], fit: BoxFit.contain)),
                      ...layers.map(_layerWidget),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Material(
          elevation: 8,
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (selected != null)
                    Row(children: [
                      const Text('اندازه'),
                      Expanded(child: Slider(min: .4, max: 2.4, value: selected.scale, onChanged: (value) => setState(() => selected.scale = value))),
                      IconButton(onPressed: () => setState(() { layers.removeWhere((layer) => layer.id == selected.id); selectedLayerId = null; }), icon: const Icon(Icons.delete_outline)),
                    ]),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 5,
                    children: [
                      _editorButton(Icons.text_fields, 'متن', _addText),
                      _editorButton(Icons.draw, 'امضا/اثر', _addAsset),
                      _editorButton(Icons.verified, 'مهر', _addStamp),
                      _editorButton(Icons.image_outlined, 'PNG', _exportPng),
                      _editorButton(Icons.picture_as_pdf, 'PDF', _exportPdf),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _editorButton(IconData icon, String label, VoidCallback action) {
    return ActionChip(avatar: Icon(icon, size: 18), label: Text(label), onPressed: busy ? null : action);
  }

  Widget _layerWidget(EditorLayer layer) {
    Widget child;
    if (layer.kind == EditorOverlayKind.text) {
      child = Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        color: Colors.white.withValues(alpha: .7),
        child: Text(layer.text ?? '', style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.black, fontSize: 18)),
      );
    } else if (layer.kind == EditorOverlayKind.image) {
      child = Image.file(File(layer.path!), width: 120, height: 80, fit: BoxFit.contain);
    } else {
      final stamp = layer.stamp!;
      child = StampPreview(
        text: stamp.text,
        shape: stamp.shape,
        opacity: stamp.opacity,
        size: 100,
        color: stampColorFromPreset(stamp),
        textWeight: stamp.textWeight,
        isBold: stamp.isBold,
        insetFactor: stamp.insetFactor,
        borderWidth: stamp.borderWidth,
      );
    }
    return Positioned(
      left: layer.offset.dx,
      top: layer.offset.dy,
      child: GestureDetector(
        onTap: () => setState(() => selectedLayerId = layer.id),
        onPanUpdate: (details) => setState(() {
          selectedLayerId = layer.id;
          layer.offset = Offset(
            (layer.offset.dx + details.delta.dx).clamp(0.0, 300.0).toDouble(),
            (layer.offset.dy + details.delta.dy).clamp(0.0, 440.0).toDouble(),
          );
        }),
        child: Transform.scale(
          scale: layer.scale,
          alignment: Alignment.topLeft,
          child: DecoratedBox(
            decoration: BoxDecoration(border: Border.all(color: selectedLayerId == layer.id ? Colors.blue : Colors.transparent, width: 1.5)),
            child: child,
          ),
        ),
      ),
    );
  }

  Future<void> _openDocument() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png'], allowMultiple: false);
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    setState(() => busy = true);
    try {
      final extension = result.files.single.extension?.toLowerCase();
      final loaded = <Uint8List>[];
      if (extension == 'pdf') {
        final bytes = await File(path).readAsBytes();
        await for (final raster in Printing.raster(bytes, dpi: 130)) {
          loaded.add(await raster.toPng());
        }
      } else {
        loaded.add(await File(path).readAsBytes());
      }
      if (loaded.isEmpty) throw StateError('صفحه‌ای از سند خوانده نشد.');
      if (mounted) setState(() { pages.addAll(loaded); selectedPage = 0; });
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('بازکردن سند انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _addText() async {
    final text = await TextInputDialog.show(context, title: 'متن روی سند', hint: 'متن را وارد کن');
    if (text == null || text.trim().isEmpty) return;
    final layer = EditorLayer(id: const Uuid().v4(), kind: EditorOverlayKind.text, offset: const Offset(90, 80), text: text.trim());
    setState(() { layers.add(layer); selectedLayerId = layer.id; });
  }

  Future<void> _addAsset() async {
    final candidates = widget.store.assets.where((asset) => asset.kind != AssetKind.portrait).toList();
    if (candidates.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا یک امضا یا اثر انگشت ذخیره کن.')));
      return;
    }
    final asset = await showModalBottomSheet<SavedAsset>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: candidates.map((item) => ListTile(leading: Image.file(File(item.path), width: 54, height: 54, fit: BoxFit.contain), title: Text(item.name), subtitle: Text(_assetKindLabel(item.kind)), onTap: () => Navigator.pop(sheetContext, item))).toList(),
        ),
      ),
    );
    if (asset == null) return;
    final layer = EditorLayer(id: const Uuid().v4(), kind: EditorOverlayKind.image, offset: const Offset(100, 130), path: asset.path);
    setState(() { layers.add(layer); selectedLayerId = layer.id; });
  }

  Future<void> _addStamp() async {
    final stamp = await showModalBottomSheet<StampPreset>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: widget.store.stamps.map((item) => ListTile(leading: StampPreview(text: item.text, shape: item.shape, opacity: item.opacity, size: 52, color: stampColorFromPreset(item), textWeight: item.textWeight, isBold: item.isBold, insetFactor: item.insetFactor, borderWidth: item.borderWidth), title: Text(item.text), onTap: () => Navigator.pop(sheetContext, item))).toList(),
        ),
      ),
    );
    if (stamp == null) return;
    final layer = EditorLayer(id: const Uuid().v4(), kind: EditorOverlayKind.stamp, offset: const Offset(110, 180), stamp: stamp);
    setState(() { layers.add(layer); selectedLayerId = layer.id; });
  }

  Future<Uint8List> _captureEditedPage() async {
    setState(() => selectedLayerId = null);
    await WidgetsBinding.instance.endOfFrame;
    final boundary = boundaryKey.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final image = await boundary.toImage(pixelRatio: 3);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('خروجی صفحه ساخته نشد.');
    return data.buffer.asUint8List();
  }

  Future<void> _exportPng() async {
    setState(() => busy = true);
    try {
      final bytes = await _captureEditedPage();
      if (!mounted) return;
      await OutputService.save(
        context: context,
        store: widget.store,
        bytes: bytes,
        fileName: 'edited_${DateTime.now().millisecondsSinceEpoch}.png',
        title: 'ذخیره تصویر ویرایش‌شده',
        allowGallery: true,
        saveInsideSanadyar: (file) => GeneratedFileSaver.attach(
          context: context,
          store: widget.store,
          file: file,
          type: 'image',
          historyTitle: 'ویرایش تصویر سند',
        ),
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ساخت PNG انجام نشد: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _exportPdf() async {
    setState(() => busy = true);
    try {
      final edited = await _captureEditedPage();
      final outputPages = [...pages];
      outputPages[selectedPage] = edited;
      final document = pw.Document(compress: true);
      for (final page in outputPages) {
        final memory = pw.MemoryImage(page);
        document.addPage(
          pw.Page(
            pageFormat: PdfPageFormat.a4,
            margin: const pw.EdgeInsets.all(12),
            build: (_) => pw.Center(child: pw.Image(memory, fit: pw.BoxFit.contain)),
          ),
        );
      }
      final bytes = await document.save();
      if (!mounted) return;
      await OutputService.save(
        context: context,
        store: widget.store,
        bytes: bytes,
        fileName: 'edited_${DateTime.now().millisecondsSinceEpoch}.pdf',
        title: 'ذخیره PDF ویرایش‌شده',
        allowGallery: false,
        saveInsideSanadyar: (file) => GeneratedFileSaver.attach(
          context: context,
          store: widget.store,
          file: file,
          type: 'pdf',
          historyTitle: 'ویرایش PDF و افزودن لایه',
        ),
      );
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ساخت PDF انجام نشد: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}

class ChangeNotifierProviderLite extends InheritedNotifier<LocalStore> {
  const ChangeNotifierProviderLite({super.key, required LocalStore notifier, required super.child}) : super(notifier: notifier);
}

extension IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
