# Third-party notices

Sanadyar includes or depends on the following third-party software. Refer to each package distribution for the complete license text.

- Flutter SDK — BSD 3-Clause License.
- Dart SDK — BSD 3-Clause License.
- `gal` 2.3.3 — MIT License.
- `google_mlkit_selfie_segmentation` 0.11.0 — MIT License; uses Google ML Kit native components subject to their applicable terms.
- `google_mlkit_face_detection` 0.14.0 — MIT License; uses Google ML Kit native components subject to their applicable terms.
- `image` 4.8.0 — MIT License.
- `pdf` / `printing` — Apache License 2.0.
- `tesseract_ocr` vendored compatibility wrapper — see `packages/tesseract_ocr/LICENSE`.
- Tesseract / tess-two native engine and trained data — Apache License 2.0 and respective trained-data terms.
