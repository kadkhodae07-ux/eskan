# Vendored tesseract_ocr for Sanadyar

This package preserves the `tesseract_ocr 0.5.0` Dart API used by Sanadyar while shipping the Flutter/Android bridge inside the source archive.

Sanadyar-specific changes:

- removed the duplicate Kotlin `TesseractOcrPlugin` implementation;
- retained one Java plugin class only;
- pinned Android compile SDK 36, minimum SDK 24 and Java 17;
- removed runtime dependence on a mutable Pub Cache plugin checkout;
- pinned `Tesseract4Android 4.8.0` and scoped JitPack to its Maven group only;
- added argument validation and safe background OCR execution.
