import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:tesseract_ocr/ocr_engine_config.dart';

class TesseractOcr {
  static const String tessDataConfig = 'assets/tessdata_config.json';
  static const String tessDataAssets = 'assets/tessdata';
  static const MethodChannel _channel = MethodChannel('tesseract_ocr');

  static Future<String>? _preparedDataPath;

  static Future<String> extractText(
    String imagePath, {
    OCRConfig? config,
  }) {
    return _extract('extractText', imagePath, config ?? const OCRConfig());
  }

  static Future<String> extractHocr(
    String imagePath, {
    OCRConfig? config,
  }) {
    return _extract('extractHocr', imagePath, config ?? const OCRConfig());
  }

  static Future<String> _extract(
    String method,
    String imagePath,
    OCRConfig config,
  ) async {
    final File image = File(imagePath);
    if (!await image.exists()) {
      throw ArgumentError.value(imagePath, 'imagePath', 'Image file does not exist');
    }

    if (config.engine == OCREngine.vision) {
      throw UnsupportedError('Apple Vision OCR is not available in the Android-only Sanadyar build.');
    }

    final String tessDataPath = config.tessDataPath ?? await _prepareTessData();
    final String? result = await _channel.invokeMethod<String>(
      method,
      <String, dynamic>{
        'imagePath': imagePath,
        'tessData': tessDataPath,
        'language': config.language,
        'config': config.toMap(),
      },
    );
    return result ?? '';
  }

  static Future<String> _prepareTessData() {
    return _preparedDataPath ??= _copyTessData();
  }

  static Future<String> _copyTessData() async {
    final Directory appDirectory = await getApplicationDocumentsDirectory();
    final Directory tessdataDirectory = Directory(p.join(appDirectory.path, 'tessdata'));
    await tessdataDirectory.create(recursive: true);

    final String rawConfig = await rootBundle.loadString(tessDataConfig);
    final Object? decoded = jsonDecode(rawConfig);
    if (decoded is! Map<String, dynamic> || decoded['files'] is! List) {
      throw const FormatException('assets/tessdata_config.json must contain a files array');
    }

    final List<Object?> entries = decoded['files'] as List<Object?>;
    if (entries.isEmpty) {
      throw const FormatException('assets/tessdata_config.json contains no trained-data files');
    }

    for (final Object? entry in entries) {
      if (entry is! String || entry.trim().isEmpty || p.basename(entry) != entry) {
        throw FormatException('Invalid tessdata filename: $entry');
      }

      final String assetPath = p.posix.join(tessDataAssets, entry);
      final ByteData data = await rootBundle.load(assetPath);
      final Uint8List bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
      final File target = File(p.join(tessdataDirectory.path, entry));

      final bool mustWrite = !await target.exists() || await target.length() != bytes.length;
      if (mustWrite) {
        final File temporary = File('${target.path}.tmp');
        await temporary.writeAsBytes(bytes, flush: true);
        if (await target.exists()) {
          await target.delete();
        }
        await temporary.rename(target.path);
      }
    }

    return appDirectory.path;
  }
}
