# Tesseract4Android is consumed through its public Java API.
-keep class com.googlecode.tesseract.android.** { *; }
