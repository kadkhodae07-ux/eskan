# Validation report — Build 36

- Version identity: `1.0.16+36`.
- Signature settings use `PenSettingsSheet` and return one immutable result to the page.
- Support and admin screens are included in the client source.
- API base URL and store channel use compile-time Dart defines.
- The Workflow requires Release signing and expects exactly two APK outputs.
- Backend/admin PHP files are distributed separately.
