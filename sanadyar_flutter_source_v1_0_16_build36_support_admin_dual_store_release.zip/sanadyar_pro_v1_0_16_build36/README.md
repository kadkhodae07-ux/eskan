# Sanadyar Pro — Build 36

Build 36 adds the online support and administration layer and a dual-store Release build pipeline.

## Main changes
- Stable standalone signature settings sheet; no nested page/sheet setState.
- Floating support button, ticket history, ticket thread and new-ticket flow.
- Secure hidden admin login after seven taps on the version row.
- Native admin dashboard for total, active and Pro users plus ticket replies.
- Backend URL and store channel are injected by `--dart-define`.
- Workflow produces exactly two signed Release APKs: Bazaar and Myket.

The Backend must be deployed and the GitHub variable `SANADYAR_API_BASE_URL` must be configured for online features.
