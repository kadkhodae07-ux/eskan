# Sanadyar 1.0.16+36

## Fixed
- Replaced the nested signature settings bottom-sheet state handling with a standalone stateful settings component to prevent app exit/crash.

## Added
- Offline-safe installation identity and controlled activity heartbeat.
- Ticket history, ticket conversation and a floating New Ticket action.
- Hidden administration login after seven taps on the version row.
- Administration dashboard with total, currently active, active-today and Pro-user metrics.
- Admin support ticket list and reply action.
- Bazaar/Myket build channel injection.

## Build and size
- Debug APK fallback removed.
- Release signing is mandatory.
- R8 minification, resource shrinking, icon tree shaking, obfuscation and ARM/ARM64-only packaging enabled.
- Exactly two APK artifacts are generated: Bazaar and Myket.
