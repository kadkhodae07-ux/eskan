#!/usr/bin/env python3
"""Normalize only the generated Sanadyar Android application module to JVM 17.

The OCR plugin is vendored under packages/tesseract_ocr and already contains a
fixed Java 17 Gradle configuration. This tool deliberately never edits package
cache entries or local package sources.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

LEGACY_MARKERS = (
    "SANADYAR_JVM17_PATCH",
    "SANADYAR_JVM17_TARGETED_PATCH",
    "SANADYAR_APP_JVM17_PATCH",
)
APP_MARKER = "SANADYAR_APP_JVM17_PATCH"


def strip_marker_tail(text: str, marker: str) -> tuple[str, bool]:
    match = re.search(rf"(?m)^\s*//\s*{re.escape(marker)}\s*$", text)
    if not match:
        return text, False
    return text[: match.start()].rstrip() + "\n", True


def strip_generated_tails(text: str) -> tuple[str, list[str]]:
    removed: list[str] = []
    for marker in LEGACY_MARKERS:
        text, changed = strip_marker_tail(text, marker)
        if changed:
            removed.append(marker)
    return text, removed


def module_kind(text: str) -> str | None:
    if re.search(
        r'id\s*\(\s*["\']com\.android\.application["\']\s*\)'
        r'|id\s+["\']com\.android\.application["\']'
        r'|apply\s+plugin\s*:\s*["\']com\.android\.application["\']',
        text,
    ):
        return "application"
    return None


def normalize_legacy_targets(text: str) -> str:
    replacements = {
        "JavaVersion.VERSION_1_8": "JavaVersion.VERSION_17",
        "JavaVersion.VERSION_11": "JavaVersion.VERSION_17",
        "JvmTarget.JVM_1_8": "JvmTarget.JVM_17",
        "JvmTarget.JVM_11": "JvmTarget.JVM_17",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)

    patterns = (
        (r"(?m)(jvmTarget\s*=\s*)['\"](?:1\.8|8|11)['\"]", r'\g<1>"17"'),
        (r"(?m)(sourceCompatibility\s*=\s*)['\"](?:1\.8|8|11)['\"]", r'\g<1>"17"'),
        (r"(?m)(targetCompatibility\s*=\s*)['\"](?:1\.8|8|11)['\"]", r'\g<1>"17"'),
        (r"(?m)(sourceCompatibility\s+)['\"](?:1\.8|8|11)['\"]", r'\g<1>"17"'),
        (r"(?m)(targetCompatibility\s+)['\"](?:1\.8|8|11)['\"]", r'\g<1>"17"'),
    )
    for pattern, replacement in patterns:
        text = re.sub(pattern, replacement, text)
    return text


def groovy_patch() -> str:
    return f'''
// {APP_MARKER}
android {{
    compileOptions {{
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }}
}}

tasks.withType(org.gradle.api.tasks.compile.JavaCompile).configureEach {{
    sourceCompatibility = JavaVersion.VERSION_17.toString()
    targetCompatibility = JavaVersion.VERSION_17.toString()
}}

tasks.withType(org.jetbrains.kotlin.gradle.tasks.KotlinCompile).configureEach {{
    kotlinOptions {{
        jvmTarget = "17"
    }}
}}
'''


def kotlin_patch() -> str:
    return f'''
// {APP_MARKER}
android {{
    compileOptions {{
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }}
}}

tasks.withType<org.gradle.api.tasks.compile.JavaCompile>().configureEach {{
    sourceCompatibility = JavaVersion.VERSION_17.toString()
    targetCompatibility = JavaVersion.VERSION_17.toString()
}}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {{
    compilerOptions {{
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }}
}}
'''


def sanitize_android_root(project: Path) -> list[dict[str, object]]:
    results: list[dict[str, object]] = []
    for path in (project / "android" / "build.gradle", project / "android" / "build.gradle.kts"):
        if not path.is_file():
            continue
        original = path.read_text(encoding="utf-8")
        cleaned, removed = strip_generated_tails(original)
        changed = cleaned != original
        if changed:
            path.write_text(cleaned, encoding="utf-8")
        if any(marker in cleaned for marker in LEGACY_MARKERS):
            raise SystemExit(f"Generated JVM marker remains in Android root build file: {path}")
        results.append({"file": str(path), "changed": changed, "removedMarkers": removed, "safe": True})
    return results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path.cwd())
    parser.add_argument("--report", type=Path)
    parser.add_argument("--agp", default="8.11.1")
    parser.add_argument("--kotlin", default="2.2.20")
    parser.add_argument("--compile-sdk", default="36")
    args = parser.parse_args()

    project = args.project.resolve()
    root_safety = sanitize_android_root(project)
    app_gradle = next(
        (
            path
            for path in (
                project / "android" / "app" / "build.gradle.kts",
                project / "android" / "app" / "build.gradle",
            )
            if path.is_file()
        ),
        None,
    )
    if app_gradle is None:
        raise SystemExit("Android application Gradle file was not found")

    original = app_gradle.read_text(encoding="utf-8")
    without_generated, removed = strip_generated_tails(original)
    kind = module_kind(without_generated)
    if kind != "application":
        raise SystemExit(f"Refusing to patch a non-application Gradle file: {app_gradle}")

    normalized = normalize_legacy_targets(without_generated).rstrip()
    updated = normalized + (kotlin_patch() if app_gradle.suffix == ".kts" else groovy_patch())
    changed = updated != original
    if changed:
        app_gradle.write_text(updated, encoding="utf-8")

    report = {
        "javaTarget": 17,
        "kotlinTarget": 17,
        "androidGradlePlugin": args.agp,
        "kotlinPlugin": args.kotlin,
        "compileSdk": args.compile_sdk,
        "strategy": "generated-app-only-local-ocr-preconfigured",
        "patchedModules": [
            {
                "package": "application",
                "file": str(app_gradle),
                "moduleKind": kind,
                "changed": changed,
                "removedMarkers": removed,
                "markerPresent": APP_MARKER in updated,
            }
        ],
        "androidRootBuildFiles": root_safety,
        "rootBuildFileSafe": bool(root_safety) and all(item["safe"] for item in root_safety),
        "applicationPatched": True,
        "packageSourcesPatched": False,
    }
    output = json.dumps(report, indent=2, ensure_ascii=False)
    print(output)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
