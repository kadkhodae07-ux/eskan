#!/usr/bin/env python3
"""Validate the deterministic, local tesseract_ocr Android plugin."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from urllib.parse import unquote, urlparse


def resolve_root(config_file: Path, root_uri: str) -> Path:
    parsed = urlparse(root_uri)
    if parsed.scheme == "file":
        return Path(unquote(parsed.path)).resolve()
    return (config_file.parent / unquote(root_uri)).resolve()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, default=Path.cwd())
    parser.add_argument("--compile-sdk", default="36")
    parser.add_argument("--min-sdk", default="24")
    parser.add_argument("--engine-version", default="4.8.0")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    project = args.project.resolve()
    expected = (project / "packages" / "tesseract_ocr").resolve()
    config_file = project / ".dart_tool" / "package_config.json"
    if not config_file.is_file():
        raise SystemExit(f"Missing package config: {config_file}")

    config = json.loads(config_file.read_text(encoding="utf-8"))
    package = next((item for item in config.get("packages", []) if item.get("name") == "tesseract_ocr"), None)
    if not package:
        raise SystemExit("tesseract_ocr was not resolved")
    actual = resolve_root(config_file, package["rootUri"])
    if actual != expected:
        raise SystemExit(f"tesseract_ocr is not local: expected {expected}, resolved {actual}")

    java_files = sorted((expected / "android" / "src" / "main").rglob("TesseractOcrPlugin.java"))
    kotlin_files = sorted((expected / "android" / "src" / "main").rglob("TesseractOcrPlugin.kt"))
    all_kotlin = sorted((expected / "android" / "src" / "main").rglob("*.kt"))
    if len(java_files) != 1:
        raise SystemExit(f"Expected one Java plugin class, found {len(java_files)}")
    if kotlin_files or all_kotlin:
        raise SystemExit(f"Kotlin source must not exist in the vendored OCR plugin: {all_kotlin}")

    java_text = java_files[0].read_text(encoding="utf-8")
    declaration_count = len(re.findall(r"\bclass\s+TesseractOcrPlugin\b", java_text))
    if declaration_count != 1:
        raise SystemExit(f"Expected one TesseractOcrPlugin declaration, found {declaration_count}")

    gradle = expected / "android" / "build.gradle"
    gradle_text = gradle.read_text(encoding="utf-8")
    required = {
        "compileSdk": rf"compileSdkVersion\s+{re.escape(args.compile_sdk)}\b",
        "minSdk": rf"minSdkVersion\s+{re.escape(args.min_sdk)}\b",
        "sourceJava17": r"sourceCompatibility\s+JavaVersion\.VERSION_17",
        "targetJava17": r"targetCompatibility\s+JavaVersion\.VERSION_17",
        "androidLibrary": r"apply\s+plugin:\s*['\"]com\.android\.library['\"]",
        "tesseract4Android": rf"tesseract4android:{re.escape(args.engine_version)}\b",
        "jitpackRepository": r"url\s+[\'\"]https://jitpack\.io[\'\"]",
        "jitpackGroupFilter": r"includeGroup\s+[\'\"]cz\.adaptech\.tesseract4android[\'\"]",
    }
    missing = [name for name, pattern in required.items() if not re.search(pattern, gradle_text)]
    if missing:
        raise SystemExit(f"Vendored OCR Gradle validation failed: {missing}")

    pubspec = (expected / "pubspec.yaml").read_text(encoding="utf-8")
    if "pluginClass: TesseractOcrPlugin" not in pubspec:
        raise SystemExit("Vendored OCR pubspec does not register TesseractOcrPlugin")

    report = {
        "resolvedRoot": str(actual),
        "local": True,
        "javaPluginFiles": [str(path) for path in java_files],
        "kotlinPluginFiles": [str(path) for path in kotlin_files],
        "allKotlinSources": [str(path) for path in all_kotlin],
        "pluginDeclarationCount": declaration_count,
        "compileSdk": int(args.compile_sdk),
        "minSdk": int(args.min_sdk),
        "javaTarget": 17,
        "engineArtifact": f"cz.adaptech.tesseract4android:tesseract4android:{args.engine_version}",
        "engineRepository": "https://jitpack.io",
        "engineRepositoryScoped": True,
        "engineArtifactVendored": False,
        "pubCachePatched": False,
    }
    output = json.dumps(report, indent=2, ensure_ascii=False)
    print(output)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(output + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
