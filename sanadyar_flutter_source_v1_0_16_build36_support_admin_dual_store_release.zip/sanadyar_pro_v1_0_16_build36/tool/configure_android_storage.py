#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', required=True)
    parser.add_argument('--report', required=True)
    args = parser.parse_args()

    project = Path(args.project).resolve()
    manifest = project / 'android/app/src/main/AndroidManifest.xml'
    if not manifest.is_file():
        raise SystemExit(f'AndroidManifest.xml not found: {manifest}')

    text = manifest.read_text(encoding='utf-8')
    permission = '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />'
    permission_added = False
    legacy_added = False

    if 'android.permission.WRITE_EXTERNAL_STORAGE' not in text:
        match = re.search(r'<manifest\b[^>]*>', text)
        if not match:
            raise SystemExit('Manifest root tag was not found')
        text = text[:match.end()] + '\n    ' + permission + text[match.end():]
        permission_added = True

    app_match = re.search(r'<application\b', text)
    if not app_match:
        raise SystemExit('Application tag was not found')
    app_tag_end = text.find('>', app_match.start())
    if app_tag_end < 0:
        raise SystemExit('Application tag is malformed')
    app_tag = text[app_match.start():app_tag_end + 1]
    if 'android:requestLegacyExternalStorage=' not in app_tag:
        text = text[:app_match.end()] + '\n        android:requestLegacyExternalStorage="true"' + text[app_match.end():]
        legacy_added = True

    manifest.write_text(text, encoding='utf-8')
    report = {
        'manifest': str(manifest),
        'writeExternalStoragePresent': 'android.permission.WRITE_EXTERNAL_STORAGE' in text,
        'requestLegacyExternalStoragePresent': 'android:requestLegacyExternalStorage="true"' in text,
        'permissionAdded': permission_added,
        'legacyAttributeAdded': legacy_added,
    }
    report_path = Path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
