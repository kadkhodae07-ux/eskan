# Validation report — Build 36

- Version identity: `1.0.16+36`.
- Signature settings use `PenSettingsSheet` and return one immutable result to the page.
- Support and admin screens are included in the client source.
- API base URL and store channel use compile-time Dart defines.
- The Workflow requires Release signing and expects exactly two APK outputs.
- Backend/admin PHP files are distributed separately.

- WF-36.3 embeds the release signing package under `tool/signing/` so the workflow can locate it when the source ZIP is uploaded alone.
