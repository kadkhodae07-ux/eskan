# سندیار — Flutter 1.0.16+41

این نسخه خطای تداخل Billing بازار و مایکت را با معماری Build ایزوله رفع می‌کند.

## ساخت دو نسخه فروشگاهی

Workflow دو پروژه موقت مستقل ایجاد می‌کند:

- بازار: فقط `flutter_poolakey` و Adapter بازار
- مایکت: فقط `myket_iap` و Adapter مایکت

در نتیجه کلاس `IInAppBillingService` فقط یک‌بار در هر APK قرار می‌گیرد و کتابخانه پرداخت فروشگاه دیگر وارد خروجی نمی‌شود.

## تنظیمات لازم GitHub

- Variable: `SANADYAR_API_BASE_URL`
- Variable اختیاری: `SANADYAR_PRO_PRODUCT_ID`؛ پیش‌فرض `sanadyar_pro_monthly`
- Secret: `SANADYAR_BAZAAR_RSA_KEY`
- Secret: `SANADYAR_MYKET_RSA_KEY`

## محصول اشتراکی

در هر دو پنل بازار و مایکت محصول اشتراکی ماهانه زیر ساخته شود:

`sanadyar_pro_monthly`

قیمت: `۲۵٬۰۰۰ تومان` در ماه.

## تبلیغات Adivery

- App ID: `1cced1a2-7651-4886-88ae-40bb836351e2`
- Native: `d826715d-efaa-4760-8e3c-4f1926daccb5`
- Rewarded: `1f94d8a9-cbc0-48d4-88a6-898cd45f4384`
- Interstitial: `f633fe88-25fa-407b-bd5c-dd681b5ac63c`
