# گزارش اعتبارسنجی — سندیار Build 41 / WF-41.1

## خطای ورودی

لاگ Build 40 نشان داد:

- `flutter analyze`: موفق
- `flutter test`: ۱۷ تست موفق
- شکست در `:app:checkBazaarReleaseDuplicateClasses`
- کلاس تکراری: `com.android.vending.billing.IInAppBillingService`
- ماژول‌های متداخل: `myket-billing-client` و `poolakey`

## اصلاح انجام‌شده

- واردکردن مستقیم هر دو SDK پرداخت از `main.dart` حذف شد.
- قرارداد مستقل `StoreBillingGateway` اضافه شد.
- Adapterهای بازار و مایکت از هم جدا شدند.
- Workflow برای هر فروشگاه پروژه مستقل و Dependency Graph مستقل تولید می‌کند.
- در نسخه بازار، `myket_iap` حذف می‌شود.
- در نسخه مایکت، `flutter_poolakey` حذف می‌شود.
- Analyzer جداگانه برای هر دو پروژه فروشگاهی اضافه شد.
- کنترل خودکار اضافه شد که وابستگی فروشگاه مخالف در Graph وجود نداشته باشد.

## کنترل‌های محلی

- نسخه `1.0.16+41` در `pubspec.yaml`، `AppBuildInfo` و تست‌ها هماهنگ است.
- YAML با parser بررسی شد.
- ساختار ZIP و مسیرهای امن بررسی شد.
- Keystore داخل سورس حفظ شد.
- تفکیک محلی pubspec و Adapter برای هر دو کانال شبیه‌سازی و تأیید شد.

## محدودیت محیط

Flutter SDK در محیط محلی موجود نبود؛ بنابراین کامپایل واقعی APK در همین محیط اجرا نشد. Workflow پیش از Build، تحلیل پایه، تست‌ها، تحلیل جداگانه بازار و مایکت و بررسی Dependency Graph را اجباری اجرا می‌کند.
