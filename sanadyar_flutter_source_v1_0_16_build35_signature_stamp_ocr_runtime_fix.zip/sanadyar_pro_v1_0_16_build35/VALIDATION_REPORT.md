# Validation report — Build 35 / WF-35.1

## Source checks

- Source version set to `1.0.16+35`.
- Signature export uses vector-stroke bounds rather than widget capture.
- Stamp schema includes backward-compatible `borderWidth` persistence.
- OCR native plugin validates `tessdata`, decodes an Android ARGB bitmap and uses multiple recognition passes.
- OCR status and non-empty-result handling are present.

## Regression coverage

- Signature bounds include all stroke points and safety padding.
- Stamp border thickness scaling and legacy defaults.
- Existing person-mask, OCR preprocessing, Persian cleanup, background removal and portrait-size tests are retained.

## Environment limitation

Flutter and Android SDKs are not installed in the artifact environment. Final dependency resolution, analyzer, Flutter tests and APK compilation are executed by WF-35.1 in GitHub Actions.
