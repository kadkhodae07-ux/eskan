# Sanadyar 1.0.16+35

## Fixed

- Signature output no longer depends on a screenshot of the visible widget. All strokes are rendered to a dedicated transparent image using their complete geometric bounds and safety padding.
- The last segment of every signature stroke is explicitly completed before export.
- OCR Android integration now validates language assets, decodes the prepared image to an ARGB bitmap and sends the bitmap directly to Tesseract.
- OCR no longer fails silently when no text is returned; the user receives a visible status and actionable error.

## Improved

- Added adjustable stamp border thickness from 1.0 to 8.0.
- Stamp border thickness is saved in presets and preserved in live preview, saved-list thumbnails, document layers and PDF output.
- OCR uses multiple page-segmentation passes, retries the original image and separates Persian/English recognition when mixed-language mode needs a fallback.
- Added OCR progress stages and successful character-count feedback.

## Toolchain

- Flutter: 3.44.6
- Dart: 3.12.2
- Java: 17
- Android compile/target SDK: 36
- Android min SDK: 24
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3
- Kotlin Gradle Plugin: 2.2.20
