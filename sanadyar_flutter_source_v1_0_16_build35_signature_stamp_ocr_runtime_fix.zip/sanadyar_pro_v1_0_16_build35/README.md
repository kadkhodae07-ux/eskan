# Sanadyar Pro — Build 35

Sanadyar is a Flutter-based Persian document utility app for scanning, OCR, signatures, fingerprints, portrait photos, background removal and PDF/image editing.

## Build 35 focus

- Signature PNG export is rendered directly from all vector strokes and cropped to their full bounds with safety padding, preventing partial signatures.
- Stamp presets now include a persistent, real border-thickness setting used in previews, saved presets, the document editor and PDF exports.
- OCR now validates trained-data files, decodes input through Android Bitmap, runs multiple recognition passes and reports an explicit status instead of silently returning an empty result.

See `CHANGELOG.md` and `VALIDATION_REPORT.md` for details.
