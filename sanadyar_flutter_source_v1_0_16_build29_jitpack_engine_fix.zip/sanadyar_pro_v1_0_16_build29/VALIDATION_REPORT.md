# Validation report — Sanadyar 1.0.16+29

## Failure reviewed

Build 28 passed the Kotlin source and task checks. It failed at `:tesseract_ocr:compileDebugJavaWithJavac` because Gradle searched Google Maven and Maven Central but no JitPack repository was configured for `cz.adaptech.tesseract4android:tesseract4android:4.8.0`.

## Build 29 checks

- `pubspec.yaml` version is `1.0.16+29`.
- `tesseract_ocr` remains a local path dependency.
- Exactly one Java plugin source exists and no Kotlin source exists.
- The OCR Gradle module declares compile SDK 36, minimum SDK 24 and Java 17.
- JitPack is enabled only with `includeGroup 'cz.adaptech.tesseract4android'`.
- The engine coordinate is pinned to `cz.adaptech.tesseract4android:tesseract4android:4.8.0`.
- The Workflow resolves `debugCompileClasspath` and rejects unresolved or substituted engine versions.
- The resolved AAR must exist in Gradle's module cache, contain `AndroidManifest.xml`, `classes.jar` and native JNI libraries, and have its SHA-256 recorded.
- The isolated Java OCR compilation remains mandatory.
- Workflow YAML, shell blocks and embedded Python blocks are syntax-validated.
- Helper Python scripts parse successfully and ZIP integrity/manifests are verified.

## Build boundary

The packaging environment does not include Flutter/Android SDK and cannot execute the final Android dependency resolution. The included GitHub Actions Workflow performs the real JitPack resolution, AAR validation, Flutter analysis, tests and APK compilation.
