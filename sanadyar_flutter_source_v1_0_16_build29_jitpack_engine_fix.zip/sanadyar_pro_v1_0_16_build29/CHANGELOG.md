# Sanadyar 1.0.16+29

## Fixed

- Added the missing JitPack repository required by the pinned `Tesseract4Android 4.8.0` engine.
- Scoped JitPack access exclusively to `cz.adaptech.tesseract4android`.
- Added an explicit `debugCompileClasspath` dependency-resolution preflight.
- Added AAR cache discovery, ZIP-structure validation and SHA-256 diagnostics before Java compilation.
- Preserved the Java-only local Flutter OCR plugin and Kotlin `NO-SOURCE` gate from Build 28.

## Toolchain

- Flutter: 3.44.6
- Java: 17
- Android compile/target SDK: 36
- Android min SDK: 24
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3
- Kotlin Gradle Plugin: 2.2.20
- file_picker: 10.3.10
- local tesseract_ocr: 0.5.0+sanadyar.1
- Tesseract4Android: 4.8.0 via scoped JitPack repository

## Output

- APK only; no AAB is produced.
