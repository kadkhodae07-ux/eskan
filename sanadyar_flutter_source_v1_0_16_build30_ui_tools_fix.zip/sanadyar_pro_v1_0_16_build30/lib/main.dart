import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:image/image.dart' as im;
import 'package:image_picker/image_picker.dart';
import 'package:local_auth/local_auth.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:tesseract_ocr/ocr_engine_config.dart';
import 'package:tesseract_ocr/tesseract_ocr.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SanadyarApp());
}

enum OutputQuality { light, printReady, compressed }
enum StampShape { circle, rectangle, oval, rounded }
enum AssetKind { signature, fingerprint, portrait }
enum ScanFilter { color, grayscale, document }
enum FingerprintMode { photo, manual }
enum EditorOverlayKind { text, image, stamp }

class SanadyarApp extends StatelessWidget {
  const SanadyarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'سندیار',
      themeMode: ThemeMode.system,
      theme: SanadyarTheme.light(),
      darkTheme: SanadyarTheme.dark(),
      home: const HomeShell(),
    );
  }
}

class SanadyarTheme {
  static ThemeData light() => ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2157D6), brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F7FB),
        cardTheme: CardThemeData(
          elevation: 0,
          color: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
      );

  static ThemeData dark() => ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7EA6FF), brightness: Brightness.dark),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        ),
      );
}

class DocumentProject {
  DocumentProject({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
    this.isPrivate = false,
    this.notes = '',
    this.files = const [],
    this.history = const [],
  });

  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isPrivate;
  final String notes;
  final List<DocumentFile> files;
  final List<EditHistory> history;

  DocumentProject copyWith({
    String? title,
    DateTime? updatedAt,
    bool? isPrivate,
    String? notes,
    List<DocumentFile>? files,
    List<EditHistory>? history,
  }) {
    return DocumentProject(
      id: id,
      title: title ?? this.title,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isPrivate: isPrivate ?? this.isPrivate,
      notes: notes ?? this.notes,
      files: files ?? this.files,
      history: history ?? this.history,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'isPrivate': isPrivate,
        'notes': notes,
        'files': files.map((e) => e.toJson()).toList(),
        'history': history.map((e) => e.toJson()).toList(),
      };

  factory DocumentProject.fromJson(Map<String, dynamic> json) => DocumentProject(
        id: json['id'] as String,
        title: json['title'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        updatedAt: DateTime.parse(json['updatedAt'] as String),
        isPrivate: json['isPrivate'] == true,
        notes: (json['notes'] ?? '') as String,
        files: ((json['files'] ?? []) as List).map((e) => DocumentFile.fromJson(Map<String, dynamic>.from(e))).toList(),
        history: ((json['history'] ?? []) as List).map((e) => EditHistory.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class DocumentFile {
  DocumentFile({required this.id, required this.name, required this.path, required this.type, required this.createdAt});
  final String id;
  final String name;
  final String path;
  final String type;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'path': path, 'type': type, 'createdAt': createdAt.toIso8601String()};
  factory DocumentFile.fromJson(Map<String, dynamic> json) => DocumentFile(
        id: json['id'] as String,
        name: json['name'] as String,
        path: json['path'] as String,
        type: json['type'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}

class EditHistory {
  EditHistory({required this.id, required this.title, required this.createdAt, this.snapshotPath});
  final String id;
  final String title;
  final DateTime createdAt;
  final String? snapshotPath;
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'createdAt': createdAt.toIso8601String(), 'snapshotPath': snapshotPath};
  factory EditHistory.fromJson(Map<String, dynamic> json) => EditHistory(
        id: json['id'] as String,
        title: json['title'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        snapshotPath: json['snapshotPath'] as String?,
      );
}

class StampPreset {
  StampPreset({required this.id, required this.text, required this.shape, required this.opacity, required this.createdAt});
  final String id;
  final String text;
  final StampShape shape;
  final double opacity;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'shape': shape.name, 'opacity': opacity, 'createdAt': createdAt.toIso8601String()};
  factory StampPreset.fromJson(Map<String, dynamic> json) => StampPreset(
        id: json['id'] as String,
        text: json['text'] as String,
        shape: StampShape.values.firstWhere((e) => e.name == json['shape'], orElse: () => StampShape.circle),
        opacity: (json['opacity'] as num?)?.toDouble() ?? .72,
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}


class SavedAsset {
  SavedAsset({
    required this.id,
    required this.name,
    required this.path,
    required this.kind,
    required this.createdAt,
  });

  final String id;
  final String name;
  final String path;
  final AssetKind kind;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'path': path,
        'kind': kind.name,
        'createdAt': createdAt.toIso8601String(),
      };

  factory SavedAsset.fromJson(Map<String, dynamic> json) => SavedAsset(
        id: json['id'] as String,
        name: json['name'] as String,
        path: json['path'] as String,
        kind: AssetKind.values.firstWhere(
          (value) => value.name == json['kind'],
          orElse: () => AssetKind.signature,
        ),
        createdAt: DateTime.parse(json['createdAt'] as String),
      );
}


class InkStroke {
  InkStroke({required this.points, required this.color, required this.width});
  final List<Offset> points;
  final Color color;
  final double width;
}

class LocalStore extends ChangeNotifier {
  static const _projectsKey = 'sanadyar.projects.v17';
  static const _stampsKey = 'sanadyar.stamps.v17';
  static const _tipsKey = 'sanadyar.tips.seen.v17';
  static const _assetsKey = 'sanadyar.assets.v23';
  final _uuid = const Uuid();
  final _secure = const FlutterSecureStorage();
  final _auth = LocalAuthentication();

  List<DocumentProject> projects = [];
  List<StampPreset> stamps = [];
  List<SavedAsset> assets = [];
  bool tipsEnabled = true;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    projects = ((jsonDecode(prefs.getString(_projectsKey) ?? '[]')) as List)
        .map((e) => DocumentProject.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    stamps = ((jsonDecode(prefs.getString(_stampsKey) ?? '[]')) as List)
        .map((e) => StampPreset.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    assets = ((jsonDecode(prefs.getString(_assetsKey) ?? '[]')) as List)
        .map((e) => SavedAsset.fromJson(Map<String, dynamic>.from(e)))
        .where((asset) => File(asset.path).existsSync())
        .toList();
    tipsEnabled = prefs.getBool(_tipsKey) ?? true;
    if (stamps.isEmpty) {
      stamps = [
        StampPreset(id: _uuid.v4(), text: 'کپی برابر اصل', shape: StampShape.circle, opacity: .70, createdAt: DateTime.now()),
        StampPreset(id: _uuid.v4(), text: 'محرمانه', shape: StampShape.rectangle, opacity: .65, createdAt: DateTime.now()),
      ];
      await _saveStamps();
    }
    notifyListeners();
  }

  Future<void> setTips(bool value) async {
    tipsEnabled = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_tipsKey, value);
    notifyListeners();
  }

  Future<DocumentProject> createProject(String title, {bool isPrivate = false}) async {
    final now = DateTime.now();
    final project = DocumentProject(id: _uuid.v4(), title: title.trim().isEmpty ? 'پرونده جدید' : title.trim(), createdAt: now, updatedAt: now, isPrivate: isPrivate);
    projects = [project, ...projects];
    await _saveProjects();
    notifyListeners();
    return project;
  }

  Future<void> updateProject(DocumentProject project) async {
    projects = projects.map((p) => p.id == project.id ? project.copyWith(updatedAt: DateTime.now()) : p).toList();
    await _saveProjects();
    notifyListeners();
  }

  Future<void> addStamp(StampPreset stamp) async {
    stamps = [stamp, ...stamps];
    await _saveStamps();
    notifyListeners();
  }

  Future<void> addAsset(SavedAsset asset) async {
    assets = [asset, ...assets];
    await _saveAssets();
    notifyListeners();
  }

  Future<void> deleteAsset(String id) async {
    final target = assets.where((asset) => asset.id == id).firstOrNull;
    if (target != null) {
      final file = File(target.path);
      if (file.existsSync()) {
        await file.delete();
      }
    }
    assets = assets.where((asset) => asset.id != id).toList();
    await _saveAssets();
    notifyListeners();
  }

  Future<void> addFile(String projectId, DocumentFile file, String historyTitle) async {
    projects = projects.map((project) {
      if (project.id != projectId) return project;
      final history = EditHistory(id: _uuid.v4(), title: historyTitle, createdAt: DateTime.now(), snapshotPath: file.path);
      return project.copyWith(files: [file, ...project.files], history: [history, ...project.history], updatedAt: DateTime.now());
    }).toList();
    await _saveProjects();
    notifyListeners();
  }

  Future<bool> unlockPrivateArea() async {
    try {
      final canAuth = await _auth.canCheckBiometrics || await _auth.isDeviceSupported();
      if (canAuth) {
        return _auth.authenticate(localizedReason: 'برای مشاهده پرونده خصوصی، احراز هویت کنید.', options: const AuthenticationOptions(biometricOnly: false));
      }
      final marker = await _secure.read(key: 'private_area_enabled');
      if (marker == null) await _secure.write(key: 'private_area_enabled', value: '1');
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<File> saveBytes(String filename, Uint8List bytes) async {
    final dir = await getApplicationDocumentsDirectory();
    final folder = Directory('${dir.path}/sanadyar_outputs');
    if (!folder.existsSync()) folder.createSync(recursive: true);
    final file = File('${folder.path}/$filename');
    return file.writeAsBytes(bytes, flush: true);
  }

  Future<void> _saveProjects() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_projectsKey, jsonEncode(projects.map((e) => e.toJson()).toList()));
  }

  Future<void> _saveStamps() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_stampsKey, jsonEncode(stamps.map((e) => e.toJson()).toList()));
  }

  Future<void> _saveAssets() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_assetsKey, jsonEncode(assets.map((e) => e.toJson()).toList()));
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  final store = LocalStore();
  int tab = 0;

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: ChangeNotifierProviderLite(
        notifier: store,
        child: AnimatedBuilder(
          animation: store,
          builder: (context, _) => Scaffold(
            appBar: AppBar(
              centerTitle: false,
              title: const Text('سندیار Pro'),
              actions: [
                IconButton(onPressed: () => _showGuide(context), icon: const Icon(Icons.help_outline)),
                IconButton(onPressed: () => setState(() {}), icon: const Icon(Icons.refresh)),
              ],
            ),
            body: IndexedStack(
              index: tab,
              children: [
                DashboardScreen(store: store),
                ToolsScreen(store: store),
                ProjectsScreen(store: store),
                SettingsScreen(store: store),
              ],
            ),
            bottomNavigationBar: NavigationBar(
              selectedIndex: tab,
              onDestinationSelected: (value) => setState(() => tab = value),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'داشبورد'),
                NavigationDestination(icon: Icon(Icons.auto_fix_high_outlined), selectedIcon: Icon(Icons.auto_fix_high), label: 'ابزارها'),
                NavigationDestination(icon: Icon(Icons.folder_copy_outlined), selectedIcon: Icon(Icons.folder_copy), label: 'پرونده‌ها'),
                NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'تنظیمات'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showGuide(BuildContext context) => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (_) => const SmartGuideSheet(section: 'home'),
      );
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    final recent = [...store.projects]..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        _HeroPanel(projectCount: store.projects.length, fileCount: store.projects.fold<int>(0, (sum, p) => sum + p.files.length)),
        const SizedBox(height: 18),
        Text('ابزارهای اصلی', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        ToolGrid(store: store, compact: true),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(child: _ActionCard(icon: Icons.create_new_folder, title: 'پرونده جدید', subtitle: 'ساخت پوشه اسناد', onTap: () => _createProject(context))),
            const SizedBox(width: 12),
            Expanded(child: _ActionCard(icon: Icons.picture_as_pdf, title: 'خروجی چاپی', subtitle: 'A4 و PDF', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PrintPrepScreen(store: store))))),
          ],
        ),
        const SizedBox(height: 18),
        Text('فایل‌های اخیر', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        if (recent.isEmpty) const EmptyState(title: 'هنوز پرونده‌ای ساخته نشده', subtitle: 'برای شروع، یک پرونده بساز و فایل‌های سند را داخل آن نگه‌دار.'),
        for (final project in recent.take(6)) ProjectTile(project: project, store: store),
      ],
    );
  }

  Future<void> _createProject(BuildContext context) async {
    final title = await TextInputDialog.show(context, title: 'نام پرونده', hint: 'مثلاً قرارداد اجاره');
    if (title == null) return;
    final project = await store.createProject(title);
    if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectDetailScreen(store: store, projectId: project.id)));
  }
}

class _HeroPanel extends StatelessWidget {
  const _HeroPanel({required this.projectCount, required this.fileCount});
  final int projectCount;
  final int fileCount;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(colors: [Color(0xFF0E2A5C), Color(0xFF246BFE)], begin: Alignment.topRight, end: Alignment.bottomLeft),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('مدیریت حرفه‌ای اسناد', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 23)),
        const SizedBox(height: 8),
        const Text('اسکن، امضا، اثر انگشت، عکس ۳×۴، OCR، ویرایش PDF و مدیریت پرونده‌ها در یک اپ.', style: TextStyle(color: Colors.white70, height: 1.6)),
        const SizedBox(height: 18),
        Row(children: [
          _MetricPill(label: 'پرونده', value: projectCount.toString()),
          const SizedBox(width: 10),
          _MetricPill(label: 'فایل', value: fileCount.toString()),
        ]),
      ]),
    );
  }
}

class _MetricPill extends StatelessWidget {
  const _MetricPill({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: .14), borderRadius: BorderRadius.circular(100)),
        child: Text('$label: $value', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      );
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 12),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
        ),
      );
}

class ProjectsScreen extends StatelessWidget {
  const ProjectsScreen({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final title = await TextInputDialog.show(context, title: 'پرونده جدید', hint: 'نام پرونده');
          if (title != null) store.createProject(title);
        },
        icon: const Icon(Icons.add),
        label: const Text('پرونده'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const SectionTitle(title: 'پرونده‌ها', subtitle: 'هر سند، فایل، یادداشت و تاریخچه داخل پرونده خودش ذخیره می‌شود.'),
          const SizedBox(height: 12),
          if (store.projects.isEmpty) const EmptyState(title: 'پرونده‌ای وجود ندارد', subtitle: 'پرونده بساز تا مدارک پراکنده نشوند.'),
          ...store.projects.map((p) => ProjectTile(project: p, store: store)),
        ],
      ),
    );
  }
}

class ProjectTile extends StatelessWidget {
  const ProjectTile({super.key, required this.project, required this.store});
  final DocumentProject project;
  final LocalStore store;
  @override
  Widget build(BuildContext context) {
    final date = DateFormat('yyyy/MM/dd HH:mm').format(project.updatedAt);
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: CircleAvatar(child: Icon(project.isPrivate ? Icons.lock : Icons.folder)),
        title: Text(project.title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${project.files.length} فایل • آخرین ویرایش $date'),
        trailing: const Icon(Icons.chevron_left),
        onTap: () async {
          if (project.isPrivate) {
            final ok = await store.unlockPrivateArea();
            if (!ok) return;
          }
          if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectDetailScreen(store: store, projectId: project.id)));
        },
      ),
    );
  }
}

class ProjectDetailScreen extends StatefulWidget {
  const ProjectDetailScreen({super.key, required this.store, required this.projectId});
  final LocalStore store;
  final String projectId;
  @override
  State<ProjectDetailScreen> createState() => _ProjectDetailScreenState();
}

class _ProjectDetailScreenState extends State<ProjectDetailScreen> {
  DocumentProject get project => widget.store.projects.firstWhere((p) => p.id == widget.projectId);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(project.title)),
        body: AnimatedBuilder(
          animation: widget.store,
          builder: (_, __) => ListView(
            padding: const EdgeInsets.all(18),
            children: [
              SmartTip(enabled: widget.store.tipsEnabled, text: 'هر بار خروجی گرفتن، یک رکورد در تاریخچه ثبت می‌کند تا برگشت‌پذیری سند حفظ شود.'),
              Row(children: [
                Expanded(child: _ActionCard(icon: Icons.upload_file, title: 'افزودن فایل', subtitle: 'PDF یا عکس', onTap: _pickFile)),
                const SizedBox(width: 12),
                Expanded(child: _ActionCard(icon: Icons.history, title: 'تاریخچه', subtitle: '${project.history.length} تغییر', onTap: () => _showHistory(context))),
              ]),
              const SizedBox(height: 14),
              FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExportComposerScreen(store: widget.store, projectId: project.id))), icon: const Icon(Icons.tune), label: const Text('ساخت خروجی حرفه‌ای')),
              const SizedBox(height: 20),
              const SectionTitle(title: 'فایل‌های پرونده', subtitle: 'فایل‌ها با برچسب نوع و زمان ذخیره می‌شوند.'),
              if (project.files.isEmpty) const EmptyState(title: 'فایلی داخل پرونده نیست', subtitle: 'PDF یا عکس را اضافه کن تا خروجی مهر/واترمارک بسازی.'),
              ...project.files.map((f) => Card(
                    child: ListTile(
                      leading: Icon(f.type == 'pdf' ? Icons.picture_as_pdf : Icons.image),
                      title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(f.type.toUpperCase()),
                      trailing: IconButton(icon: const Icon(Icons.open_in_new), onPressed: () => _openFile(context, f)),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png'],
        allowMultiple: false,
      );
      if (result == null || result.files.isEmpty) return;

      final selected = result.files.first;
      final path = selected.path;
      if (path == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('مسیر فایل انتخاب‌شده در دسترس نیست.')),
          );
        }
        return;
      }

      final name = selected.name;
      final ext = name.split('.').last.toLowerCase();
      await widget.store.addFile(
        project.id,
        DocumentFile(
          id: const Uuid().v4(),
          name: name,
          path: path,
          type: ext == 'pdf' ? 'pdf' : 'image',
          createdAt: DateTime.now(),
        ),
        'افزودن فایل $name',
      );
    } on PlatformException catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('انتخاب فایل انجام نشد: ${error.message ?? error.code}')),
      );
    }
  }

  void _showHistory(BuildContext context) => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (_) => Directionality(
          textDirection: ui.TextDirection.rtl,
          child: ListView(padding: const EdgeInsets.all(18), children: [
            const SectionTitle(title: 'تاریخچه ویرایش', subtitle: 'نسخه‌ها و عملیات مهم این پرونده'),
            if (project.history.isEmpty) const EmptyState(title: 'تاریخچه خالی است', subtitle: 'با افزودن فایل یا خروجی گرفتن، تاریخچه ساخته می‌شود.'),
            ...project.history.map((h) => ListTile(leading: const Icon(Icons.restore), title: Text(h.title), subtitle: Text(DateFormat('yyyy/MM/dd HH:mm').format(h.createdAt)))),
          ]),
        ),
      );

  void _openFile(BuildContext context, DocumentFile file) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => FilePreviewScreen(file: file)));
  }
}

class FilePreviewScreen extends StatelessWidget {
  const FilePreviewScreen({super.key, required this.file});
  final DocumentFile file;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: Text(file.name)),
          body: _buildPreview(),
        ),
      );

  Widget _buildPreview() {
    final source = File(file.path);
    if (!source.existsSync()) {
      return const Center(child: Text('فایل در حافظه پیدا نشد.'));
    }
    if (file.type == 'image') {
      return Center(child: InteractiveViewer(child: Image.file(source)));
    }
    if (file.type == 'text') {
      return FutureBuilder<String>(
        future: source.readAsString(),
        builder: (context, snapshot) => SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: SelectableText(snapshot.data ?? (snapshot.hasError ? 'خواندن متن انجام نشد.' : 'در حال خواندن...')),
        ),
      );
    }
    if (file.type == 'pdf') {
      return PdfPreview(
        canChangeOrientation: false,
        canChangePageFormat: false,
        allowPrinting: true,
        allowSharing: true,
        build: (_) => source.readAsBytes(),
      );
    }
    return Center(child: Text(file.path, textAlign: TextAlign.center));
  }
}

class StampStudioScreen extends StatefulWidget {
  const StampStudioScreen({super.key, required this.store});
  final LocalStore store;
  @override
  State<StampStudioScreen> createState() => _StampStudioScreenState();
}

class _StampStudioScreenState extends State<StampStudioScreen> {
  final controller = TextEditingController(text: 'کپی برابر اصل');
  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  StampShape shape = StampShape.circle;
  double opacity = .70;
  Color stampColor = Colors.red;

  String get _effectiveText {
    final name = '${firstNameController.text.trim()} ${lastNameController.text.trim()}'.trim();
    if (name.isNotEmpty) return name;
    return controller.text.trim();
  }

  @override
  void dispose() {
    controller.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(18), children: [
      SmartTip(enabled: widget.store.tipsEnabled, text: 'نام و نام خانوادگی را وارد کن یا متن دلخواه بنویس. مهرها ذخیره می‌شوند و بعداً روی PDF یا عکس قابل استفاده‌اند.'),
      const SectionTitle(title: 'ابزار مهر حرفه‌ای', subtitle: 'مهرهای متنی با چند قالب و رنگ قابل ساخت و ذخیره هستند.'),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: TextField(
            controller: firstNameController,
            decoration: const InputDecoration(labelText: 'نام', border: OutlineInputBorder()),
            onChanged: (_) => setState(() {}),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: TextField(
            controller: lastNameController,
            decoration: const InputDecoration(labelText: 'نام خانوادگی', border: OutlineInputBorder()),
            onChanged: (_) => setState(() {}),
          ),
        ),
      ]),
      const SizedBox(height: 12),
      TextField(
        controller: controller,
        decoration: const InputDecoration(
          labelText: 'متن مهر یا عنوان تکمیلی',
          hintText: 'مثلاً کپی برابر اصل / تایید شد / امور اداری',
          border: OutlineInputBorder(),
        ),
        onChanged: (_) => setState(() {}),
      ),
      const SizedBox(height: 12),
      SegmentedButton<StampShape>(
        segments: const [
          ButtonSegment(value: StampShape.circle, label: Text('دایره‌ای')),
          ButtonSegment(value: StampShape.rectangle, label: Text('مستطیلی')),
          ButtonSegment(value: StampShape.oval, label: Text('بیضی')),
          ButtonSegment(value: StampShape.rounded, label: Text('گردگوشه')),
        ],
        selected: {shape},
        onSelectionChanged: (value) => setState(() => shape = value.first),
      ),
      const SizedBox(height: 12),
      const Text('رنگ مهر', style: TextStyle(fontWeight: FontWeight.w700)),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _stampColorChip('قرمز', Colors.red.shade700),
          _stampColorChip('آبی', const Color(0xFF2356C8)),
          _stampColorChip('مشکی', Colors.black87),
          _stampColorChip('سبز', const Color(0xFF0B8C58)),
        ],
      ),
      const SizedBox(height: 12),
      Text('شفافیت: ${(opacity * 100).round()}٪'),
      Slider(value: opacity, onChanged: (v) => setState(() => opacity = v), min: .25, max: 1),
      Center(child: StampPreview(text: _effectiveText, shape: shape, opacity: opacity, size: 170, color: stampColor)),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: _effectiveText.isEmpty
            ? null
            : () => widget.store.addStamp(
                  StampPreset(
                    id: const Uuid().v4(),
                    text: _effectiveText,
                    shape: shape,
                    opacity: opacity,
                    createdAt: DateTime.now(),
                  ),
                ),
        icon: const Icon(Icons.save),
        label: const Text('ذخیره مهر'),
      ),
      const SizedBox(height: 18),
      const SectionTitle(title: 'مهرهای ذخیره‌شده', subtitle: ''),
      ...widget.store.stamps.map(
        (s) => Card(
          child: ListTile(
            leading: StampPreview(text: s.text, shape: s.shape, opacity: s.opacity, size: 56),
            title: Text(s.text),
            subtitle: Text(
              switch (s.shape) {
                StampShape.circle => 'دایره‌ای',
                StampShape.rectangle => 'مستطیلی',
                StampShape.oval => 'بیضی',
                StampShape.rounded => 'گردگوشه',
              },
            ),
          ),
        ),
      ),
    ]);
  }

  Widget _stampColorChip(String label, Color value) {
    return ChoiceChip(
      label: Text(label),
      selected: stampColor.value == value.value,
      onSelected: (_) => setState(() => stampColor = value),
      avatar: CircleAvatar(backgroundColor: value, radius: 9),
    );
  }
}

class StampPreview extends StatelessWidget {
  const StampPreview({super.key, required this.text, required this.shape, required this.opacity, required this.size, this.color = Colors.red});
  final String text;
  final StampShape shape;
  final double opacity;
  final double size;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final borderColor = color;
    final width = switch (shape) {
      StampShape.circle => size,
      StampShape.oval => size * 1.18,
      StampShape.rectangle || StampShape.rounded => size * 1.18,
    };
    final height = switch (shape) {
      StampShape.circle => size,
      StampShape.oval => size * .72,
      StampShape.rectangle || StampShape.rounded => size * .66,
    };
    final radius = switch (shape) {
      StampShape.circle => size,
      StampShape.oval => size,
      StampShape.rectangle => 6.0,
      StampShape.rounded => 22.0,
    };
    return Opacity(
      opacity: opacity,
      child: Container(
        width: width,
        height: height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(color: borderColor, width: 3),
          borderRadius: BorderRadius.circular(radius),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              text.isEmpty ? 'مهر' : text,
              textAlign: TextAlign.center,
              style: TextStyle(color: borderColor, fontWeight: FontWeight.w900, fontSize: size / 8.6, height: 1.08),
            ),
          ),
        ),
      ),
    );
  }
}

class ExportComposerScreen extends StatefulWidget {
  const ExportComposerScreen({super.key, required this.store, required this.projectId});
  final LocalStore store;
  final String projectId;
  @override
  State<ExportComposerScreen> createState() => _ExportComposerScreenState();
}

class _ExportComposerScreenState extends State<ExportComposerScreen> {
  OutputQuality quality = OutputQuality.printReady;
  String watermark = '';
  bool datedSignature = true;
  bool printMargins = true;
  StampPreset? stamp;
  final signer = TextEditingController();
  final tracking = TextEditingController();

  DocumentProject get project => widget.store.projects.firstWhere((p) => p.id == widget.projectId);

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('خروجی حرفه‌ای')),
          body: ListView(padding: const EdgeInsets.all(18), children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'برای چاپ، کیفیت چاپی و حاشیه A4 را فعال نگه‌دار. برای واتساپ، خروجی سبک مناسب‌تر است.'),
            const SectionTitle(title: 'کیفیت خروجی', subtitle: 'سبک برای ارسال، چاپی برای پرینتر، فشرده برای PDF کم‌حجم.'),
            SegmentedButton<OutputQuality>(
              segments: const [
                ButtonSegment(value: OutputQuality.light, label: Text('سبک')),
                ButtonSegment(value: OutputQuality.printReady, label: Text('چاپی')),
                ButtonSegment(value: OutputQuality.compressed, label: Text('فشرده')),
              ],
              selected: {quality},
              onSelectionChanged: (value) => setState(() => quality = value.first),
            ),
            const SizedBox(height: 16),
            TextField(decoration: const InputDecoration(labelText: 'واترمارک اختیاری', hintText: 'مثلاً محرمانه / نمونه / پرداخت شد', border: OutlineInputBorder()), onChanged: (v) => watermark = v),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'مهر', border: OutlineInputBorder()),
              initialValue: stamp?.id,
              items: widget.store.stamps.map((s) => DropdownMenuItem(value: s.id, child: Text(s.text))).toList(),
              onChanged: (id) => setState(() => stamp = widget.store.stamps.where((s) => s.id == id).firstOrNull),
            ),
            SwitchListTile(value: datedSignature, title: const Text('امضای تاریخ‌دار'), subtitle: const Text('نام، تاریخ و کد پیگیری کنار خروجی ثبت شود.'), onChanged: (v) => setState(() => datedSignature = v)),
            if (datedSignature) ...[
              TextField(controller: signer, decoration: const InputDecoration(labelText: 'نام امضاکننده', border: OutlineInputBorder())),
              const SizedBox(height: 10),
              TextField(controller: tracking, decoration: const InputDecoration(labelText: 'کد پیگیری دستی', border: OutlineInputBorder())),
            ],
            SwitchListTile(value: printMargins, title: const Text('آماده‌سازی چاپ A4'), subtitle: const Text('حاشیه امن و اندازه استاندارد PDF'), onChanged: (v) => setState(() => printMargins = v)),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: _exportPdf, icon: const Icon(Icons.picture_as_pdf), label: const Text('ساخت PDF خروجی')),
          ]),
        ),
      );

  Future<void> _exportPdf() async {
    final doc = pw.Document(compress: quality != OutputQuality.printReady);
    final pageTheme = pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: printMargins ? const pw.EdgeInsets.all(36) : pw.EdgeInsets.zero,
    );
    final font = await PdfGoogleFonts.vazirmatnRegular();
    final bold = await PdfGoogleFonts.vazirmatnBold();
    final files = project.files.take(12).toList();
    final date = DateFormat('yyyy/MM/dd HH:mm').format(DateTime.now());

    doc.addPage(pw.MultiPage(
      pageTheme: pageTheme,
      textDirection: pw.TextDirection.rtl,
      build: (context) => [
        pw.Text(project.title, style: pw.TextStyle(font: bold, fontSize: 22)),
        pw.SizedBox(height: 10),
        pw.Text('خروجی سندیار Pro - کیفیت: ${_qualityLabel(quality)}', style: pw.TextStyle(font: font)),
        if (watermark.trim().isNotEmpty) ...[
          pw.SizedBox(height: 20),
          pw.Center(child: pw.Opacity(opacity: .15, child: pw.Text(watermark.trim(), style: pw.TextStyle(font: bold, fontSize: 54, color: PdfColors.red700)))),
        ],
        if (stamp != null) ...[
          pw.SizedBox(height: 16),
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.red700, width: 2), borderRadius: pw.BorderRadius.circular(stamp!.shape == StampShape.circle ? 80 : 8)),
            child: pw.Text(stamp!.text, style: pw.TextStyle(font: bold, fontSize: 18, color: PdfColors.red700)),
          ),
        ],
        if (datedSignature) ...[
          pw.SizedBox(height: 22),
          pw.Container(
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey600), borderRadius: pw.BorderRadius.circular(10)),
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('امضای تاریخ‌دار', style: pw.TextStyle(font: bold)),
              pw.Text('نام: ${signer.text.trim().isEmpty ? '-' : signer.text.trim()}', style: pw.TextStyle(font: font)),
              pw.Text('تاریخ: $date', style: pw.TextStyle(font: font)),
              pw.Text('کد پیگیری: ${tracking.text.trim().isEmpty ? '-' : tracking.text.trim()}', style: pw.TextStyle(font: font)),
            ]),
          ),
        ],
        pw.SizedBox(height: 22),
        pw.Text('فایل‌های پرونده', style: pw.TextStyle(font: bold, fontSize: 16)),
        ...files.map((f) => pw.Bullet(text: '${f.name} - ${f.type}', style: pw.TextStyle(font: font))),
      ],
    ));
    final bytes = await doc.save();
    final safeName = project.title.replaceAll(RegExp(r'[^A-Za-z0-9آ-ی_-]+'), '_');
    final file = await widget.store.saveBytes('sanadyar_${safeName}_${DateTime.now().millisecondsSinceEpoch}.pdf', bytes);
    await widget.store.addFile(project.id, DocumentFile(id: const Uuid().v4(), name: file.uri.pathSegments.last, path: file.path, type: 'pdf', createdAt: DateTime.now()), 'خروجی PDF با ${_qualityLabel(quality)}');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF ذخیره شد: ${file.path}')));
      await Printing.sharePdf(bytes: bytes, filename: file.uri.pathSegments.last);
    }
  }

  String _qualityLabel(OutputQuality q) => switch (q) { OutputQuality.light => 'سبک', OutputQuality.printReady => 'چاپی', OutputQuality.compressed => 'فشرده' };
}

class PrintPrepScreen extends StatelessWidget {
  const PrintPrepScreen({super.key, required this.store});
  final LocalStore store;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('آماده‌سازی چاپ')),
          body: ListView(padding: const EdgeInsets.all(18), children: const [
            SectionTitle(title: 'چاپ A4', subtitle: 'این بخش برای کنترل خروجی نهایی قبل از پرینت طراحی شده است.'),
            SmartTip(enabled: true, text: 'حاشیه امن باعث می‌شود امضا، مهر یا متن نزدیک لبه کاغذ بریده نشود.'),
            PrintMockupCard(),
          ]),
        ),
      );
}

class PrintMockupCard extends StatelessWidget {
  const PrintMockupCard({super.key});
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: AspectRatio(
            aspectRatio: 1 / 1.414,
            child: Container(
              decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.outlineVariant), color: Colors.white),
              padding: const EdgeInsets.all(22),
              child: Container(decoration: BoxDecoration(border: Border.all(color: Colors.blueGrey.shade100, style: BorderStyle.solid)), child: const Center(child: Text('پیش‌نمایش حاشیه امن A4'))),
            ),
          ),
        ),
      );
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.store});
  final LocalStore store;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
        const SectionTitle(title: 'تنظیمات', subtitle: 'کنترل امنیت و راهنمای داخل اپ'),
        SwitchListTile(value: store.tipsEnabled, title: const Text('راهنمای هوشمند داخل اپ'), subtitle: const Text('نمایش نکات کوتاه در بخش‌های مهم'), onChanged: store.setTips),
        ListTile(leading: const Icon(Icons.lock), title: const Text('پوشه خصوصی'), subtitle: const Text('پرونده خصوصی با رمز/اثر انگشت دستگاه باز می‌شود.'), trailing: FilledButton(onPressed: store.unlockPrivateArea, child: const Text('تست قفل'))),
        ListTile(leading: const Icon(Icons.draw), title: const Text('دارایی‌های ذخیره‌شده'), subtitle: Text('${store.assets.length} امضا، اثر انگشت یا عکس ۳×۴')),
        const AboutListTile(icon: Icon(Icons.info_outline), applicationName: 'سندیار', applicationVersion: '1.0.16+23'),
      ]);
}

class SmartGuideSheet extends StatelessWidget {
  const SmartGuideSheet({super.key, required this.section});
  final String section;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: const [
            SectionTitle(title: 'راهنمای سریع سندیار', subtitle: 'مسیر پیشنهادی برای خروجی حرفه‌ای'),
            ListTile(leading: Icon(Icons.document_scanner), title: Text('از داشبورد ابزار را انتخاب کن'), subtitle: Text('اسکن، امضا، اثر انگشت، عکس ۳×۴ و OCR همگی مستقیم در دسترس‌اند.')),
            ListTile(leading: Icon(Icons.folder), title: Text('خروجی را داخل پرونده ذخیره کن'), subtitle: Text('تاریخچه و فایل‌ها در پرونده باقی می‌مانند و دوباره قابل استفاده‌اند.')),
            ListTile(leading: Icon(Icons.edit_document), title: Text('در ویرایشگر لایه اضافه کن'), subtitle: Text('امضا، اثر انگشت، مهر و متن را روی PDF یا عکس جابه‌جا و اندازه‌گذاری کن.')),
          ]),
        ),
      );
}

class SmartTip extends StatelessWidget {
  const SmartTip({super.key, required this.enabled, required this.text});
  final bool enabled;
  final String text;
  @override
  Widget build(BuildContext context) => enabled
      ? Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: .55), borderRadius: BorderRadius.circular(18)),
          child: Row(children: [Icon(Icons.lightbulb_outline, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 10), Expanded(child: Text(text))]),
        )
      : const SizedBox.shrink();
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({super.key, required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
        if (subtitle.isNotEmpty) ...[const SizedBox(height: 4), Text(subtitle, style: Theme.of(context).textTheme.bodyMedium)],
      ]);
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(children: [Icon(Icons.inbox_outlined, size: 42, color: Theme.of(context).colorScheme.outline), const SizedBox(height: 10), Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 6), Text(subtitle, textAlign: TextAlign.center)]),
        ),
      );
}

class TextInputDialog {
  static Future<String?> show(BuildContext context, {required String title, required String hint}) async {
    final controller = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: AlertDialog(
          title: Text(title),
          content: TextField(controller: controller, autofocus: true, decoration: InputDecoration(hintText: hint)),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('انصراف')), FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('تأیید'))],
        ),
      ),
    );
  }
}


class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const SectionTitle(
          title: 'ابزارهای سندیار',
          subtitle: 'اسکن، امضا، اثر انگشت، عکس ۳×۴، OCR و ویرایش PDF یا عکس.',
        ),
        const SizedBox(height: 12),
        ToolGrid(store: store),
        const SizedBox(height: 22),
        SectionTitle(
          title: 'دارایی‌های ذخیره‌شده',
          subtitle: '${store.assets.length} مورد قابل استفاده در ویرایشگر',
        ),
        const SizedBox(height: 10),
        if (store.assets.isEmpty)
          const EmptyState(
            title: 'هنوز امضا یا اثر انگشتی ذخیره نشده',
            subtitle: 'از ابزار امضا، اثر انگشت یا عکس ۳×۴ خروجی ذخیره کن.',
          ),
        ...store.assets.take(10).map((asset) => AssetListTile(store: store, asset: asset)),
      ],
    );
  }
}

class ToolGrid extends StatelessWidget {
  const ToolGrid({super.key, required this.store, this.compact = false});
  final LocalStore store;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final tools = <_ToolSpec>[
      _ToolSpec('اسکن سند', 'چندصفحه‌ای و PDF', Icons.document_scanner, () => ScannerScreen(store: store)),
      _ToolSpec('امضا', 'دستی و شفاف', Icons.draw, () => SignatureStudioScreen(store: store)),
      _ToolSpec('اثر انگشت', 'گالری و PNG شفاف', Icons.fingerprint, () => FingerprintStudioScreen(store: store)),
      _ToolSpec('عکس ۳×۴', 'برش و پس‌زمینه', Icons.badge, () => PortraitPhotoScreen(store: store)),
      _ToolSpec('OCR', 'فارسی و انگلیسی', Icons.text_snippet, () => OcrScreen(store: store)),
      _ToolSpec('حذف پس‌زمینه', 'خروجی PNG شفاف', Icons.auto_fix_high, () => BackgroundRemovalScreen(store: store)),
      _ToolSpec('ویرایش سند', 'PDF، عکس و لایه‌ها', Icons.edit_document, () => DocumentEditorScreen(store: store)),
      _ToolSpec('مهر حرفه‌ای', 'دایره‌ای و مستطیلی', Icons.verified, () => StampStudioPage(store: store)),
    ];

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: tools.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: compact ? 1.25 : 1.18,
      ),
      itemBuilder: (context, index) {
        final tool = tools[index];
        return Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => tool.builder())),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(tool.icon, color: Theme.of(context).colorScheme.primary),
                  ),
                  const SizedBox(height: 10),
                  Text(tool.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text(tool.subtitle, style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ToolSpec {
  const _ToolSpec(this.title, this.subtitle, this.icon, this.builder);
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget Function() builder;
}

class AssetListTile extends StatelessWidget {
  const AssetListTile({super.key, required this.store, required this.asset});
  final LocalStore store;
  final SavedAsset asset;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        if (!store.assets.any((item) => item.id == asset.id)) {
          return const SizedBox.shrink();
        }
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: 52,
                height: 52,
                color: Colors.white,
                child: File(asset.path).existsSync()
                    ? Image.file(File(asset.path), fit: BoxFit.contain)
                    : const Icon(Icons.broken_image_outlined),
              ),
            ),
            title: Text(asset.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(_assetKindLabel(asset.kind)),
            trailing: IconButton(
              tooltip: 'حذف',
              onPressed: () => store.deleteAsset(asset.id),
              icon: const Icon(Icons.delete_outline),
            ),
          ),
        );
      },
    );
  }
}

String _assetKindLabel(AssetKind kind) => switch (kind) {
      AssetKind.signature => 'امضا',
      AssetKind.fingerprint => 'اثر انگشت',
      AssetKind.portrait => 'عکس ۳×۴',
    };

class StampStudioPage extends StatelessWidget {
  const StampStudioPage({super.key, required this.store});
  final LocalStore store;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('مهر حرفه‌ای')),
        body: StampStudioScreen(store: store),
      ),
    );
  }
}

class ProjectPicker {
  static Future<DocumentProject?> pick(BuildContext context, LocalStore store) async {
    if (store.projects.isEmpty) {
      final name = await TextInputDialog.show(context, title: 'ساخت پرونده', hint: 'نام پرونده خروجی');
      if (name == null) return null;
      return store.createProject(name);
    }

    return showModalBottomSheet<DocumentProject>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              const SectionTitle(title: 'انتخاب پرونده', subtitle: 'خروجی در کدام پرونده ذخیره شود؟'),
              const SizedBox(height: 8),
              ListTile(
                leading: const CircleAvatar(child: Icon(Icons.create_new_folder)),
                title: const Text('پرونده جدید'),
                onTap: () async {
                  final name = await TextInputDialog.show(sheetContext, title: 'پرونده جدید', hint: 'نام پرونده');
                  if (name == null || !sheetContext.mounted) return;
                  final project = await store.createProject(name);
                  if (sheetContext.mounted) Navigator.pop(sheetContext, project);
                },
              ),
              ...store.projects.map(
                (project) => ListTile(
                  leading: Icon(project.isPrivate ? Icons.lock : Icons.folder),
                  title: Text(project.title),
                  subtitle: Text('${project.files.length} فایل'),
                  onTap: () => Navigator.pop(sheetContext, project),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GeneratedFileSaver {
  static Future<void> attach({
    required BuildContext context,
    required LocalStore store,
    required File file,
    required String type,
    required String historyTitle,
  }) async {
    final project = await ProjectPicker.pick(context, store);
    if (project == null) return;
    await store.addFile(
      project.id,
      DocumentFile(
        id: const Uuid().v4(),
        name: file.uri.pathSegments.last,
        path: file.path,
        type: type,
        createdAt: DateTime.now(),
      ),
      historyTitle,
    );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('در پرونده «${project.title}» ذخیره شد.')),
      );
    }
  }
}

class ImageOperations {
  static Uint8List applyScanFilter(Uint8List bytes, ScanFilter filter) {
    var image = im.decodeImage(bytes);
    if (image == null) throw const FormatException('تصویر قابل پردازش نیست.');
    image = im.bakeOrientation(image);
    image = _resizeLarge(image, maxSide: 1800);
    switch (filter) {
      case ScanFilter.color:
        image = im.adjustColor(image, contrast: 1.08, saturation: 1.04);
        break;
      case ScanFilter.grayscale:
        image = im.grayscale(image);
        image = im.adjustColor(image, contrast: 1.18);
        break;
      case ScanFilter.document:
        image = im.grayscale(image);
        image = im.adjustColor(image, contrast: 1.55, brightness: 1.06);
        image = _thresholdDocument(image);
        break;
    }
    return Uint8List.fromList(im.encodeJpg(image, quality: 88));
  }

  static Uint8List extractInk(Uint8List bytes, double threshold, {Color color = Colors.black}) {
    var source = im.decodeImage(bytes);
    if (source == null) throw const FormatException('تصویر قابل پردازش نیست.');
    source = im.bakeOrientation(source);
    source = _resizeLarge(source, maxSide: 1600);
    source = im.grayscale(source);
    source = im.adjustColor(source, contrast: 1.45, brightness: 1.02);
    final output = im.Image(width: source.width, height: source.height, numChannels: 4);
    final cut = (threshold * 255).round();
    final cr = (color.r * 255).round();
    final cg = (color.g * 255).round();
    final cb = (color.b * 255).round();
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        final pixel = source.getPixel(x, y);
        final light = ((pixel.r + pixel.g + pixel.b) / 3).round();
        final alpha = light >= cut ? 0 : (((cut - light) / math.max(cut, 1)) * 255).round().clamp(0, 255);
        output.setPixelRgba(x, y, cr, cg, cb, alpha);
      }
    }
    return Uint8List.fromList(im.encodePng(output));
  }

  static Uint8List removeCornerBackground(Uint8List bytes, double tolerance) {
    return removeBackgroundSmart(bytes, tolerance, protectCenter: true);
  }

  static Uint8List removeBackgroundSmart(Uint8List bytes, double tolerance, {bool protectCenter = false}) {
    var source = im.decodeImage(bytes);
    if (source == null) throw const FormatException('تصویر قابل پردازش نیست.');
    source = im.bakeOrientation(source);
    source = _resizeLarge(source, maxSide: 1600);

    final width = source.width;
    final height = source.height;
    final bg = _estimateBorderBackground(source);
    final baseThreshold = 18 + tolerance * 70;
    final brightThreshold = 26 + tolerance * 90;
    final visited = Uint8List(width * height);
    final bgMask = Uint8List(width * height);
    final queue = ListQueue<int>();

    bool insideProtectedZone(int x, int y) {
      if (!protectCenter) return false;
      final nx = (x - width / 2) / (width * 0.29);
      final ny = (y - height * 0.45) / (height * 0.36);
      return nx * nx + ny * ny <= 1.0;
    }

    void pushIfSeed(int x, int y) {
      final idx = y * width + x;
      if (visited[idx] == 1) return;
      final pixel = source.getPixel(x, y);
      final distance = _colorDistance(pixel, bg);
      final brightness = _brightnessDistance(pixel, bg);
      if (distance <= baseThreshold * 1.3 && brightness <= brightThreshold * 1.4) {
        visited[idx] = 1;
        bgMask[idx] = 1;
        queue.add(idx);
      }
    }

    for (var x = 0; x < width; x++) {
      pushIfSeed(x, 0);
      pushIfSeed(x, height - 1);
    }
    for (var y = 0; y < height; y++) {
      pushIfSeed(0, y);
      pushIfSeed(width - 1, y);
    }

    while (queue.isNotEmpty) {
      final idx = queue.removeFirst();
      final x = idx % width;
      final y = idx ~/ width;
      const neighbors = [
        Offset(1, 0),
        Offset(-1, 0),
        Offset(0, 1),
        Offset(0, -1),
      ];
      for (final step in neighbors) {
        final nx = x + step.dx.toInt();
        final ny = y + step.dy.toInt();
        if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
        final nIdx = ny * width + nx;
        if (visited[nIdx] == 1) continue;
        final pixel = source.getPixel(nx, ny);
        final distance = _colorDistance(pixel, bg);
        final brightness = _brightnessDistance(pixel, bg);
        final allowed = insideProtectedZone(nx, ny)
            ? (distance <= baseThreshold * 0.55 && brightness <= brightThreshold * 0.55)
            : (distance <= baseThreshold && brightness <= brightThreshold) ||
                (distance <= baseThreshold * 1.25 && brightness <= brightThreshold * 1.6 && _saturation(pixel) < 0.18);
        if (allowed) {
          visited[nIdx] = 1;
          bgMask[nIdx] = 1;
          queue.add(nIdx);
        }
      }
    }

    final output = im.Image(width: width, height: height, numChannels: 4);
    for (var y = 0; y < height; y++) {
      for (var x = 0; x < width; x++) {
        final idx = y * width + x;
        final pixel = source.getPixel(x, y);
        if (bgMask[idx] == 1) {
          output.setPixelRgba(x, y, pixel.r.toInt(), pixel.g.toInt(), pixel.b.toInt(), 0);
          continue;
        }
        var alpha = 255;
        var bgNeighbors = 0;
        for (var oy = -1; oy <= 1; oy++) {
          for (var ox = -1; ox <= 1; ox++) {
            if (ox == 0 && oy == 0) continue;
            final nx = x + ox;
            final ny = y + oy;
            if (nx < 0 || ny < 0 || nx >= width || ny >= height) continue;
            if (bgMask[ny * width + nx] == 1) bgNeighbors++;
          }
        }
        if (bgNeighbors > 0) {
          alpha = (255 - bgNeighbors * 18).clamp(110, 255);
        }
        output.setPixelRgba(x, y, pixel.r.toInt(), pixel.g.toInt(), pixel.b.toInt(), alpha);
      }
    }
    return Uint8List.fromList(im.encodePng(output));
  }

  static Uint8List makePortrait(Uint8List bytes, double tolerance, Color background) {
    var source = im.decodeImage(bytes);
    if (source == null) throw const FormatException('تصویر قابل پردازش نیست.');
    source = im.bakeOrientation(source);
    source = _resizeLarge(source, maxSide: 1700);

    final transparent = im.decodeImage(removeBackgroundSmart(Uint8List.fromList(im.encodePng(source)), tolerance, protectCenter: true))!;
    final box = _subjectBounds(transparent) ?? _fallbackPortraitBounds(source);
    final expanded = _expandRect(box, source.width, source.height, horizontalFactor: 0.17, topFactor: 0.22, bottomFactor: 0.12);
    final subject = im.copyCrop(transparent, x: expanded.left, y: expanded.top, width: expanded.width, height: expanded.height);

    final output = im.Image(width: 900, height: 1200, numChannels: 4);
    final br = (background.r * 255).round();
    final bg = (background.g * 255).round();
    final bb = (background.b * 255).round();
    im.fill(output, color: im.ColorRgba8(br, bg, bb, 255));

    const targetWidth = 760;
    const targetHeight = 1030;
    final fit = math.min(targetWidth / subject.width, targetHeight / subject.height);
    final renderWidth = math.max(1, (subject.width * fit).round());
    final renderHeight = math.max(1, (subject.height * fit).round());
    final resized = im.copyResize(subject, width: renderWidth, height: renderHeight, interpolation: im.Interpolation.cubic);
    final dx = ((output.width - renderWidth) / 2).round();
    final dy = math.max(40, ((output.height - renderHeight) / 2).round() - 30);
    im.compositeImage(output, resized, dstX: dx, dstY: dy, blend: im.BlendMode.direct);
    return Uint8List.fromList(im.encodePng(output));
  }

  static im.Image _resizeLarge(im.Image image, {required int maxSide}) {
    final largest = math.max(image.width, image.height);
    if (largest <= maxSide) return image;
    final scale = maxSide / largest;
    return im.copyResize(
      image,
      width: math.max(1, (image.width * scale).round()),
      height: math.max(1, (image.height * scale).round()),
      interpolation: im.Interpolation.cubic,
    );
  }

  static im.Image _thresholdDocument(im.Image image) {
    final result = im.copyCrop(image, x: 0, y: 0, width: image.width, height: image.height);
    for (var y = 0; y < result.height; y++) {
      for (var x = 0; x < result.width; x++) {
        final p = result.getPixel(x, y);
        final luma = ((p.r * .2126) + (p.g * .7152) + (p.b * .0722)).round();
        final v = luma > 172 ? 255 : (luma < 70 ? 0 : luma);
        result.setPixelRgba(x, y, v, v, v, 255);
      }
    }
    return result;
  }

  static im.Color _estimateBorderBackground(im.Image source) {
    double r = 0, g = 0, b = 0;
    var count = 0;
    final stepX = math.max(1, source.width ~/ 24);
    final stepY = math.max(1, source.height ~/ 24);
    for (var x = 0; x < source.width; x += stepX) {
      final top = source.getPixel(x, 0);
      final bottom = source.getPixel(x, source.height - 1);
      r += top.r + bottom.r;
      g += top.g + bottom.g;
      b += top.b + bottom.b;
      count += 2;
    }
    for (var y = 0; y < source.height; y += stepY) {
      final left = source.getPixel(0, y);
      final right = source.getPixel(source.width - 1, y);
      r += left.r + right.r;
      g += left.g + right.g;
      b += left.b + right.b;
      count += 2;
    }
    return im.ColorRgb8((r / count).round(), (g / count).round(), (b / count).round());
  }

  static double _colorDistance(im.Color pixel, im.Color background) {
    final dr = pixel.r - background.r;
    final dg = pixel.g - background.g;
    final db = pixel.b - background.b;
    return math.sqrt(dr * dr + dg * dg + db * db);
  }

  static double _brightnessDistance(im.Color pixel, im.Color background) {
    final pl = (pixel.r + pixel.g + pixel.b) / 3;
    final bl = (background.r + background.g + background.b) / 3;
    return (pl - bl).abs();
  }

  static double _saturation(im.Color pixel) {
    final maxValue = math.max(pixel.r, math.max(pixel.g, pixel.b));
    final minValue = math.min(pixel.r, math.min(pixel.g, pixel.b));
    if (maxValue == 0) return 0;
    return (maxValue - minValue) / maxValue;
  }

  static _Rect? _subjectBounds(im.Image image) {
    int minX = image.width, minY = image.height, maxX = -1, maxY = -1;
    for (var y = 0; y < image.height; y++) {
      for (var x = 0; x < image.width; x++) {
        if (image.getPixel(x, y).a > 24) {
          if (x < minX) minX = x;
          if (y < minY) minY = y;
          if (x > maxX) maxX = x;
          if (y > maxY) maxY = y;
        }
      }
    }
    if (maxX <= minX || maxY <= minY) return null;
    return _Rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
  }

  static _Rect _fallbackPortraitBounds(im.Image image) {
    final width = (image.width * .72).round();
    final height = (width / (3 / 4)).round().clamp(1, image.height);
    final left = ((image.width - width) / 2).round();
    final top = ((image.height - height) * .18).round().clamp(0, image.height - height);
    return _Rect(left, top, width, height);
  }

  static _Rect _expandRect(_Rect rect, int maxWidth, int maxHeight, {required double horizontalFactor, required double topFactor, required double bottomFactor}) {
    final left = math.max(0, (rect.left - rect.width * horizontalFactor).floor());
    final right = math.min(maxWidth, (rect.right + rect.width * horizontalFactor).ceil());
    final top = math.max(0, (rect.top - rect.height * topFactor).floor());
    final bottom = math.min(maxHeight, (rect.bottom + rect.height * bottomFactor).ceil());
    return _Rect(left, top, right - left, bottom - top);
  }
}

class _Rect {
  const _Rect(this.left, this.top, this.width, this.height);
  final int left;
  final int top;
  final int width;
  final int height;
  int get right => left + width;
  int get bottom => top + height;
}

class ScanPageData {
  ScanPageData({required this.path, this.filter = ScanFilter.document});
  final String path;
  ScanFilter filter;
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final picker = ImagePicker();
  final pages = <ScanPageData>[];
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('اسکن سند')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'چند صفحه ثبت کن، فیلتر هر صفحه را جدا انتخاب کن و یک PDF چندصفحه‌ای بگیر.'),
            Row(
              children: [
                Expanded(child: FilledButton.icon(onPressed: busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('دوربین'))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('گالری'))),
              ],
            ),
            const SizedBox(height: 16),
            if (pages.isEmpty)
              const EmptyState(title: 'صفحه‌ای ثبت نشده', subtitle: 'با دوربین یا گالری اولین صفحه سند را اضافه کن.'),
            ...pages.asMap().entries.map((entry) => _scanPageCard(entry.key, entry.value)),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: pages.isEmpty || busy ? null : _exportPdf,
              icon: busy ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.picture_as_pdf),
              label: const Text('ساخت PDF چندصفحه‌ای'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _scanPageCard(int index, ScanPageData page) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                Text('صفحه ${index + 1}', style: const TextStyle(fontWeight: FontWeight.w900)),
                const Spacer(),
                IconButton(onPressed: () => setState(() => pages.removeAt(index)), icon: const Icon(Icons.delete_outline)),
              ],
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(height: 230, width: double.infinity, child: _filteredPreview(page)),
            ),
            const SizedBox(height: 10),
            SegmentedButton<ScanFilter>(
              segments: const [
                ButtonSegment(value: ScanFilter.color, label: Text('رنگی')),
                ButtonSegment(value: ScanFilter.grayscale, label: Text('خاکستری')),
                ButtonSegment(value: ScanFilter.document, label: Text('سند')),
              ],
              selected: {page.filter},
              onSelectionChanged: (value) => setState(() => page.filter = value.first),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filteredPreview(ScanPageData page) {
    final image = Image.file(File(page.path), fit: BoxFit.contain);
    return switch (page.filter) {
      ScanFilter.color => image,
      ScanFilter.grayscale => ColorFiltered(colorFilter: const ColorFilter.matrix(<double>[.2126, .7152, .0722, 0, 0, .2126, .7152, .0722, 0, 0, .2126, .7152, .0722, 0, 0, 0, 0, 0, 1, 0]), child: image),
      ScanFilter.document => ColorFiltered(colorFilter: const ColorFilter.matrix(<double>[1.5, 0, 0, 0, -45, 0, 1.5, 0, 0, -45, 0, 0, 1.5, 0, -45, 0, 0, 0, 1, 0]), child: image),
    };
  }

  Future<void> _pick(ImageSource source) async {
    if (source == ImageSource.gallery) {
      final files = await picker.pickMultiImage(imageQuality: 90);
      if (files.isEmpty) return;
      setState(() => pages.addAll(files.map((file) => ScanPageData(path: file.path))));
      return;
    }
    final file = await picker.pickImage(source: source, imageQuality: 92, preferredCameraDevice: CameraDevice.rear);
    if (file == null) return;
    setState(() => pages.add(ScanPageData(path: file.path)));
  }

  Future<void> _exportPdf() async {
    setState(() => busy = true);
    try {
      if (pages.isEmpty) throw StateError('صفحه‌ای برای ساخت PDF وجود ندارد.');
      final document = pw.Document(compress: true);
      for (final page in pages) {
        final sourceBytes = await File(page.path).readAsBytes();
        final processed = ImageOperations.applyScanFilter(sourceBytes, page.filter);
        final memory = pw.MemoryImage(processed);
        document.addPage(
          pw.Page(
            pageFormat: PdfPageFormat.a4,
            margin: const pw.EdgeInsets.all(18),
            build: (_) => pw.Center(child: pw.Image(memory, fit: pw.BoxFit.contain)),
          ),
        );
      }
      final bytes = await document.save();
      final file = await widget.store.saveBytes('scan_${DateTime.now().millisecondsSinceEpoch}.pdf', bytes);
      if (mounted) {
        await GeneratedFileSaver.attach(context: context, store: widget.store, file: file, type: 'pdf', historyTitle: 'اسکن چندصفحه‌ای');
        await Printing.sharePdf(bytes: bytes, filename: file.uri.pathSegments.last);
      }
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ساخت PDF انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}

class InkCanvas extends StatefulWidget {
  const InkCanvas({super.key, required this.penWidth, this.inkColor = Colors.black, this.height = 280});
  final double penWidth;
  final Color inkColor;
  final double height;

  @override
  State<InkCanvas> createState() => InkCanvasState();
}

class InkCanvasState extends State<InkCanvas> {
  final boundaryKey = GlobalKey();
  final strokes = <InkStroke>[];

  bool get isEmpty => strokes.isEmpty;

  void clear() => setState(strokes.clear);

  void undo() {
    if (strokes.isNotEmpty) setState(() => strokes.removeLast());
  }

  Future<Uint8List> exportPng() async {
    final boundary = boundaryKey.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final image = await boundary.toImage(pixelRatio: 3);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('خروجی امضا ساخته نشد.');
    return data.buffer.asUint8List();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanStart: (details) => setState(() => strokes.add(InkStroke(points: [details.localPosition], color: widget.inkColor, width: widget.penWidth))),
      onPanUpdate: (details) => setState(() => strokes.last.points.add(details.localPosition)),
      child: Container(
        height: widget.height,
        width: double.infinity,
        decoration: BoxDecoration(
          border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
          borderRadius: BorderRadius.circular(18),
        ),
        clipBehavior: Clip.antiAlias,
        child: RepaintBoundary(
          key: boundaryKey,
          child: ColoredBox(
            color: Colors.transparent,
            child: CustomPaint(
              painter: InkStrokePainter(strokes: strokes),
            ),
          ),
        ),
      ),
    );
  }
}

class InkStrokePainter extends CustomPainter {
  const InkStrokePainter({required this.strokes});
  final List<InkStroke> strokes;

  @override
  void paint(Canvas canvas, Size size) {
    for (final stroke in strokes) {
      final paint = Paint()
        ..color = stroke.color
        ..strokeWidth = stroke.width
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..style = PaintingStyle.stroke;
      if (stroke.points.length == 1) {
        canvas.drawCircle(stroke.points.first, stroke.width / 2, paint..style = PaintingStyle.fill);
        continue;
      }
      final path = Path()..moveTo(stroke.points.first.dx, stroke.points.first.dy);
      for (var i = 1; i < stroke.points.length; i++) {
        final previous = stroke.points[i - 1];
        final current = stroke.points[i];
        final mid = Offset((previous.dx + current.dx) / 2, (previous.dy + current.dy) / 2);
        path.quadraticBezierTo(previous.dx, previous.dy, mid.dx, mid.dy);
      }
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(covariant InkStrokePainter oldDelegate) => true;
}

class SignatureStudioScreen extends StatefulWidget {
  const SignatureStudioScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<SignatureStudioScreen> createState() => _SignatureStudioScreenState();
}

class _SignatureStudioScreenState extends State<SignatureStudioScreen> {
  final padKey = GlobalKey<InkCanvasState>();
  double thickness = 3.2;
  Color color = const Color(0xFF15264D);
  String tool = 'pen';
  bool busy = false;

  double get _effectiveThickness {
    return switch (tool) {
      'fineliner' => thickness * .78,
      'marker' => thickness * 1.42,
      'brush' => thickness * 1.18,
      _ => thickness,
    };
  }

  Color get _effectiveColor {
    final opacity = switch (tool) {
      'marker' => .82,
      'brush' => .92,
      _ => 1.0,
    };
    return color.withValues(alpha: opacity);
  }

  @override
  Widget build(BuildContext context) {
    final signatures = widget.store.assets.where((asset) => asset.kind == AssetKind.signature).toList();
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ساخت امضا')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'امضا با پس‌زمینه شفاف ذخیره می‌شود. چند نوع قلم، رنگ و ضخامت برای امضای دقیق‌تر در دسترس است.'),
            const Text('نوع قلم', style: TextStyle(fontWeight: FontWeight.w800)),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _toolChip('pen', 'خودکار'),
                _toolChip('fineliner', 'روان‌نویس'),
                _toolChip('marker', 'ماژیک'),
                _toolChip('brush', 'قلم‌مو'),
              ],
            ),
            const SizedBox(height: 12),
            const Text('رنگ امضا', style: TextStyle(fontWeight: FontWeight.w800)),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _colorChip('سرمه‌ای', const Color(0xFF15264D)),
                _colorChip('مشکی', Colors.black),
                _colorChip('آبی', const Color(0xFF2157D6)),
                _colorChip('قرمز', const Color(0xFFC62828)),
                _colorChip('سبز', const Color(0xFF1B8E5A)),
              ],
            ),
            const SizedBox(height: 12),
            Text('ضخامت: ${_effectiveThickness.toStringAsFixed(1)}'),
            Slider(min: 1, max: 9, value: thickness, onChanged: (value) => setState(() => thickness = value)),
            InkCanvas(key: padKey, penWidth: _effectiveThickness, inkColor: _effectiveColor, height: 420),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: () => padKey.currentState?.undo(), icon: const Icon(Icons.undo), label: const Text('برگشت'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => padKey.currentState?.clear(), icon: const Icon(Icons.delete_sweep), label: const Text('پاک‌کردن'))),
            ]),
            const SizedBox(height: 10),
            FilledButton.icon(onPressed: busy ? null : _save, icon: const Icon(Icons.save), label: const Text('ذخیره امضا')),
            const SizedBox(height: 20),
            SectionTitle(title: 'امضاهای ذخیره‌شده', subtitle: '${signatures.length} امضا'),
            ...signatures.map((asset) => AssetListTile(store: widget.store, asset: asset)),
          ],
        ),
      ),
    );
  }

  Widget _toolChip(String value, String label) => ChoiceChip(
        label: Text(label),
        selected: tool == value,
        onSelected: (_) => setState(() => tool = value),
      );

  Widget _colorChip(String label, Color value) => ChoiceChip(
        label: Text(label),
        avatar: CircleAvatar(backgroundColor: value, radius: 9),
        selected: color.value == value.value,
        onSelected: (_) => setState(() => color = value),
      );

  Future<void> _save() async {
    final pad = padKey.currentState;
    if (pad == null || pad.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا امضا را رسم کن.')));
      return;
    }
    final name = await TextInputDialog.show(context, title: 'نام امضا', hint: 'مثلاً امضای اصلی');
    if (name == null) return;
    setState(() => busy = true);
    try {
      final bytes = await pad.exportPng();
      final file = await widget.store.saveBytes('signature_${DateTime.now().millisecondsSinceEpoch}.png', bytes);
      await widget.store.addAsset(SavedAsset(id: const Uuid().v4(), name: name.trim().isEmpty ? 'امضا' : name.trim(), path: file.path, kind: AssetKind.signature, createdAt: DateTime.now()));
      pad.clear();
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}

class FingerprintStudioScreen extends StatefulWidget {
  const FingerprintStudioScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<FingerprintStudioScreen> createState() => _FingerprintStudioScreenState();
}

class _FingerprintStudioScreenState extends State<FingerprintStudioScreen> {
  final picker = ImagePicker();
  XFile? source;
  Uint8List? preview;
  double threshold = .72;
  Color inkColor = Colors.black;
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final fingerprints = widget.store.assets.where((asset) => asset.kind == AssetKind.fingerprint).toList();
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('اثر انگشت')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'اثر انگشت فقط از تصویر موجود در گالری استخراج می‌شود و خروجی به‌صورت PNG شفاف ذخیره خواهد شد.'),
            FilledButton.icon(onPressed: _pickFromGallery, icon: const Icon(Icons.photo_library), label: const Text('انتخاب از گالری')),
            const SizedBox(height: 12),
            const Text('رنگ خروجی', style: TextStyle(fontWeight: FontWeight.w800)),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _colorChip('مشکی', Colors.black),
                _colorChip('آبی', const Color(0xFF2157D6)),
                _colorChip('قرمز', const Color(0xFFC62828)),
                _colorChip('سبز', const Color(0xFF1B8E5A)),
              ],
            ),
            const SizedBox(height: 12),
            Text('حساسیت استخراج: ${(threshold * 100).round()}٪'),
            Slider(min: .35, max: .92, value: threshold, onChanged: (value) => setState(() => threshold = value), onChangeEnd: (_) => _refreshPreview()),
            if (preview != null)
              Container(
                height: 260,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                child: Image.memory(preview!, fit: BoxFit.contain),
              )
            else
              const EmptyState(title: 'تصویر اثر انتخاب نشده', subtitle: 'اثر جوهری روی کاغذ روشن بهترین نتیجه را می‌دهد.'),
            const SizedBox(height: 10),
            FilledButton.icon(onPressed: busy ? null : _save, icon: const Icon(Icons.save), label: const Text('ذخیره اثر انگشت')),
            const SizedBox(height: 20),
            SectionTitle(title: 'اثرهای ذخیره‌شده', subtitle: '${fingerprints.length} مورد'),
            ...fingerprints.map((asset) => AssetListTile(store: widget.store, asset: asset)),
          ],
        ),
      ),
    );
  }

  Widget _colorChip(String label, Color value) => ChoiceChip(
        label: Text(label),
        avatar: CircleAvatar(backgroundColor: value, radius: 9),
        selected: inkColor.value == value.value,
        onSelected: (_) {
          setState(() => inkColor = value);
          _refreshPreview();
        },
      );

  Future<void> _pickFromGallery() async {
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 96);
    if (file == null) return;
    source = file;
    await _refreshPreview();
  }

  Future<void> _refreshPreview() async {
    if (source == null) return;
    setState(() => busy = true);
    try {
      final result = ImageOperations.extractInk(await source!.readAsBytes(), threshold, color: inkColor);
      if (mounted) setState(() => preview = result);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('پردازش اثر انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final bytes = preview;
    if (bytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا تصویر اثر انگشت را انتخاب کن.')));
      return;
    }
    final name = await TextInputDialog.show(context, title: 'نام اثر انگشت', hint: 'مثلاً انگشت اشاره');
    if (name == null) return;
    final file = await widget.store.saveBytes('fingerprint_${DateTime.now().millisecondsSinceEpoch}.png', bytes);
    await widget.store.addAsset(SavedAsset(id: const Uuid().v4(), name: name.trim().isEmpty ? 'اثر انگشت' : name.trim(), path: file.path, kind: AssetKind.fingerprint, createdAt: DateTime.now()));
    if (mounted) setState(() {});
  }
}

class PortraitPhotoScreen extends StatefulWidget {
  const PortraitPhotoScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<PortraitPhotoScreen> createState() => _PortraitPhotoScreenState();
}

class _PortraitPhotoScreenState extends State<PortraitPhotoScreen> {
  final picker = ImagePicker();
  XFile? source;
  Uint8List? result;
  Color background = Colors.white;
  double tolerance = .28;
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('عکس ۳×۴')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'صورت را روبه‌رو و نور را یکنواخت نگه‌دار. جداسازی سوژه به‌صورت هوشمند انجام می‌شود تا مو و چهره بهتر حفظ شوند و خروجی دقیق ۹۰۰×۱۲۰۰ تحویل داده شود.'),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('دوربین'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('گالری'))),
            ]),
            const SizedBox(height: 14),
            const Text('رنگ پس‌زمینه', style: TextStyle(fontWeight: FontWeight.w800)),
            Wrap(spacing: 8, children: [
              ChoiceChip(label: const Text('سفید'), selected: background == Colors.white, onSelected: (_) => setState(() => background = Colors.white)),
              ChoiceChip(label: const Text('آبی روشن'), selected: background == const Color(0xFFD9EDFF), onSelected: (_) => setState(() => background = const Color(0xFFD9EDFF))),
              ChoiceChip(label: const Text('خاکستری'), selected: background == const Color(0xFFE8E8E8), onSelected: (_) => setState(() => background = const Color(0xFFE8E8E8))),
            ]),
            const SizedBox(height: 8),
            Text('حساسیت حذف پس‌زمینه: ${(tolerance * 100).round()}٪'),
            Slider(min: .08, max: .65, value: tolerance, onChanged: (value) => setState(() => tolerance = value)),
            FilledButton.tonalIcon(onPressed: source == null || busy ? null : _process, icon: const Icon(Icons.auto_fix_high), label: const Text('پردازش و پیش‌نمایش')),
            const SizedBox(height: 14),
            Center(
              child: Container(
                width: 240,
                decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(18), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
                child: AspectRatio(
                  aspectRatio: 3 / 4,
                  child: result != null
                      ? ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.memory(result!, fit: BoxFit.cover))
                      : source != null
                          ? ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(File(source!.path), fit: BoxFit.cover))
                          : const Center(child: Icon(Icons.person, size: 72)),
                ),
              ),
            ),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: result == null || busy ? null : _save, icon: const Icon(Icons.save), label: const Text('ذخیره عکس ۳×۴')),
          ],
        ),
      ),
    );
  }

  Future<void> _pick(ImageSource imageSource) async {
    final file = await picker.pickImage(source: imageSource, imageQuality: 98, preferredCameraDevice: CameraDevice.front);
    if (file == null) return;
    setState(() {
      source = file;
      result = null;
    });
  }

  Future<void> _process() async {
    setState(() => busy = true);
    try {
      final bytes = ImageOperations.makePortrait(await source!.readAsBytes(), tolerance, background);
      if (mounted) setState(() => result = bytes);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ساخت عکس انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final name = await TextInputDialog.show(context, title: 'نام عکس', hint: 'مثلاً عکس پرسنلی');
    if (name == null || result == null) return;
    final file = await widget.store.saveBytes('portrait_${DateTime.now().millisecondsSinceEpoch}.png', result!);
    await widget.store.addAsset(SavedAsset(id: const Uuid().v4(), name: name.trim().isEmpty ? 'عکس ۳×۴' : name.trim(), path: file.path, kind: AssetKind.portrait, createdAt: DateTime.now()));
    if (mounted) await GeneratedFileSaver.attach(context: context, store: widget.store, file: file, type: 'image', historyTitle: 'ساخت عکس ۳×۴');
  }
}

class OcrScreen extends StatefulWidget {
  const OcrScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<OcrScreen> createState() => _OcrScreenState();
}

class _OcrScreenState extends State<OcrScreen> {
  final picker = ImagePicker();
  final textController = TextEditingController();
  XFile? source;
  String language = 'fas+eng';
  bool busy = false;

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تشخیص متن OCR')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'OCR کاملاً آفلاین است. تصویر صاف، نور کافی و متن چاپی نتیجه دقیق‌تری می‌دهد.'),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: busy ? null : () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('دوربین'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('گالری'))),
            ]),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'fas', label: Text('فارسی')),
                ButtonSegment(value: 'eng', label: Text('انگلیسی')),
                ButtonSegment(value: 'fas+eng', label: Text('هر دو')),
              ],
              selected: {language},
              onSelectionChanged: (value) => setState(() => language = value.first),
            ),
            if (source != null) ...[
              const SizedBox(height: 12),
              ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(File(source!.path), height: 240, fit: BoxFit.contain)),
            ],
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: source == null || busy ? null : _recognize,
              icon: busy ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.document_scanner),
              label: const Text('استخراج متن'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: textController,
              minLines: 8,
              maxLines: 18,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(labelText: 'متن استخراج‌شده', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: textController.text.isEmpty ? null : () => Clipboard.setData(ClipboardData(text: textController.text)), icon: const Icon(Icons.copy), label: const Text('کپی'))),
              const SizedBox(width: 8),
              Expanded(child: FilledButton.tonalIcon(onPressed: textController.text.isEmpty ? null : _saveText, icon: const Icon(Icons.save), label: const Text('ذخیره متن'))),
            ]),
          ],
        ),
      ),
    );
  }

  Future<void> _pick(ImageSource sourceType) async {
    final file = await picker.pickImage(source: sourceType, imageQuality: 96);
    if (file != null) setState(() => source = file);
  }

  Future<void> _recognize() async {
    setState(() => busy = true);
    try {
      final config = OCRConfig(language: language, engine: OCREngine.tesseract);
      final text = await TesseractOcr.extractText(source!.path, config: config);
      if (mounted) setState(() => textController.text = text.trim());
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('OCR انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _saveText() async {
    final bytes = Uint8List.fromList(utf8.encode(textController.text));
    final file = await widget.store.saveBytes('ocr_${DateTime.now().millisecondsSinceEpoch}.txt', bytes);
    if (mounted) await GeneratedFileSaver.attach(context: context, store: widget.store, file: file, type: 'text', historyTitle: 'ذخیره متن OCR');
  }
}

class BackgroundRemovalScreen extends StatefulWidget {
  const BackgroundRemovalScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<BackgroundRemovalScreen> createState() => _BackgroundRemovalScreenState();
}

class _BackgroundRemovalScreenState extends State<BackgroundRemovalScreen> {
  final picker = ImagePicker();
  XFile? source;
  Uint8List? result;
  double tolerance = .28;
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حذف پس‌زمینه')),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            SmartTip(enabled: widget.store.tipsEnabled, text: 'حذف پس‌زمینه با تشخیص هوشمند لبه‌ها و سوژه انجام می‌شود تا چهره و بخش‌های اصلی تصویر حذف نشوند.'),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('دوربین'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('گالری'))),
            ]),
            const SizedBox(height: 12),
            Text('حساسیت: ${(tolerance * 100).round()}٪'),
            Slider(min: .05, max: .75, value: tolerance, onChanged: (value) => setState(() => tolerance = value)),
            FilledButton.tonalIcon(onPressed: source == null || busy ? null : _process, icon: const Icon(Icons.auto_fix_high), label: const Text('حذف پس‌زمینه')),
            const SizedBox(height: 14),
            Container(
              height: 340,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                color: const Color(0xFFF0F0F0),
                border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
              ),
              child: result != null
                  ? Image.memory(result!, fit: BoxFit.contain)
                  : source != null
                      ? Image.file(File(source!.path), fit: BoxFit.contain)
                      : const Center(child: Icon(Icons.layers_clear, size: 72)),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: result == null || busy ? null : _save, icon: const Icon(Icons.save), label: const Text('ذخیره PNG شفاف')),
          ],
        ),
      ),
    );
  }

  Future<void> _pick(ImageSource imageSource) async {
    final file = await picker.pickImage(source: imageSource, imageQuality: 96);
    if (file != null) setState(() { source = file; result = null; });
  }

  Future<void> _process() async {
    setState(() => busy = true);
    try {
      final bytes = ImageOperations.removeBackgroundSmart(await source!.readAsBytes(), tolerance, protectCenter: true);
      if (mounted) setState(() => result = bytes);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حذف پس‌زمینه انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _save() async {
    final file = await widget.store.saveBytes('transparent_${DateTime.now().millisecondsSinceEpoch}.png', result!);
    if (mounted) await GeneratedFileSaver.attach(context: context, store: widget.store, file: file, type: 'image', historyTitle: 'حذف پس‌زمینه');
  }
}

class EditorLayer {
  EditorLayer({required this.id, required this.kind, required this.offset, this.text, this.path, this.stamp, this.scale = 1});
  final String id;
  final EditorOverlayKind kind;
  Offset offset;
  String? text;
  String? path;
  StampPreset? stamp;
  double scale;
}

class DocumentEditorScreen extends StatefulWidget {
  const DocumentEditorScreen({super.key, required this.store});
  final LocalStore store;

  @override
  State<DocumentEditorScreen> createState() => _DocumentEditorScreenState();
}

class _DocumentEditorScreenState extends State<DocumentEditorScreen> {
  final boundaryKey = GlobalKey();
  final pages = <Uint8List>[];
  final layers = <EditorLayer>[];
  int selectedPage = 0;
  String? selectedLayerId;
  bool busy = false;

  EditorLayer? get selectedLayer => layers.where((layer) => layer.id == selectedLayerId).firstOrNull;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('ویرایش PDF و عکس')),
        body: pages.isEmpty ? _emptyEditor() : _editorBody(),
      ),
    );
  }

  Widget _emptyEditor() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        SmartTip(enabled: widget.store.tipsEnabled, text: 'PDF به تصویر تبدیل می‌شود تا امضا، اثر انگشت، مهر و متن دقیقاً روی صفحه قرار بگیرند.'),
        const EmptyState(title: 'سندی انتخاب نشده', subtitle: 'یک PDF یا تصویر انتخاب کن و لایه‌های موردنیاز را روی آن بگذار.'),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: busy ? null : _openDocument, icon: const Icon(Icons.upload_file), label: const Text('انتخاب PDF یا عکس')),
      ],
    );
  }

  Widget _editorBody() {
    final selected = selectedLayer;
    return Column(
      children: [
        if (pages.length > 1)
          SizedBox(
            height: 64,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              itemCount: pages.length,
              itemBuilder: (_, index) => Padding(
                padding: const EdgeInsets.only(left: 6),
                child: ChoiceChip(
                  label: Text('صفحه ${index + 1}'),
                  selected: selectedPage == index,
                  onSelected: (_) => setState(() { selectedPage = index; layers.clear(); selectedLayerId = null; }),
                ),
              ),
            ),
          ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(12),
            child: Center(
              child: RepaintBoundary(
                key: boundaryKey,
                child: Container(
                  width: 340,
                  height: 480,
                  color: Colors.white,
                  child: Stack(
                    clipBehavior: Clip.hardEdge,
                    children: [
                      Positioned.fill(child: Image.memory(pages[selectedPage], fit: BoxFit.contain)),
                      ...layers.map(_layerWidget),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Material(
          elevation: 8,
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (selected != null)
                    Row(children: [
                      const Text('اندازه'),
                      Expanded(child: Slider(min: .4, max: 2.4, value: selected.scale, onChanged: (value) => setState(() => selected.scale = value))),
                      IconButton(onPressed: () => setState(() { layers.removeWhere((layer) => layer.id == selected.id); selectedLayerId = null; }), icon: const Icon(Icons.delete_outline)),
                    ]),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 5,
                    children: [
                      _editorButton(Icons.text_fields, 'متن', _addText),
                      _editorButton(Icons.draw, 'امضا/اثر', _addAsset),
                      _editorButton(Icons.verified, 'مهر', _addStamp),
                      _editorButton(Icons.image_outlined, 'PNG', _exportPng),
                      _editorButton(Icons.picture_as_pdf, 'PDF', _exportPdf),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _editorButton(IconData icon, String label, VoidCallback action) {
    return ActionChip(avatar: Icon(icon, size: 18), label: Text(label), onPressed: busy ? null : action);
  }

  Widget _layerWidget(EditorLayer layer) {
    Widget child;
    if (layer.kind == EditorOverlayKind.text) {
      child = Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
        color: Colors.white.withValues(alpha: .7),
        child: Text(layer.text ?? '', style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.black, fontSize: 18)),
      );
    } else if (layer.kind == EditorOverlayKind.image) {
      child = Image.file(File(layer.path!), width: 120, height: 80, fit: BoxFit.contain);
    } else {
      final stamp = layer.stamp!;
      child = StampPreview(text: stamp.text, shape: stamp.shape, opacity: stamp.opacity, size: 100);
    }
    return Positioned(
      left: layer.offset.dx,
      top: layer.offset.dy,
      child: GestureDetector(
        onTap: () => setState(() => selectedLayerId = layer.id),
        onPanUpdate: (details) => setState(() {
          selectedLayerId = layer.id;
          layer.offset = Offset(
            (layer.offset.dx + details.delta.dx).clamp(0.0, 300.0).toDouble(),
            (layer.offset.dy + details.delta.dy).clamp(0.0, 440.0).toDouble(),
          );
        }),
        child: Transform.scale(
          scale: layer.scale,
          alignment: Alignment.topLeft,
          child: DecoratedBox(
            decoration: BoxDecoration(border: Border.all(color: selectedLayerId == layer.id ? Colors.blue : Colors.transparent, width: 1.5)),
            child: child,
          ),
        ),
      ),
    );
  }

  Future<void> _openDocument() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: const ['pdf', 'jpg', 'jpeg', 'png'], allowMultiple: false);
    if (result == null || result.files.single.path == null) return;
    final path = result.files.single.path!;
    setState(() => busy = true);
    try {
      final extension = result.files.single.extension?.toLowerCase();
      final loaded = <Uint8List>[];
      if (extension == 'pdf') {
        final bytes = await File(path).readAsBytes();
        await for (final raster in Printing.raster(bytes, dpi: 130)) {
          loaded.add(await raster.toPng());
        }
      } else {
        loaded.add(await File(path).readAsBytes());
      }
      if (loaded.isEmpty) throw StateError('صفحه‌ای از سند خوانده نشد.');
      if (mounted) setState(() { pages.addAll(loaded); selectedPage = 0; });
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('بازکردن سند انجام نشد: $error')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _addText() async {
    final text = await TextInputDialog.show(context, title: 'متن روی سند', hint: 'متن را وارد کن');
    if (text == null || text.trim().isEmpty) return;
    final layer = EditorLayer(id: const Uuid().v4(), kind: EditorOverlayKind.text, offset: const Offset(90, 80), text: text.trim());
    setState(() { layers.add(layer); selectedLayerId = layer.id; });
  }

  Future<void> _addAsset() async {
    final candidates = widget.store.assets.where((asset) => asset.kind != AssetKind.portrait).toList();
    if (candidates.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا یک امضا یا اثر انگشت ذخیره کن.')));
      return;
    }
    final asset = await showModalBottomSheet<SavedAsset>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: candidates.map((item) => ListTile(leading: Image.file(File(item.path), width: 54, height: 54, fit: BoxFit.contain), title: Text(item.name), subtitle: Text(_assetKindLabel(item.kind)), onTap: () => Navigator.pop(sheetContext, item))).toList(),
        ),
      ),
    );
    if (asset == null) return;
    final layer = EditorLayer(id: const Uuid().v4(), kind: EditorOverlayKind.image, offset: const Offset(100, 130), path: asset.path);
    setState(() { layers.add(layer); selectedLayerId = layer.id; });
  }

  Future<void> _addStamp() async {
    final stamp = await showModalBottomSheet<StampPreset>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: widget.store.stamps.map((item) => ListTile(leading: StampPreview(text: item.text, shape: item.shape, opacity: item.opacity, size: 52), title: Text(item.text), onTap: () => Navigator.pop(sheetContext, item))).toList(),
        ),
      ),
    );
    if (stamp == null) return;
    final layer = EditorLayer(id: const Uuid().v4(), kind: EditorOverlayKind.stamp, offset: const Offset(110, 180), stamp: stamp);
    setState(() { layers.add(layer); selectedLayerId = layer.id; });
  }

  Future<Uint8List> _captureEditedPage() async {
    setState(() => selectedLayerId = null);
    await WidgetsBinding.instance.endOfFrame;
    final boundary = boundaryKey.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final image = await boundary.toImage(pixelRatio: 3);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) throw StateError('خروجی صفحه ساخته نشد.');
    return data.buffer.asUint8List();
  }

  Future<void> _exportPng() async {
    setState(() => busy = true);
    try {
      final bytes = await _captureEditedPage();
      final file = await widget.store.saveBytes('edited_${DateTime.now().millisecondsSinceEpoch}.png', bytes);
      if (mounted) {
        await GeneratedFileSaver.attach(
          context: context,
          store: widget.store,
          file: file,
          type: 'image',
          historyTitle: 'ویرایش تصویر سند',
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ساخت PNG انجام نشد: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _exportPdf() async {
    setState(() => busy = true);
    try {
      final edited = await _captureEditedPage();
      final outputPages = [...pages];
      outputPages[selectedPage] = edited;
      final document = pw.Document(compress: true);
      for (final page in outputPages) {
        final memory = pw.MemoryImage(page);
        document.addPage(
          pw.Page(
            pageFormat: PdfPageFormat.a4,
            margin: const pw.EdgeInsets.all(12),
            build: (_) => pw.Center(child: pw.Image(memory, fit: pw.BoxFit.contain)),
          ),
        );
      }
      final bytes = await document.save();
      final file = await widget.store.saveBytes('edited_${DateTime.now().millisecondsSinceEpoch}.pdf', bytes);
      if (mounted) {
        await GeneratedFileSaver.attach(
          context: context,
          store: widget.store,
          file: file,
          type: 'pdf',
          historyTitle: 'ویرایش PDF و افزودن لایه',
        );
        await Printing.sharePdf(bytes: bytes, filename: file.uri.pathSegments.last);
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ساخت PDF انجام نشد: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
}

class ChangeNotifierProviderLite extends InheritedNotifier<LocalStore> {
  const ChangeNotifierProviderLite({super.key, required LocalStore notifier, required super.child}) : super(notifier: notifier);
}

extension IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull => isEmpty ? null : first;
}
