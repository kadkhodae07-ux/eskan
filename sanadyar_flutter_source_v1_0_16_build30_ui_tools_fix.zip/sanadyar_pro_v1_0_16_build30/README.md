# Sanadyar Pro — Build 30

Sanadyar is a Flutter-based Persian document utility app with document scanning, OCR, signatures, fingerprint extraction, portrait 3x4 creation, background removal and PDF/image editing.

## Build 30 highlights

- improved stamp creation and selection flow
- smarter multi-page scanner flow for gallery images
- larger signature studio with extra pen styles and colors
- gallery-only transparent fingerprint extraction with color output
- more reliable background removal and 3x4 portrait generation

See `CHANGELOG.md` for the full change list.
