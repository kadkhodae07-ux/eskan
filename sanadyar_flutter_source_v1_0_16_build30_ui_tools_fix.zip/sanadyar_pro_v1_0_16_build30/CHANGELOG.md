# Sanadyar 1.0.16+30

## Added / Improved

- Reworked stamp studio with name + family-name input, more stamp shapes and richer presets.
- Expanded signature studio with a larger drawing area, multiple pen styles and more colors.
- Fingerprint extraction is now gallery-only with transparent PNG output and selectable output colors.
- Portrait 3x4 generation now uses improved subject-preserving background removal and cleaner composition.
- Background removal switched from naive corner deletion to edge-aware flood-fill with protected central subject logic.
- Scanner gallery flow now supports multi-image selection and lower-memory PDF generation for multi-page scans.

## Fixed

- Prevented the scanner PDF crash path after gallery import by using batch-safe image selection and pre-resized page processing.
- Fixed fingerprint saving so the extracted mark is stored as transparent PNG without its original background.
- Improved background removal behavior so it no longer erases the full face/body area in common portrait cases.

## Toolchain

- Flutter: 3.44.6
- Java: 17
- Android compile/target SDK: 36
- Android min SDK: 24
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3
- Kotlin Gradle Plugin: 2.2.20
