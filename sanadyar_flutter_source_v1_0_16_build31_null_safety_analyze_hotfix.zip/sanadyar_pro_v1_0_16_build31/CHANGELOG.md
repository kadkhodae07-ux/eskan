# Sanadyar 1.0.16+31

## Fixed

- Fixed the Build 30 `flutter analyze` failure in `ImageOperations.removeBackgroundSmart`.
- The decoded image is now promoted to a non-null local before being captured by the flood-fill seed closure, so `getPixel` is type-safe under Dart 3.12.2.
- Replaced deprecated `Color.value` comparisons with `Color.toARGB32()`.
- Removed the redundant `dart:typed_data` import from the vendored OCR wrapper.

## Preserved from Build 30

- Reworked stamp studio with name + family-name input, multiple seal shapes and richer presets.
- Expanded signature studio with a larger canvas, multiple pen styles, thickness controls and additional colors.
- Gallery-only fingerprint extraction with transparent PNG output and selectable ink colors.
- Improved portrait 3x4 generation and edge-aware background removal.
- Batch-safe multi-image gallery scanning and lower-memory multi-page PDF generation.

## Toolchain

- Flutter: 3.44.6
- Dart: 3.12.2
- Java: 17
- Android compile/target SDK: 36
- Android min SDK: 24
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3
- Kotlin Gradle Plugin: 2.2.20
