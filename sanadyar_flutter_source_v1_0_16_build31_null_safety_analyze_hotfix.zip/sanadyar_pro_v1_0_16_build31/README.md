# Sanadyar Pro — Build 31

Sanadyar is a Flutter-based Persian document utility app with document scanning, OCR, signatures, fingerprint extraction, portrait 3x4 creation, background removal and PDF/image editing.

## Build 31 focus

Build 31 is a compile/analyzer hotfix over Build 30. It preserves the Build 30 UI and feature changes while correcting the nullable image capture that stopped GitHub Actions during `flutter analyze`.

## Included regression coverage

The existing Flutter test suite exercises background removal with a generated image and verifies that the output is a decodable transparent PNG while preserving the central foreground pixel.

See `CHANGELOG.md` and `VALIDATION_REPORT.md` for details.
