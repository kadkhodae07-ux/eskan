# Validation Report — Sanadyar 1.0.16+31

Build 31 was prepared from the supplied Build 30 source and the supplied Build 30 GitHub Actions diagnostics.

## Root cause confirmed

The failed job reached Flutter dependency resolution and OCR/Gradle preflight successfully, then stopped in `flutter analyze` at `lib/main.dart:1487`:

- `source` originated from nullable `im.decodeImage(bytes)`.
- Although a null check existed, `source` was captured by the nested `pushIfSeed` closure.
- Dart flow analysis therefore did not preserve non-null promotion inside that closure.
- Calling `source.getPixel(...)` produced `unchecked_use_of_nullable_value`.

## Corrections applied

- Introduced a final nullable decode result, checked it, then created a separate non-null mutable image variable.
- Replaced all three deprecated `Color.value` comparisons with `Color.toARGB32()`.
- Removed the unnecessary `dart:typed_data` import in the local OCR plugin.
- Updated app and workflow versioning from `1.0.16+30` to `1.0.16+31`.

## Package checks completed

- ZIP integrity and source-tree structure
- Required `pubspec.yaml` and `lib/main.dart`
- Build/version consistency
- Package name preservation: `mk.kadkhodai.sanadyar`
- OCR trained-data presence and size
- Local OCR Java-only source structure
- Workflow YAML parse
- Workflow shell syntax extraction checks
- SHA-256 manifest regeneration and verification
- Search for stale Build 30 identifiers in Build 31 deliverables

Full Flutter analyze, tests and Android APK compilation are executed by the included GitHub Actions workflow because the local packaging runtime does not include Flutter 3.44.6 or the Android SDK.
