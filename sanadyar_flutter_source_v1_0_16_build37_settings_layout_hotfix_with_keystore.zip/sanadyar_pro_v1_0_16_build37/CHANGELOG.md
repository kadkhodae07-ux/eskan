# Sanadyar 1.0.16+37

## Fixed

- Fixed the broken Settings layout shown in the runtime video.
- The private-folder action no longer inherits the global full-width FilledButton constraint inside `ListTile.trailing`.
- Persian settings text no longer collapses into a one-character-wide vertical column.
- Replaced the debug-looking lock test control with a constrained professional action and explicit success/failure feedback.

## Verified from video

- Support ticket history screen opens correctly.
- Seven taps on the app version opens the admin login screen.
- Admin authentication succeeds and the management dashboard loads.
