# Sanadyar Pro — Build 37

Build 37 is a focused runtime UI hotfix over Build 36. It fixes the Settings-screen layout corruption caused by a globally full-width FilledButton used as a ListTile trailing action.
