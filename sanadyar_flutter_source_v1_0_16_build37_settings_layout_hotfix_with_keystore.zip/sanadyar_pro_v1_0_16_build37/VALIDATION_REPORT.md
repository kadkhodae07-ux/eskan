# Validation report — Build 37

- Version updated to `1.0.16+37`.
- Settings private-folder action is width-constrained.
- The action overrides the global button minimum size.
- Support and hidden admin flows are preserved.
