# Validation report — Build 34 / WF-34.1

## Static validation completed

- Source version verified as `1.0.16+34`.
- Workflow version code verified as `34`.
- Dart lexical delimiters and top-level declaration uniqueness checked.
- Current Flutter 3.44 theme data types used (`AppBarThemeData`, `InputDecorationThemeData`, `CardThemeData`).
- Workflow YAML parsed successfully.
- All 21 workflow `run` blocks passed `bash -n` syntax validation.
- All Python tools passed `py_compile`.
- Android storage-manifest configuration was executed against a fixture and verified.
- Source-selection marker validation passed.
- ZIP extraction preserves executable mode `755` for all helper tools.

## Exact-source selection scenarios

- With Build 33 and Build 34 source ZIPs present together, only the real `1.0.16+34` source was selected.
- With only Build 33 present, selection failed as designed; an older source was not promoted by rewriting `pubspec.yaml`.
- With only a complete pack present, WF-34.1 located and verified the nested Build 34 source ZIP.

## Regression coverage included

- Stamp styling JSON compatibility and legacy defaults.
- Real stamp inset normalization.
- Synthetic person-segmentation mask alpha behavior.
- Binary OCR preprocessing and output padding.
- Persian OCR cleanup.
- Transparent background removal.
- Exact 900×1200 portrait output.

## Environment limitation

The current artifact environment does not include the Flutter SDK or Android SDK components. Final `flutter pub get`, `flutter analyze`, Flutter tests and APK compilation are executed by the included GitHub Actions workflow.
