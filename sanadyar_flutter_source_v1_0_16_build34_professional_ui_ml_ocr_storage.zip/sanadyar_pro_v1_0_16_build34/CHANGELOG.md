# Sanadyar 1.0.16+34

## Professional tool UI

- Added a shared compact design system for tool headers, panels, color selection, advanced settings and fixed bottom actions.
- Reworked signature, stamp, scanner, fingerprint, portrait, OCR and background-removal screens.
- Moved saved signatures, stamps and fingerprints to dedicated bottom sheets instead of long inline lists.

## Signature

- Replaced the scrolling signature page with a fixed canvas and bottom toolbar.
- Removed the parent scroll gesture that competed with signature drawing.
- Pen type, color and thickness can restyle existing strokes in real time.
- Added clear output choices for Sanadyar, gallery and phone storage.

## Stamp

- Text spacing now changes the actual inner padding of the stamp preview and stored preset.
- Replaced the raw numeric weight slider with readable weight presets.
- Added compact shape, color, weight, spacing and opacity controls.
- Added an exportable transparent PNG preview and explicit output destinations.

## Portrait and background removal

- Added Google ML Kit face detection and selfie segmentation for face-aware framing and person-aware masking.
- Added face-based 3×4 framing and confidence feathering to preserve face, hair, neck and clothing edges.
- Retained the existing offline image heuristic as a fallback when ML segmentation is unavailable.
- Portrait output remains exactly 900×1200 pixels.

## OCR

- Added document, label and receipt preprocessing profiles.
- Added light-region detection for labels, grayscale/contrast processing, denoise, Otsu binarization, padding and manual deskew.
- Passed page segmentation and inter-word-space settings to the vendored Android Tesseract engine.
- Added Persian letter normalization and noise-line cleanup.

## Output and storage

- Added explicit destinations for internal Sanadyar storage, gallery and user-selected phone folders.
- Removed implicit sharing from save operations.
- Added Android gallery-storage configuration to WF-34.1.

## Stability

- Kept multi-page PDF generation off the UI thread.
- Moved fingerprint extraction and OCR preprocessing to background isolates.
- Added regression tests for stamp spacing, person masks, OCR preprocessing and Persian cleanup.
