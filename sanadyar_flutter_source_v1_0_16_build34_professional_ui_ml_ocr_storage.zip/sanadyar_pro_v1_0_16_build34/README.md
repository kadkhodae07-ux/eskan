# Sanadyar Pro — Build 34

Sanadyar is a Persian Flutter document utility for scanning, signatures, stamps, fingerprint extraction, portrait photos, background removal, OCR and PDF editing.

## Build 34 focus

Build 34 replaces the long, chip-heavy tool screens with a shared professional tool layout. Frequently used controls stay visible, advanced settings collapse when not needed, previews receive visual priority and final actions remain fixed at the bottom of each screen.

Key changes:

- A fixed signature workspace that does not scroll or move while drawing.
- Real stamp text-to-border spacing and compact professional stamp controls.
- ML Kit face detection plus person segmentation for face-aware portrait framing and transparent-background tools, with an offline heuristic fallback.
- OCR profiles for documents, labels and receipts with preprocessing, Tesseract page-segmentation settings and Persian text cleanup.
- Explicit output destinations: Sanadyar, phone gallery or a user-selected device folder.
- Background-isolate processing for scan PDF, fingerprint and OCR image preparation.

## Toolchain

- Flutter 3.44.6 / Dart 3.12.2
- Java 17
- compileSdk / targetSdk 36
- minSdk 24
- Workflow WF-34.1
