package io.paratoner.tesseract_ocr;

import android.os.Handler;
import android.os.Looper;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

public final class TesseractOcrPlugin implements FlutterPlugin, MethodChannel.MethodCallHandler {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private ExecutorService executor;
    private MethodChannel channel;

    @Override
    public void onAttachedToEngine(FlutterPluginBinding binding) {
        executor = Executors.newSingleThreadExecutor();
        channel = new MethodChannel(binding.getBinaryMessenger(), "tesseract_ocr");
        channel.setMethodCallHandler(this);
    }

    @Override
    public void onDetachedFromEngine(FlutterPluginBinding binding) {
        if (channel != null) {
            channel.setMethodCallHandler(null);
            channel = null;
        }
        if (executor != null) {
            executor.shutdownNow();
            executor = null;
        }
    }

    @Override
    public void onMethodCall(MethodCall call, MethodChannel.Result result) {
        if (!"extractText".equals(call.method) && !"extractHocr".equals(call.method)) {
            result.notImplemented();
            return;
        }

        final String tessDataPath = call.argument("tessData");
        final String imagePath = call.argument("imagePath");
        final String language = resolveLanguage(call);
        final Map<?, ?> config = resolveConfig(call);

        if (tessDataPath == null || tessDataPath.trim().isEmpty()) {
            result.error("INVALID_ARGUMENT", "Data path must not be null or empty.", null);
            return;
        }
        if (imagePath == null || imagePath.trim().isEmpty()) {
            result.error("INVALID_ARGUMENT", "Image path must not be null or empty.", null);
            return;
        }

        final File imageFile = new File(imagePath);
        if (!imageFile.isFile()) {
            result.error("IMAGE_NOT_FOUND", "Image file does not exist: " + imagePath, null);
            return;
        }

        final boolean hocr = "extractHocr".equals(call.method);
        final ExecutorService worker = executor;
        if (worker == null || worker.isShutdown()) {
            result.error("PLUGIN_DETACHED", "OCR plugin is not attached to a Flutter engine.", null);
            return;
        }
        worker.execute(() -> recognize(tessDataPath, imageFile, language, config, hocr, result));
    }

    private String resolveLanguage(MethodCall call) {
        final String directLanguage = call.argument("language");
        if (directLanguage != null && !directLanguage.trim().isEmpty()) {
            return directLanguage;
        }

        final Object configObject = call.argument("config");
        if (configObject instanceof Map) {
            final Object configured = ((Map<?, ?>) configObject).get("language");
            if (configured != null && !configured.toString().trim().isEmpty()) {
                return configured.toString();
            }
        }
        return "eng";
    }


    private Map<?, ?> resolveConfig(MethodCall call) {
        final Object configObject = call.argument("config");
        if (configObject instanceof Map) {
            return (Map<?, ?>) configObject;
        }
        return java.util.Collections.emptyMap();
    }

    private void recognize(
            String tessDataPath,
            File imageFile,
            String language,
            Map<?, ?> config,
            boolean hocr,
            MethodChannel.Result result
    ) {
        final TessBaseAPI api = new TessBaseAPI();
        try {
            final boolean initialized = api.init(tessDataPath, language);
            if (!initialized) {
                postError(result, "INIT_ERROR", "Tesseract failed to initialize for language: " + language);
                return;
            }

            final int pageSegMode = resolvePageSegMode(config);
            api.setPageSegMode(pageSegMode);
            api.setVariable("preserve_interword_spaces", resolveString(config, "preserve_interword_spaces", "1"));
            api.setVariable("user_defined_dpi", "300");
            api.setVariable("textord_min_linesize", "2.5");
            api.setImage(imageFile);
            final String recognized = hocr ? api.getHOCRText(0) : api.getUTF8Text();
            postSuccess(result, recognized == null ? "" : recognized);
        } catch (Throwable error) {
            postError(result, "OCR_ERROR", error.getMessage() == null ? error.toString() : error.getMessage());
        } finally {
            api.recycle();
        }
    }


    private int resolvePageSegMode(Map<?, ?> config) {
        final String raw = resolveString(config, "tessedit_pageseg_mode", Integer.toString(TessBaseAPI.PageSegMode.PSM_AUTO));
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException ignored) {
            return TessBaseAPI.PageSegMode.PSM_AUTO;
        }
    }

    private String resolveString(Map<?, ?> config, String key, String fallback) {
        final Object value = config.get(key);
        if (value == null) {
            return fallback;
        }
        final String text = value.toString().trim();
        return text.isEmpty() ? fallback : text;
    }

    private void postSuccess(MethodChannel.Result result, String value) {
        mainHandler.post(() -> result.success(value));
    }

    private void postError(MethodChannel.Result result, String code, String message) {
        mainHandler.post(() -> result.error(code, message, null));
    }
}
