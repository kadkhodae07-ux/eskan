# گزارش اعتبارسنجی — سندیار Build 42 / WF-42.1

## خطای ورودی Build 41

- `flutter analyze`: موفق
- `flutter test`: موفق
- تفکیک Dependency بازار/مایکت: موفق
- شکست در `:app:minifyBazaarReleaseWithR8`
- کلاس‌های مفقود گزارش‌شده:
  - `com.mbridge.msdk.nativex.view.MBMediaView`
  - `com.mbridge.msdk.video.bt.module.orglistener.g`

## اصلاح انجام‌شده

- قواعد Adivery/MBridge در فایل نسخه‌بندی‌شده مستقل قرار گرفت.
- Workflow فایل قواعد را پس از ساخت Android به `android/app/proguard-rules.pro` منتقل می‌کند.
- قواعد اصلی قبل از Build با اسکریپت مستقل بررسی می‌شوند.
- Retry خودکار فقط در صورت وجود `missing_rules.txt` و فقط برای `-dontwarn`های شبکه‌های تبلیغاتی Allowlist‌شده اجرا می‌شود.
- Retry حداکثر یک مرتبه است و هر قاعده افزوده‌شده در گزارش ذخیره می‌شود.

## کنترل‌های بسته

- نسخه `1.0.16+42` در `pubspec.yaml`، `AppBuildInfo` و تست‌ها هماهنگ است.
- قواعد موردنیاز Adivery و MBridge موجودند.
- Workflow با parser YAML بررسی شده است.
- تمام ZIPها با CRC و مسیرهای امن بررسی شده‌اند.
- Keystore داخل سورس حفظ شده است.

## محدودیت محیط

Flutter SDK در محیط محلی موجود نیست؛ کامپایل واقعی APK در GitHub Actions انجام می‌شود. Workflow تحلیل، تست، بررسی Dependency Graph، اعتبارسنجی R8 و ساخت دو APK را اجباری می‌کند.
