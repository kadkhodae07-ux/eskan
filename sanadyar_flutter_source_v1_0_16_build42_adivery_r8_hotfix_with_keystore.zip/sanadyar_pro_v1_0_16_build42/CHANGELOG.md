# سندیار 1.0.16+42

## اصلاح اصلی Build 42

- رفع شکست `:app:minifyBazaarReleaseWithR8`.
- افزودن قواعد جامع Adivery برای شبکه‌های mediation اختیاری.
- افزودن `-dontwarn com.mbridge.msdk.**` برای پوشش کلاس‌های `MBMediaView` و `orglistener.g` گزارش‌شده در Build 41.
- حفظ کلاس‌ها و Interfaceهای `com.adivery.**` هنگام Minify.
- افزودن اعتبارسنجی مستقل قواعد R8 پیش از Build.
- افزودن بازیابی کنترل‌شده از `missing_rules.txt` فقط برای Namespaceهای تبلیغاتی Allowlist‌شده و تنها با یک Retry.

## موارد حفظ‌شده

- جداسازی کامل Billing بازار و مایکت.
- تبلیغات همسان، ویدئویی و تمام‌صفحه Adivery.
- دسترسی یک‌ساعته با هر تبلیغ ویدئویی کامل.
- اشتراک Pro ماهانه بازار و مایکت.
- رفع تبدیل امن داده‌های تیکت و مهرهای قدیمی.
- Keystore و امضای Release قبلی.
