# سندیار — Flutter 1.0.16+42

این نسخه خطای Release مربوط به R8 و کلاس‌های اختیاری MBridge در Adivery را رفع می‌کند و جداسازی Billing بازار/مایکت Build 41 را حفظ می‌کند.

## اصلاح Build 42

- فایل قواعد Release اختصاصی Adivery در `tool/adivery-proguard-rules.pro` اضافه شد.
- هشدارهای کلاس‌های شبکه‌های واسط اختیاری، به‌خصوص `com.mbridge.msdk.**`، برای R8 مدیریت می‌شوند.
- کلاس‌های اصلی Adivery برای جلوگیری از حذف اشتباه در Minify حفظ می‌شوند.
- Workflow قبل از Build قواعد را اعتبارسنجی می‌کند.
- در صورت تولید `missing_rules.txt` برای شبکه‌های تبلیغاتی اختیاری، فقط قواعد `-dontwarn` متعلق به Allowlist تبلیغاتی اضافه و Build یک‌بار تکرار می‌شود.

## ساخت دو نسخه فروشگاهی

- بازار: فقط `flutter_poolakey` و Adapter بازار
- مایکت: فقط `myket_iap` و Adapter مایکت

## تنظیمات GitHub

- Variable: `SANADYAR_API_BASE_URL`
- Variable اختیاری: `SANADYAR_PRO_PRODUCT_ID`؛ پیش‌فرض `sanadyar_pro_monthly`
- Secret: `SANADYAR_BAZAAR_RSA_KEY`
- Secret: `SANADYAR_MYKET_RSA_KEY`

## تبلیغات Adivery

- App ID: `1cced1a2-7651-4886-88ae-40bb836351e2`
- Native: `d826715d-efaa-4760-8e3c-4f1926daccb5`
- Rewarded: `1f94d8a9-cbc0-48d4-88a6-898cd45f4384`
- Interstitial: `f633fe88-25fa-407b-bd5c-dd681b5ac63c`
