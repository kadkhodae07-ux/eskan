#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path

ALLOWED_PREFIXES = (
    'com.adivery.',
    'com.mbridge.msdk.',
    'com.chartboost.sdk.',
    'com.adcolony.sdk.',
    'com.google.ads.interactivemedia.',
    'com.google.android.gms.ads.',
    'com.google.android.gms.internal.ads.',
    'com.google.common.',
    'com.unity3d.',
    'com.ironsource.',
    'com.startapp.',
)
RULE_RE = re.compile(r'^-dontwarn\s+([^\s]+)\s*$')


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('missing_rules', type=Path)
    parser.add_argument('target_rules', type=Path)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()

    if not args.missing_rules.is_file():
        raise SystemExit(f'R8 missing_rules.txt not found: {args.missing_rules}')
    if not args.target_rules.is_file():
        raise SystemExit(f'ProGuard target file not found: {args.target_rules}')

    existing = args.target_rules.read_text(encoding='utf-8')
    accepted: list[str] = []
    rejected: list[str] = []
    for raw in args.missing_rules.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        match = RULE_RE.fullmatch(line)
        if not match:
            rejected.append(line)
            continue
        pattern = match.group(1)
        if not pattern.startswith(ALLOWED_PREFIXES):
            rejected.append(line)
            continue
        if line not in existing and line not in accepted:
            accepted.append(line)

    if not accepted:
        raise SystemExit(
            'R8 produced no new allow-listed optional mediation rules. '
            f'Rejected entries: {rejected}'
        )

    with args.target_rules.open('a', encoding='utf-8') as handle:
        handle.write('\n# Automatically imported from R8 missing_rules.txt after first release attempt.\n')
        for line in accepted:
            handle.write(line + '\n')

    args.report.parent.mkdir(parents=True, exist_ok=True)
    report = [
        'status=patched',
        f'missing_rules={args.missing_rules}',
        f'target_rules={args.target_rules}',
        f'target_sha256={sha256(args.target_rules)}',
        'accepted_rules:',
        *[f'  {line}' for line in accepted],
    ]
    if rejected:
        report.extend(['rejected_rules:', *[f'  {line}' for line in rejected]])
    args.report.write_text('\n'.join(report) + '\n', encoding='utf-8')
    print('\n'.join(report))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
