# Sanadyar release shrinker rules — Build 42
# Core OCR / ML Kit runtime.
-keep class io.paratoner.tesseract_ocr.** { *; }
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
-dontwarn org.tensorflow.lite.**

# Preserve annotations/signatures used by Android SDKs and reflection.
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Adivery Flutter plugin and Android SDK.
-keep class com.adivery.** { *; }
-keep interface com.adivery.** { *; }
-dontwarn com.adivery.**
-dontwarn com.adivery.data.**

# Optional Adivery mediation networks. These adapters may be present in the
# Adivery SDK even when the corresponding network SDK is intentionally absent.
-dontwarn com.chartboost.sdk.**
-dontwarn com.adcolony.sdk.**
-dontwarn com.google.ads.interactivemedia.v3.api.**
-dontwarn com.google.android.gms.ads.**
-dontwarn com.google.android.gms.internal.ads.**
-dontwarn com.google.common.**
-dontwarn com.unity3d.**
-dontwarn com.ironsource.mediationsdk.**
-dontwarn com.mbridge.msdk.**
-dontwarn com.startapp.sdk.**

# Exact Build 41 R8 missing classes retained as explicit regression guards.
-dontwarn com.mbridge.msdk.nativex.view.MBMediaView
-dontwarn com.mbridge.msdk.video.bt.module.orglistener.g
