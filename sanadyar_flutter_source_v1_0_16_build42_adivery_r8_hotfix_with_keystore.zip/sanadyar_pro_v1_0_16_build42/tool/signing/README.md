# Release signing package

This directory contains the packaged release keystore used only by the GitHub Actions workflow.
Keep the repository private. Do not publish this package or its passwords.
