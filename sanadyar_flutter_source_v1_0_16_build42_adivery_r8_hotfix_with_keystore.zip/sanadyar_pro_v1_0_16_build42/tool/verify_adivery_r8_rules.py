#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

REQUIRED = (
    '-keep class com.adivery.** { *; }',
    '-dontwarn com.adivery.**',
    '-dontwarn com.mbridge.msdk.**',
    '-dontwarn com.google.android.gms.ads.**',
    '-dontwarn com.google.android.gms.internal.ads.**',
    '-dontwarn com.chartboost.sdk.**',
    '-dontwarn com.adcolony.sdk.**',
    '-dontwarn com.unity3d.**',
    '-dontwarn com.ironsource.mediationsdk.**',
    '-dontwarn com.startapp.sdk.**',
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('rules', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()

    if not args.rules.is_file():
        raise SystemExit(f'R8 rules file not found: {args.rules}')
    text = args.rules.read_text(encoding='utf-8')
    missing = [rule for rule in REQUIRED if rule not in text]
    if missing:
        raise SystemExit(f'Missing required Adivery R8 rules: {missing}')

    lines = [
        'status=ok',
        f'path={args.rules}',
        f'sha256={sha256(args.rules)}',
        f'required_rule_count={len(REQUIRED)}',
    ]
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
