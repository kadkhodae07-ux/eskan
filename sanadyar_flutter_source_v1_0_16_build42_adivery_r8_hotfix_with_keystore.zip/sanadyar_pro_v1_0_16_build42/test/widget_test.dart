import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:sanadyar/main.dart';

void main() {
  test('Build 42 version metadata is exact', () {
    expect(AppBuildInfo.versionLabel, '1.0.16+42');
  });


  test('Build 42 identity and store defaults are stable', () {
    expect(AppBuildInfo.versionLabel, '1.0.16+42');
    expect(AppBuildInfo.storeChannel, isNotEmpty);
  });

  test('Sanadyar app root can be constructed', () {
    expect(const SanadyarApp(), isA<SanadyarApp>());
  });


  test('Ticket JSON safely accepts string-encoded numeric fields', () {
    final ticket = SupportTicket.fromJson({
      'id': '42',
      'title': 'نمونه',
      'status': 'open',
      'created_at': '2026-07-28T10:00:00Z',
      'updated_at': '2026-07-28T10:05:00Z',
      'unread_count': '3',
    });

    expect(ticket.id, 42);
    expect(ticket.unreadCount, 3);
  });

  test('Legacy stamp JSON safely accepts string-encoded style numbers', () {
    final stamp = StampPreset.fromJson({
      'id': 'stamp-string-numbers',
      'text': 'تایید شد',
      'shape': 'rectangle',
      'opacity': '0.81',
      'createdAt': '2026-07-28T10:00:00Z',
      'colorValue': '4280493768',
      'textWeight': '700',
      'isBold': '1',
      'insetFactor': '0.28',
      'borderWidth': '4.5',
    });

    expect(stamp.opacity, closeTo(.81, .001));
    expect(stamp.textWeight, 700);
    expect(stamp.isBold, isTrue);
    expect(stamp.insetFactor, closeTo(.28, .001));
    expect(stamp.borderWidth, closeTo(4.5, .001));
  });


  test('Legacy stamp JSON safely accepts false-like bold values', () {
    for (final value in ['0', 'false', 'no', 0, false]) {
      final stamp = StampPreset.fromJson({
        'id': 'stamp-false-$value',
        'text': 'نمونه',
        'shape': 'circle',
        'opacity': .72,
        'createdAt': '2026-07-28T10:00:00Z',
        'isBold': value,
      });
      expect(stamp.isBold, isFalse, reason: 'Failed value: $value');
    }
  });

  test('Signature export bounds include every stroke with padding', () {
    final strokes = <InkStroke>[
      InkStroke(points: const [Offset(12, 18), Offset(290, 180)], color: Colors.black, width: 8),
      InkStroke(points: const [Offset(40, 230), Offset(310, 25)], color: Colors.blue, width: 5),
    ];
    final bounds = calculateInkStrokeBounds(strokes);

    expect(bounds.left, lessThan(12));
    expect(bounds.top, lessThan(18));
    expect(bounds.right, greaterThan(310));
    expect(bounds.bottom, greaterThan(230));
  });

  test('Stamp spacing uses direct professional inset values', () {
    expect(StampPreview.normalizedInset(.03), closeTo(.03, .0001));
    expect(StampPreview.normalizedInset(.18), closeTo(.18, .0001));
    expect(StampPreview.normalizedInset(.24), closeTo(.24, .0001));
    expect(StampPreview.normalizedInset(.34), inInclusiveRange(.12, .15));
  });

  test('Stamp border thickness scales consistently with preview size', () {
    expect(StampPreview.normalizedBorderWidth(3, 190), closeTo(3, .001));
    expect(StampPreview.normalizedBorderWidth(8, 190), closeTo(8, .001));
    expect(StampPreview.normalizedBorderWidth(1, 58), greaterThanOrEqualTo(.8));
  });

  test('Person mask creates transparent background and keeps foreground', () {
    final source = im.Image(width: 4, height: 4, numChannels: 4);
    im.fill(source, color: im.ColorRgba8(180, 120, 80, 255));
    final confidences = <double>[
      0, 0, 0, 0,
      0, 1, 1, 0,
      0, 1, 1, 0,
      0, 0, 0, 0,
    ];

    final result = ImageOperations.applyPersonMask(
      im.encodePng(source),
      maskWidth: 4,
      maskHeight: 4,
      confidences: confidences,
      threshold: .5,
    );
    final decoded = im.decodePng(result);

    expect(decoded, isNotNull);
    expect(decoded!.getPixel(0, 0).a, lessThan(20));
    expect(decoded.getPixel(2, 2).a, greaterThan(230));
  });

  test('OCR preprocessing returns a padded binary PNG', () {
    final source = im.Image(width: 40, height: 20, numChannels: 4);
    im.fill(source, color: im.ColorRgba8(255, 255, 255, 255));
    for (var x = 8; x < 32; x++) {
      for (var y = 7; y < 13; y++) {
        source.setPixelRgba(x, y, 20, 20, 20, 255);
      }
    }
    final result = ImageOperations.prepareOcrImage(
      im.encodePng(source),
      profile: OcrProfile.document,
    );
    final decoded = im.decodePng(result);

    expect(decoded, isNotNull);
    expect(decoded!.width, 104);
    expect(decoded.height, 84);
    final values = <int>{};
    for (final pixel in decoded) {
      values.add(pixel.r.toInt());
    }
    expect(values.every((value) => value == 0 || value == 255), isTrue);
  });

  test('OCR cleaner removes symbol-only noise and normalizes Persian letters', () {
    final cleaned = OcrTextCleaner.clean('***\nكپي برابر اصل\n~~\n12345', language: 'fas+eng');
    expect(cleaned, contains('کپی برابر اصل'));
    expect(cleaned, isNot(contains('***')));
    expect(cleaned, isNot(contains('~~')));
  });

  test('StampPreset JSON round-trip preserves styling fields', () {
    final stamp = StampPreset(
      id: 'stamp-1',
      text: 'محمد کدخدایی\nتایید شد',
      shape: StampShape.rectangle,
      opacity: .85,
      createdAt: DateTime.utc(2026, 7, 26),
      colorValue: 0xFF2356C8,
      textWeight: 700,
      isBold: true,
      insetFactor: .28,
      borderWidth: 5.5,
    );

    final decoded = StampPreset.fromJson(stamp.toJson());
    expect(decoded.colorValue, 0xFF2356C8);
    expect(decoded.textWeight, 700);
    expect(decoded.isBold, isTrue);
    expect(decoded.insetFactor, closeTo(.28, .001));
    expect(decoded.borderWidth, closeTo(5.5, .001));
  });

  test('Legacy StampPreset JSON receives safe styling defaults', () {
    final decoded = StampPreset.fromJson({
      'id': 'legacy-stamp',
      'text': 'تایید شد',
      'shape': 'circle',
      'opacity': .7,
      'createdAt': DateTime.utc(2026, 7, 1).toIso8601String(),
    });

    expect(decoded.textWeight, 650);
    expect(decoded.isBold, isTrue);
    expect(decoded.insetFactor, closeTo(.34, .001));
    expect(decoded.borderWidth, closeTo(3.0, .001));
  });

  test('SavedAsset JSON round-trip preserves kind and path', () {
    final asset = SavedAsset(
      id: 'asset-1',
      name: 'امضای اصلی',
      path: '/tmp/signature.png',
      kind: AssetKind.signature,
      createdAt: DateTime.utc(2026, 7, 10),
    );

    final decoded = SavedAsset.fromJson(asset.toJson());
    expect(decoded.id, asset.id);
    expect(decoded.kind, AssetKind.signature);
    expect(decoded.path, asset.path);
  });

  test('Background removal produces a decodable transparent PNG', () {
    final source = im.Image(width: 8, height: 8, numChannels: 4);
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        source.setPixelRgba(x, y, 255, 255, 255, 255);
      }
    }
    source.setPixelRgba(4, 4, 0, 0, 0, 255);

    final result = ImageOperations.removeCornerBackground(
      im.encodePng(source),
      .2,
    );
    final decoded = im.decodePng(result);

    expect(decoded, isNotNull);
    expect(decoded!.getPixel(0, 0).a, 0);
    expect(decoded.getPixel(4, 4).a, greaterThan(0));
  });

  test('Portrait output has exact 3 by 4 dimensions', () {
    final source = im.Image(width: 300, height: 500, numChannels: 4);
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        source.setPixelRgba(x, y, 240, 240, 240, 255);
      }
    }
    for (var y = 100; y < 400; y++) {
      for (var x = 80; x < 220; x++) {
        source.setPixelRgba(x, y, 80, 60, 50, 255);
      }
    }

    final result = ImageOperations.makePortrait(
      im.encodeJpg(source),
      .2,
      Colors.white,
    );
    final decoded = im.decodePng(result);

    expect(decoded, isNotNull);
    expect(decoded!.width, 900);
    expect(decoded.height, 1200);
  });

  test('Adivery R8 rules cover optional MBridge mediation classes', () {
    final rules = File('tool/adivery-proguard-rules.pro').readAsStringSync();
    expect(rules, contains('-dontwarn com.mbridge.msdk.**'));
    expect(rules, contains('-keep class com.adivery.** { *; }'));
    expect(rules, contains('-dontwarn com.google.android.gms.ads.**'));
  });

}
