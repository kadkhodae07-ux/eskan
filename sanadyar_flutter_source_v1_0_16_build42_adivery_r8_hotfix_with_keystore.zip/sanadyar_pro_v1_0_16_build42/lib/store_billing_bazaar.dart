import 'dart:async';

import 'package:flutter_poolakey/flutter_poolakey.dart';

import 'store_billing_contract.dart';

StoreBillingGateway createStoreBillingGateway() => BazaarBillingGateway();

class BazaarBillingGateway implements StoreBillingGateway {
  @override
  String get channel => 'bazaar';

  Future<bool> _connect(String rsaKey) async {
    final completer = Completer<bool>();
    try {
      await FlutterPoolakey.connect(
        rsaKey,
        onSucceed: () {
          if (!completer.isCompleted) completer.complete(true);
        },
        onFailed: () {
          if (!completer.isCompleted) completer.complete(false);
        },
        onDisconnected: () {},
      );
      if (!completer.isCompleted) {
        return completer.future.timeout(const Duration(seconds: 10), onTimeout: () => false);
      }
      return completer.future;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<StoreBillingResult> purchase({
    required String rsaKey,
    required String productId,
    required String payload,
    required bool debug,
  }) async {
    if (!await _connect(rsaKey)) {
      return const StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'اتصال به پرداخت بازار برقرار نشد.',
      );
    }
    final purchase = await FlutterPoolakey.subscribe(productId, payload: payload);
    return StoreBillingResult(
      success: true,
      active: true,
      verified: true,
      message: 'اشتراک Pro بازار فعال شد.',
      receipt: StorePurchaseReceipt(
        storeName: 'bazaar',
        productId: purchase.productId,
        orderId: purchase.orderId,
        purchaseToken: purchase.purchaseToken,
        purchaseTime: _asInt(purchase.purchaseTime),
        payload: purchase.payload,
        originalJson: purchase.originalJson,
        signature: purchase.dataSignature,
      ),
    );
  }

  @override
  Future<StoreBillingResult> restore({
    required String rsaKey,
    required String productId,
    required bool debug,
  }) async {
    if (!await _connect(rsaKey)) {
      return const StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'اتصال به پرداخت بازار برقرار نشد.',
      );
    }
    final subscriptions = await FlutterPoolakey.getAllSubscribedProducts();
    final active = subscriptions.any((item) => item.productId == productId);
    return StoreBillingResult(
      success: active,
      active: active,
      verified: true,
      message: active ? 'اشتراک فعال بازار بازیابی شد.' : 'اشتراک فعالی در بازار پیدا نشد.',
    );
  }

  @override
  Future<void> dispose() => FlutterPoolakey.disconnect();
}

int _asInt(Object? value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString() ?? '') ?? 0;
}
