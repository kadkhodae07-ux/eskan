import 'store_billing_contract.dart';

StoreBillingGateway createStoreBillingGateway() => const _UnsupportedBillingGateway();

class _UnsupportedBillingGateway implements StoreBillingGateway {
  const _UnsupportedBillingGateway();

  @override
  String get channel => 'direct';

  @override
  Future<StoreBillingResult> purchase({
    required String rsaKey,
    required String productId,
    required String payload,
    required bool debug,
  }) async => const StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'این نسخه برای پرداخت بازار یا مایکت ساخته نشده است.',
      );

  @override
  Future<StoreBillingResult> restore({
    required String rsaKey,
    required String productId,
    required bool debug,
  }) async => const StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'کانال فروشگاه پشتیبانی نمی‌شود.',
      );

  @override
  Future<void> dispose() async {}
}
