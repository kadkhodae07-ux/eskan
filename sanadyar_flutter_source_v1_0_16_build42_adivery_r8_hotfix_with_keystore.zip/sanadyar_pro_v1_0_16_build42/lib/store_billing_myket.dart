import 'package:myket_iap/myket_iap.dart';

import 'store_billing_contract.dart';

StoreBillingGateway createStoreBillingGateway() => MyketBillingGateway();

class MyketBillingGateway implements StoreBillingGateway {
  @override
  String get channel => 'myket';

  Future<bool> _initialize(String rsaKey, bool debug) async {
    final result = await MyketIAP.init(rsaKey: rsaKey, enableDebugLogging: debug);
    return result?.isFailure() != true;
  }

  @override
  Future<StoreBillingResult> purchase({
    required String rsaKey,
    required String productId,
    required String payload,
    required bool debug,
  }) async {
    if (!await _initialize(rsaKey, debug)) {
      return const StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'اتصال به پرداخت مایکت برقرار نشد.',
      );
    }
    final resultMap = await MyketIAP.launchPurchaseFlow(sku: productId, payload: payload);
    final result = resultMap[MyketIAP.RESULT];
    final purchase = resultMap[MyketIAP.PURCHASE];
    if (result?.isFailure() == true || purchase == null) {
      return StoreBillingResult(
        success: false,
        active: false,
        verified: true,
        message: 'پرداخت مایکت کامل نشد: $result',
      );
    }
    return StoreBillingResult(
      success: true,
      active: true,
      verified: true,
      message: 'اشتراک Pro مایکت فعال شد.',
      receipt: StorePurchaseReceipt(
        storeName: 'myket',
        productId: purchase.mSku.toString(),
        orderId: purchase.mOrderId.toString(),
        purchaseToken: purchase.mToken.toString(),
        purchaseTime: _asInt(purchase.mPurchaseTime),
        payload: (purchase.mDeveloperPayload ?? '').toString(),
        originalJson: purchase.mOriginalJson.toString(),
        signature: purchase.mSignature.toString(),
      ),
    );
  }

  @override
  Future<StoreBillingResult> restore({
    required String rsaKey,
    required String productId,
    required bool debug,
  }) async {
    if (!await _initialize(rsaKey, debug)) {
      return const StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'اتصال به پرداخت مایکت برقرار نشد.',
      );
    }
    final resultMap = await MyketIAP.getPurchase(sku: productId, querySkuDetails: false);
    final result = resultMap[MyketIAP.RESULT];
    final purchase = resultMap[MyketIAP.PURCHASE];
    if (result?.isFailure() == true) {
      return StoreBillingResult(
        success: false,
        active: false,
        verified: false,
        message: 'بررسی خرید مایکت انجام نشد: $result',
      );
    }
    final active = purchase != null && purchase.mSku.toString() == productId;
    return StoreBillingResult(
      success: active,
      active: active,
      verified: true,
      message: active ? 'اشتراک فعال مایکت بازیابی شد.' : 'اشتراک فعالی در مایکت پیدا نشد.',
    );
  }

  @override
  Future<void> dispose() => MyketIAP.dispose();
}

int _asInt(Object? value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse(value?.toString() ?? '') ?? 0;
}
