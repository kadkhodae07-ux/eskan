class StorePurchaseReceipt {
  const StorePurchaseReceipt({
    required this.storeName,
    required this.productId,
    required this.orderId,
    required this.purchaseToken,
    required this.purchaseTime,
    required this.payload,
    required this.originalJson,
    required this.signature,
  });

  final String storeName;
  final String productId;
  final String orderId;
  final String purchaseToken;
  final int purchaseTime;
  final String payload;
  final String originalJson;
  final String signature;
}

class StoreBillingResult {
  const StoreBillingResult({
    required this.success,
    required this.active,
    required this.verified,
    required this.message,
    this.receipt,
  });

  final bool success;
  final bool active;
  final bool verified;
  final String message;
  final StorePurchaseReceipt? receipt;
}

abstract class StoreBillingGateway {
  String get channel;

  Future<StoreBillingResult> purchase({
    required String rsaKey,
    required String productId,
    required String payload,
    required bool debug,
  });

  Future<StoreBillingResult> restore({
    required String rsaKey,
    required String productId,
    required bool debug,
  });

  Future<void> dispose();
}
