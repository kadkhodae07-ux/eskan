# Third-party notices

Sanadyar includes or depends on the following third-party software. Refer to each package distribution for complete license text and applicable service terms.

- Flutter SDK — BSD 3-Clause License.
- Dart SDK — BSD 3-Clause License.
- `adivery` 4.9.0 — Apache License 2.0; ad serving is subject to Adivery service terms.
- `flutter_poolakey` 2.2.0+1.0.0 — Apache License 2.0; wraps Cafe Bazaar Poolakey billing.
- `myket_iap` 1.1.12 — BSD 3-Clause License; wraps Myket billing.
- `shared_preferences` 2.5.5 and `flutter_secure_storage` 9.2.4 — respective package licenses.
- `gal` 2.3.3 — MIT License.
- `google_mlkit_selfie_segmentation` 0.11.0 and `google_mlkit_face_detection` 0.14.0 — MIT License; Google ML Kit components have their own terms.
- `image` 4.8.0 — MIT License.
- `pdf` / `printing` — Apache License 2.0.
- `tesseract_ocr` vendored compatibility wrapper — see `packages/tesseract_ocr/LICENSE`.
- Tesseract / tess-two native engine and trained data — Apache License 2.0 and respective trained-data terms.
