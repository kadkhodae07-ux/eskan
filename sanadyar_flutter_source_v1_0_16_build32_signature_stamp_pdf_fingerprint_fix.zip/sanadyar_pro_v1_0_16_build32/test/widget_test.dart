import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as im;
import 'package:sanadyar/main.dart';

void main() {
  test('Sanadyar app root can be constructed', () {
    expect(const SanadyarApp(), isA<SanadyarApp>());
  });


  test('StampPreset JSON round-trip preserves styling fields', () {
    final stamp = StampPreset(
      id: 'stamp-1',
      text: 'محمد کدخدایی\nتایید شد',
      shape: StampShape.rectangle,
      opacity: .85,
      createdAt: DateTime.utc(2026, 7, 26),
      colorValue: 0xFF2356C8,
      textWeight: 700,
      isBold: true,
      insetFactor: .28,
    );

    final decoded = StampPreset.fromJson(stamp.toJson());
    expect(decoded.colorValue, 0xFF2356C8);
    expect(decoded.textWeight, 700);
    expect(decoded.isBold, isTrue);
    expect(decoded.insetFactor, closeTo(.28, .001));
  });

  test('SavedAsset JSON round-trip preserves kind and path', () {
    final asset = SavedAsset(
      id: 'asset-1',
      name: 'امضای اصلی',
      path: '/tmp/signature.png',
      kind: AssetKind.signature,
      createdAt: DateTime.utc(2026, 7, 10),
    );

    final decoded = SavedAsset.fromJson(asset.toJson());
    expect(decoded.id, asset.id);
    expect(decoded.kind, AssetKind.signature);
    expect(decoded.path, asset.path);
  });

  test('Background removal produces a decodable transparent PNG', () {
    final source = im.Image(width: 8, height: 8, numChannels: 4);
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        source.setPixelRgba(x, y, 255, 255, 255, 255);
      }
    }
    source.setPixelRgba(4, 4, 0, 0, 0, 255);

    final result = ImageOperations.removeCornerBackground(
      im.encodePng(source),
      .2,
    );
    final decoded = im.decodePng(result);

    expect(decoded, isNotNull);
    expect(decoded!.getPixel(0, 0).a, 0);
    expect(decoded.getPixel(4, 4).a, greaterThan(0));
  });

  test('Portrait output has exact 3 by 4 dimensions', () {
    final source = im.Image(width: 300, height: 500, numChannels: 4);
    for (var y = 0; y < source.height; y++) {
      for (var x = 0; x < source.width; x++) {
        source.setPixelRgba(x, y, 240, 240, 240, 255);
      }
    }
    for (var y = 100; y < 400; y++) {
      for (var x = 80; x < 220; x++) {
        source.setPixelRgba(x, y, 80, 60, 50, 255);
      }
    }

    final result = ImageOperations.makePortrait(
      im.encodeJpg(source),
      .2,
      Colors.white,
    );
    final decoded = im.decodePng(result);

    expect(decoded, isNotNull);
    expect(decoded!.width, 900);
    expect(decoded.height, 1200);
  });
}
