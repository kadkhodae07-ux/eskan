# Validation report — Build 32

- Source tree version updated to `1.0.16+32`.
- Signature canvas logic updated to apply style changes to existing strokes.
- Scan PDF creation updated to an isolate-based background job.
- Stamp preset schema extended with color/text-weight/bold/inset settings and backward-compatible defaults.
- Fingerprint extraction output is now cropped to subject bounds.
