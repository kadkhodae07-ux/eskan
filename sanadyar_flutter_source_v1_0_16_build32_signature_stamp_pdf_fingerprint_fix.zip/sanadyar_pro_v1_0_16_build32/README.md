# Sanadyar Pro — Build 32

Sanadyar is a Flutter-based Persian document utility app with document scanning, OCR, signatures, fingerprint extraction, portrait 3×4 creation, background removal and PDF/image editing.

## Build 32 focus

Build 32 focuses on the user-reported runtime issues from Build 31:

- Signature settings now restyle the current signature strokes and the canvas no longer scroll-shakes while drawing.
- Multi-page PDF generation is moved off the UI thread to prevent ANR/crash during gallery-based scans.
- Stamp creation now supports richer text controls and confirms successful save.
- Fingerprint extraction is cleaner, cropped tighter and confirms save.

See `CHANGELOG.md` and `VALIDATION_REPORT.md` for details.
