# Sanadyar 1.0.16+32

## Fixed

- Signature settings now apply to the already drawn signature by restyling all existing strokes when pen type, color or thickness changes.
- Signature canvas scrolling jitter is reduced by locking parent scrolling while the user is drawing.
- Multi-page scan PDF creation now runs in a background isolate and uses lower-memory image processing to prevent ANR/crash on gallery-based batches.
- Removed the automatic PDF share step after scan generation and replaced it with a save confirmation flow.

## Improved

- Stamp presets now persist color, text weight, bold mode and inner spacing.
- Stamp studio now includes text-weight, bold and text-to-border spacing controls, and shows a success message after saving.
- Fingerprint extraction now denoises, crops to the detected print bounds and keeps a larger cleaner transparent preview/output.
- Signature, stamp and fingerprint save flows now show explicit success feedback.

## Toolchain

- Flutter: 3.44.6
- Dart: 3.12.2
- Java: 17
- Android compile/target SDK: 36
- Android min SDK: 24
- Android Gradle Plugin: 8.11.1
- Gradle: 8.14.3
- Kotlin Gradle Plugin: 2.2.20
